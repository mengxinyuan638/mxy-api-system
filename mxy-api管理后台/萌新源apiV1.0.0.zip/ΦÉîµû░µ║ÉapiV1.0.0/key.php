<?php
$key=$_SERVER["HTTP_HOST"];//网址
$qq="1648576390";//QQ
$mz="萌新源";//名称
?>
