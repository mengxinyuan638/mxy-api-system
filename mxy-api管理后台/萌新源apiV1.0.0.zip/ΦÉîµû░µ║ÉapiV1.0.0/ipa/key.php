<?php
$aa=$_SERVER["HTTP_HOST"];
$key="http://".$aa."";//网址
$qq="1984873728";//QQ
$mz="呵呵";//名称
?>
