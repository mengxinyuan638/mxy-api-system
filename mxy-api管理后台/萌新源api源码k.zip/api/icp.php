<?php
$res = $_GET['msg'];

function post_data_test($url,$data)
{
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
$header = array(
'User-Agent' => 'Mozilla/5.0 (Linux; Android 10; Redmi K30 5G Build/QKQ1.191222.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.101 Mobile Safari/537.36',
'Referer' => 'http://micp.chinaz.com/?query='.$res,
'Cookie'=>'inputbox_urls=["'.$res.'"]');

curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
curl_setopt($curl, CURLOPT_POST, 1);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
curl_setopt($curl, CURLOPT_TIMEOUT, 30);
curl_setopt($curl, CURLOPT_HEADER, 0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
if (curl_errno($curl))
{
echo '错误信息;'.curl_error($curl);
}
curl_close($curl);
return $result;
}


if(strstr($res,"."))
{
$data="query=".$res."&accessmode=host&isupdate=false";
//获取开始，注册字段
$url='http://micp.chinaz.com/?query='.$res;
$json = post_data_test($url,$data); //调用的站长工具
function GetBetween($content,$start,$end){
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
// 获取主办单位名称
$b ='主办单位：</td><td class="z-tl">';
$c ='<';
$name = GetBetween($json,$b,$c);
// 获取性质
$b ='单位性质：</td><td class="z-tl">';
$c ='<';
$nature = GetBetween($json,$b,$c);
// 获取备案号
$b ='备案号：</td><td class="z-tl">';
$c ='<';
$icp = GetBetween($json,$b,$c);
// 获取网站名称
$b ='网站名称：</td><td class="z-tl">';
$c ='<';
$sitename = GetBetween($json,$b,$c);
// 获取网站首页地址
$b ='网站首页：</td><td class="z-tl">';
$c ='<';
$index = GetBetween($json,$b,$c);
if(strstr($index,"."))
{ }else{
echo '未有此域名ICP备案记录!';
exit();
}
// 获取审核时间
$b ='审核时间：</td><td class="z-tl">';
$c ='<';
$time = GetBetween($json,$b,$c);
// 获取最近检测时间
$b ='最近检测：</td><td class="z-tl">';
$c ='<';
$Detection = GetBetween($json,$b,$c);
echo '主办单位名称:'.$name.'\n主办单位性质:'.$nature.'\n网站备案/许可证号:'.$icp.'\n网站名称:'.$sitename.'\n网站首页网址:'.$index.'\n审核时间:'.$time.'\n最近检测:'.$Detection.'';
}else{
echo '域名不能为空!';
// echo "内容不为空";
// return false;
exit();
}
?>