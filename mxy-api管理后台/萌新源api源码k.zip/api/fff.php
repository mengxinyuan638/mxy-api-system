<?php
header("Content-type:application/json;charset=utf-8");
$url="https://api.jikipedia.com/go/search_definitions"; 
$param=array(
"phrase"=>$_GET["msg"],
"page"=>1,
);
$data = json_encode($param); 
list($return_code, $return_content) = http_post_data($url, $data);
$sss=print_r($return_content,true);
$pst= json_decode($sss);
$de=$pst->data;
$cou= count($de);
$title=$de[0]->term->title;
if($title){
echo "流行语：".$title."\n".$de[0]->plaintext;
}else{
$url="https://api.jikipedia.com/wiki/get_user_info"; 
$param=array("code"=>"10c4c4520fdf68e95ee6644c4d6044bc");
$data = json_encode($param); 
list($return_code, $return_content) = http_post_data($url, $data);
$sss= print_r($return_content,true);
$ss=json_decode($sss);
$fs = fopen("token.txt",'w');
   fwrite($fs,$ss->token);
echo "搜索失败，该词条未收录";
}
exit;
function http_post_data($url, $data_string) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	"Content-Type: application/json; charset=utf-8",
		"Content-Length: " . strlen($data_string),
"XID: aAXeCVBFdR+p5c1Pzri3Gt0LvvSdG8tfU5k18gEnzS9fgAaGDt8cnYD+pfFb2yMWqwPA36XDX8V5Ifs85m1fTRj59dUwDFdBQicRo0Ht1Qc=",
"Referer: https://appservice.qq.com/1109319762/1.1.0/page-frame.html",
"User-Agent: Mozilla%2F5.0+%28Linux%3B+Android+10%3B+MI+8+Lite+Build%2FQKQ1.190910.002%3B+wv%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Version%2F4.0+Chrome%2F81.0.4044.138+Mobile+Safari%2F537.36 QQ/8.4.10.4875 V1_AND_SQ_8.4.10_1524_YYB_D QQ/MiniApp",
"Token: " . file_get_contents("token.txt"),
"Client-Version: 1.1.0",
"Client: qq_miniapp",
"Host: api.jikipedia.com",
"Connection: Keep-Alive",
"Accept-Encoding: gzip")
	);
	ob_start();
	curl_exec($ch);
	$return_content = ob_get_contents();
	ob_end_clean();
	$return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	return array($return_code, $return_content);
}
?>