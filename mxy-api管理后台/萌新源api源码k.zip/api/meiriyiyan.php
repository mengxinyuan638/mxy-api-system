<?php
header("Content-type: text/html; charset=UTF-8");
 //统计

$name = urlencode($_GET['msg']);
$html = file_get_contents("compress.zlib://http://api.douqq.com/?key=OUpHNGc9U0FjdGhrZj1LeDFQQS9Zc3p6eVJJQUFBPT0&msg="每日一言"");





echo "$html";


?>