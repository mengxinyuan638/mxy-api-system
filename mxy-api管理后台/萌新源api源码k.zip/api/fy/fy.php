<?php
header("Content-Type:text/html;charset=utf-8");
include("http://api.robotmm.cn/tongji/tongji.php"); //统计

include ("HttpCurl.php");
include ("array.php");
$from=$_GET["from"];
$text=$_GET["msg"];
$to=$_GET["to"];
$from=$array[$from];
$to=$array[$to];
$header=array(
"Accept: */*",
"Content-Type:application/x-www-form-urlencoded",
"X-FORWARDED-FOR:27.38.28.255",
"CLIENT-IP:27.38.28.255",
"Referer:https://fanyi.baidu.com/",
"User-Agent:Mozilla/5.0 (Linux; Android 7.0; MHA-AL00 Build/HUAWEIMHA-AL00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.134 Mobile Safari/537.36 LeBrowser/7.4.0"
);
$header2=array(
"Content-Type: application/x-www-form-urlencoded",
"Referer: https://fanyi.baidu.com/",
"User-Agent: Mozilla/5.0 (Linux; Android 7.0; MHA-AL00 Build/HUAWEIMHA-AL00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.134 Mobile Safari/537.36 LeBrowser/7.4.0",
);
$data="query=".$text."&from=".$from."&to=".$to."";
//$data=["query"=>"中国人","from"=>"zh","to"=>"en"];
$result = (new HttpCurl())->setHeader($header)->setParams($data)->post("https://fanyi.baidu.com/basetrans");
$data=$result;
if($from==null||$to==null)
{
echo "抱歉，获取出错了！\n请检查from或to参数！";
}
else
if($text==null)
{
echo "抱歉，未检测到输入内容！";
}
else
if($text!=null&&$from!=null&&$to!=null)
{
$data=json_decode($data,true);
if($data["errno"]=="0")
{
echo "---百  度  翻  译---\n[状态]errno:0(正常)\n[类型]".$array2[$from]."转".$array2[$to]."\n[译前]".$data["trans"][0]["src"]."\n[译后]".$data["trans"][0]["dst"]."\n[时间]".date("Y-m-d-h-i-sa")."";
}
else
{
echo "---百  度  翻  译---\n[状态]errno:-999(错误)\n[原因]百度暂不支持此语种\n[时间]".date("Y-m-d-h-i-sa")."";
}
}
?>