<?php

/**
 * HttpCurl Curl模拟Http工具类。
 * time 2018 10/26 修订完成。
 *如果发现错误或者bug，自己有能力修改的稍微修改一下。
 *或者联系QQ50687505。
 */

 /*服务器错误码*/
//include("error.php");
error_reporting(0);
function sendHttpStatus($code) {
	$errorcode = array(
		// Informational 1xx
		100 => "Continue",
		101 => "Switching Protocols",
 		// Success 2xx
   //	200 => "OK",
		201 => "Created",
		202 => "Accepted",
		203 => "Non-Authoritative Information",
		204 => "No Content",
		205 => "Reset Content",
		206 => "Partial Content",
		// Redirection 3xx
		300 => "Multiple Choices",
		301 => "Moved Permanently",
		302 => "Moved Temporarily ",
		// 1.1
		303 => "See Other",
		304 => "Not Modified",
		305 => "Use Proxy",
		// 306 is deprecated but reserved
		307 => "Temporary Redirect",
		// Client Error 4xx
		400 => "Bad Request",
		401 => "Unauthorized",
		402 => "Payment Required",
		403 => "Forbidden",
		404 => "Not Found",
		405 => "Method Not Allowed",
		406 => "Not Acceptable",
		407 => "Proxy Authentication Required",
		408 => "Request Timeout",
		409 => "Conflict",
		410 => "Gone",
		411 => "Length Required",
		412 => "Precondition Failed",
		413 => "Request Entity Too Large",
		414 => "Request-URI Too Long",
		415 => "Unsupported Media Type",
		416 => "Requested Range Not Satisfiable",
		417 => "Expectation Failed",
		// Server Error 5xx
		500 => "Internal Server Error",
		501 => "Not Implemented",
		502 => "Bad Gateway",
		503 => "Service Unavailable",
		504 => "Gateway Timeout",
		505 => "HTTP Version Not Supported",
		509 => "Bandwidth Limit Exceeded"
	);

	if ($code==false) {
	return "请检查域名是否正确!";}
else 	if (isset($errorcode [$code])) {
	return "错误码: ".$code."，主要原因: ".$errorcode [$code];
	}}




 /*CURL函数调用类*/
class HttpCurl {
    private $ch = null; // curl handle
    private $header = array(); // request header
    private $proxy = null; // http proxy
    private $timeout = 5; // connnect timeout
    private $httpParams = null;


    public function __construct() {
        $this->ch = curl_init();
    }
    
       /**
     * 设置http header
     * @param $header
     * @return $this
     */
    public function setHeader($header) {
        if (is_array($header)){
        curl_setopt($this->ch, CURLOPT_HTTPHEADER , $header);
        }
        return $this;
    }
    
      /**
     * 设置来源页面
     * @param string $referer
     * @return $this
     */
     public function setReferer($referer = "") {
        if (!empty($referer))
        curl_setopt($this->ch, CURLOPT_REFERER , $referer);
        return $this;
    }
    
      /**
     * 设置 跟踪重定向302, 1表示跟踪
     * @param array $location
     * @return $this
     */
   public function setlocation($shownum) {
     if ($shownum) {
      curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, $shownum);
      return $this;
     }
     else {
    $this->sendHttp = null;
     return $this;
    }
  }

     /*
     * 显示重定向地址, 1表示显示
     * @param array $location
     * @return $this
     */
public function showlocation($shownum) {

   if ($shownum==1){
    $this->ymcdx = CURLINFO_EFFECTIVE_URL;
    return $this;
    }else {
   $this->ymcdx = null;
    return $this;
    }
}

     /**
     * 设置 自定义cookie和存储cookie
     说明:
     1只发送自定义cookie
     2只发送固定文件名文件版cookie
     3只发送随机文件名文件版cookie
     4只发送自定义cookie和访问网站产生的固定文件名文件版cookie
     5只发送自定义cookie和访问网站产生的随机文件名文件版cookie
     使用随机文件名cookie时候需要手动新建一个tmp文件夹
     格式: setcookie(调用id比如1,cookie赋值)
     * @param array $cookie
     * @return $this
     */
    public function setcookie($id,$cookie) {
    
     if ($id==1) {
    curl_setopt($this->ch, CURLOPT_COOKIE, $cookie);
    return $this;
     }
    else if ($id==2) {
    curl_setopt($this->ch, CURLOPT_COOKIEFILE, "cookie.txt");
    curl_setopt($this->ch, CURLOPT_COOKIEJAR, "cookie.txt");
    return $this;
     }
     else if ($id==3) {
     $cookie_jar = tempnam("./tmp","cookie");
    curl_setopt($this->ch, CURLOPT_COOKIEFILE, $cookie_jar);
    curl_setopt($this->ch, CURLOPT_COOKIEJAR, $cookie_jar);
    return $this;
     }
     else if ($id==4) {
    curl_setopt($this->ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($this->ch, CURLOPT_COOKIEFILE, "cookie.txt");
    curl_setopt($this->ch, CURLOPT_COOKIEJAR, "cookie.txt");
    return $this;
    }
     else if ($id==5) {
     $cookie_jar = tempnam("./tmp","cookie");
    curl_setopt($this->ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($this->ch, CURLOPT_COOKIEFILE, $cookie_jar);
    curl_setopt($this->ch, CURLOPT_COOKIEJAR, $cookie_jar);
    return $this;
    }
    
    else {
    $this->sendHttp = null;
     return $this;
    }
    
  }

    /**
     * 设置http 请求成功后前后超时时间设置
     * @param int $time
     * @return $this
     */
    public function setTimeout($time,$time2) {
        // 不能小于等于0
        if ($time <= 0||$time2 <= 0) {
            $time = 5;
            $time2 = 5;
        }
        //只需要设置一个秒的数量就可以
        curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT, $time);
        curl_setopt($this->ch, CURLOPT_TIMEOUT, $time2);
        return $this;
    }

    /**
     * 设置http 代理
     * @param string $proxy
     * @return $this
     */
    public function setProxy($proxy) {
        if ($proxy) {
            curl_setopt ($this->ch, CURLOPT_PROXY, $proxy);
        }
        return $this;
    }

    /**
     * 设置http 代理端口
     * @param int $port
     * @return $this
     */
    public function setProxyPort($port) {
        if (is_int($port)) {
            curl_setopt($this->ch, CURLOPT_PROXYPORT, $port);
        }
        return $this;
    }

    /**
     * 设置用户代理
     * @param string $agent
     * @return $this
     */
    public function setUserAgent($agent = "") {
        if ($agent) {
            // 模拟用户使用的浏览器
            curl_setopt($this->ch, CURLOPT_USERAGENT, $agent);
        }
        return $this;
    }

    /**
     * http响应中是否显示header，1表示显示
     * @param $show
     * @return $this
     */
    public function showResponseHeader($show) {
        curl_setopt($this->ch, CURLOPT_HEADER, $show);
        return $this;
    }

    /**
     * 设置http请求的参数,get或post
     * @param array $params
     * @return $this
     */
     public function setParams($params) {
        $this->httpParams = $params;
        return $this;
    }
    
        /**
     * 设置证书路径
     * @param $file
     */
    public function setCainfo($file) {
        curl_setopt($this->ch, CURLOPT_CAINFO, $file);
    }
   
    
    /**
     * 模拟GET请求
     * @param string $url
     * @param string $dataType
     * @return bool|mixed
     */
      public function get($url, $dataType = "text") {
   
        if (stripos($url, "https://") !== false) {
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($this->ch, CURLOPT_SSLVERSION, 1);
        }
 
        // 设置get body
        if (!empty($this->httpParams) && is_array($this->httpParams)) {

        $arrStr = explode("&", $url); 
       if ($arrStr[count($arrStr)-1] == "") {
         $url .= http_build_query($this->httpParams);
         }
         else if(strpos($url, "?") !== false) {
                $url .= "&".http_build_query($this->httpParams);
            } else {
               $url .= "?" . http_build_query($this->httpParams);
            }
    
    } 

         // end 设置get body
        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
       $content = curl_exec($this->ch);

        if ($this->ymcdx!="1048577") {
        $status = curl_getinfo($this->ch);
        }
        else {
   $status = curl_getinfo($this->ch,$this->ymcdx);
 }
 
        curl_close($this->ch);
       
        if ($this->ymcdx=="1048577") {
            return $status;}
            
          else if (isset($status["http_code"]) 
&& $status["http_code"] == 200) {
         
            if ($dataType == "json") {
                $content = json_decode($content, true);
            }
          
            return $content;
            }
            
        else if (isset($status["http_code"]) 
&& $status["http_code"] != 200) {
  $HttpStatus=sendHttpStatus($status["http_code"]);
     echo $HttpStatus."<br>";
        }
         else {
            return false;
           }
           
        }

              
    /*
     * 模拟POST请求
     * @param string $url
     * @param array $fields
     * @param string $dataType
     * @return mixed
     * 
     * HttpCurl::post("http://api.example.com/?a=123", array("abc"=>"123", "efg"=>"567"), "json");
     * HttpCurl::post("http://api.example.com/", "这是post原始内容", "json");
     * 文件post上传
     * HttpCurl::post("http://api.example.com/", array("abc"=>"123", "file1"=>"@/data/1.jpg"), "json");
     */
    public function post($url, $dataType="text") {
    
        if (stripos($url, "https://") !== false) {
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($this->ch, CURLOPT_SSLVERSION, 1);
        }
        curl_setopt($this->ch, CURLOPT_URL, $url);
        // 设置post body
        if (!empty($this->httpParams)) {
            if (is_array($this->httpParams)) {
                curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($this->httpParams));
            } else if (is_string($this->httpParams)) {
                curl_setopt($this->ch, CURLOPT_POSTFIELDS, $this->httpParams);
            }
        }
        // end 设置post body
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
        if ($this->httpParams!=null) {
       curl_setopt($this->ch, CURLOPT_POST, true);
        }
        $content = curl_exec($this->ch);
 
        if ($this->ymcdx!="1048577") {
        $status = curl_getinfo($this->ch);
        }
        else {
$status = curl_getinfo($this->ch,$this->ymcdx);
 }
 
        curl_close($this->ch);
        
       if ($this->ymcdx=="1048577") {
            return $status;}
            
          else if (isset($status["http_code"]) 
&& $status["http_code"] == 200) {
     
            if ($dataType == "json") {
                $content=json_decode($content, 1);
            }
            
            return $content;
        }
        else if (isset($status["http_code"]) 
&& $status["http_code"] != 200) {
  $HttpStatus=sendHttpStatus($status["http_code"]);
     echo $HttpStatus."<br>";
        }
        else {
            return false;
        }
 
    }
  
}





/**
*报错或者脚本出现问题解决方法备份

 else{
    $this->sendHttp = null;
     return $this;
    }
    
*/


?>
