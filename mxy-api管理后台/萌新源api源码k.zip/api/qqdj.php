<?php
 //统计

$zskey=file_get_contents("http://".$_SERVER['HTTP_HOST']."/key/skey.dat");
$s=preg_match_all('/"uin":"(.*?)","skey":"(.*?)","pskey":"(.*?)"/',$zskey,$j);
$uin=$j[1][0];
$skey=$j[2][0];
$pskey=$j[3][0];
@$uin=$_GET['uin']?:$uin;
@$skey=$_GET['skey']?:"@".$skey;
if($_GET['qq']){}
else{
echo "抱歉，qq参数不存在！\\n此为必填项。";exit;}
$gtk= getGTK($skey);
$cookie = 'uin=o0'.$uin.'; skey='.$skey.'; p_uin=o'.$uin.'; ';
$url = "https://h5.vip.qq.com/p/mc/cardv2/other?_wv=1031&platform=1&qq=".$_GET['qq']."&adtag=qun&aid=mvip.pingtai.mobileqq.androidziliaoka.fromqqqun";
$post = '0';
$data = get_curl($url,$post,$url,$cookie);
$s=preg_match_all('/<p><small>LV<\/small>(.*?)<\/p>/',$data,$trstr);
if($s==0){echo "抱歉，skey已失效。\\n若此为官方提供的skey等信息，则请您提供个人相关参数。\\nuin=账号、skey=QQskey。";exit;}
$dj=$trstr[1][0];//等级
echo "QQ等级：".$dj."";
function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept:application/json";
$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
$httpheader[] = "Connection:close";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if($post){
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
if($header){
curl_setopt($ch, CURLOPT_HEADER, TRUE);}
if($cookie){
curl_setopt($ch, CURLOPT_COOKIE, $cookie);}
if($referer){
if($referer==1){
curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
}else{
curl_setopt($ch, CURLOPT_REFERER, $referer);}}
if($ua){
curl_setopt($ch, CURLOPT_USERAGENT,$ua);
}else{
curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');}
if($nobaody){
curl_setopt($ch, CURLOPT_NOBODY,1);}
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;}
function getGTK($skey){
$len = strlen($skey);
$hash = 5381;
for($i = 0; $i < $len; $i++){
$hash += ($hash << 5) + ord($skey[$i]);}
return $hash & 0x7fffffff;}

?>