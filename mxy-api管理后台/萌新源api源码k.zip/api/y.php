<?php
 //统计

$msg=$_GET['msg'];
$n=$_GET['n'];
$cookie = '0';
$url = "https://u.y.qq.com/cgi-bin/musicu.fcg";
$post = '{"comm":{"uin":"486657778","authst":"Q_H_L_2iPd9t50eCklB8p37yV4Sojpi4Ixix4ehcayzwOwZnBLcS9l9mTRe5hApHDi802","mina":1,"appid":1109523715,"ct":29},"search":{"module":"qqmusic.adaptor","method":"do_search","param":{"searchid":"1573494200311","search_type":100,"query":"'.$msg.'","page_id":1,"page_num":10,"remoteplace":"txt.miniapp.1109523715","highlight":0,"nqc_flag":0,"grp":0,"multi_zhida":1}}}';
$str= get_curl($url,$post,0,$cookie);
$result=preg_match_all('/"label":"(.*?)","language":(.*?),"mid":"(.*?)","mv":{"id":(.*?),"name":"(.*?)","title":"(.*?)","vid":"(.*?)"},"name":"(.*?)","pay":{"pay_down":(.*?),"pay_month":(.*?),"pay_play":(.*?),"pay_status":(.*?),"price_album":(.*?),"price_track":(.*?),"time_free":(.*?)},"singer":\[{"id":(.*?),"mid":"(.*?)","name":"(.*?)"/',$str,$trstr);
if($result== 0){
echo "搜索不到与".$_GET["msg"]."的相关音乐，请稍后重试或换个关键词试试。";exit;}

if($n==null){
for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$ga=$trstr[8][$i];//歌曲
$gb=$trstr[18][$i];//歌手
echo ($i+1)."：".$ga."——".$gb."\n";}
echo "\n共搜索到与".$_GET["msg"]."的相关音乐".$result."曲，您可以点1～".$result."任一曲。";
exit;}
//"label":"0","language":0,"mid":"000junkg15bKSI","mv":{"id":1485703,"name":"","title":"","vid":"r0027dno8wg"},"name":"选择失忆","pay":{"pay_down":1,"pay_month":1,"pay_play":0,"pay_status":0,"price_album":0,"price_track":200,"time_free":0},"singer":[{"id":1055436,"mid":"004IHCLx2eWTCC","name":"季彦霖"

$mid=$trstr[3][($n-1)];
$url = "https://u.y.qq.com/cgi-bin/musicu.fcg";
$t = get_millisecond();
$guid = round((mt_rand()/mt_getrandmax())*2147483647) * $t % 10000000000;

$post = '{"comm":{"uin":"2657595205","authst":"Q_H_L_2GkSAt50ee8gzIxBfwVxm4zic4SoFWtBe7jn4KeVgsdv-i16zip19RIMmP_JJ59","mina":1,"appid":1109523715,"ct":29},"urlReq":{"module":"vkey.GetVkeyServer","method":"CgiGetVkey","param":{"guid":"'.$guid.'","songmid":["'.$mid.'"],"songtype":[0],"uin":"2657595205","loginflag":1,"platform":"23","h5to":"speed"}}}';
$str= get_curl($url,$post,0,$cookie);
function get_millisecond(){
list($usec, $sec) = explode(" ", microtime());
$msec=round($usec*1000);
return $msec;}
preg_match_all('/"purl":"(.*?)"/',$str,$c);
$j=$c[1][0];
echo "http://dl.stream.qqmusic.qq.com/".$j;
function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=1,$nobaody=0,$json=0)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept:application/json";
$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
$httpheader[] = "Connection:close";
if($json){
$httpheader[] = "Content-Type:application/json; charset=utf-8";
}
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if($post){
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
if($header){
curl_setopt($ch, CURLOPT_HEADER, TRUE);
}
if($cookie){
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
}
if($referer){
if($referer==1){
curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
}else{
curl_setopt($ch, CURLOPT_REFERER, $referer);
}}
if($ua){
curl_setopt($ch, CURLOPT_USERAGENT,$ua);
}else{
curl_setopt($ch, CURLOPT_USERAGENT,'Dalvik/2.1.0 (Linux; U; Android 9; 16s Build/PKQ1.190202.001)');
}
if($nobaody){
curl_setopt($ch, CURLOPT_NOBODY,1);
}
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$ret = curl_exec($ch);
curl_close($ch);
//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
return $ret;
}
?>