<?php
	 $arr=range(0,30);
        shuffle($arr);
        foreach($arr as $values);
        $str = "/\"objURL\":\"(.*?)\",/";
        $name = urlencode($_GET["msg"]);
        $html = file_get_contents("http://image.baidu.com/search/index?tn=baiduimage&ipn=r&ct=201326592&cl=2&lm=-1&st=-1&fm=index&fr=&sf=1&fmq=&pv=&ic=0&nc=1&z=&se=1&showtab=0&fb=0&width=&height=&face=0&istype=2&ie=utf-8&word=".$name."&oq=haizei&rsp=0");
        preg_match_all($str,$html,$trstr);
        echo $trstr[1][$values];
?>
