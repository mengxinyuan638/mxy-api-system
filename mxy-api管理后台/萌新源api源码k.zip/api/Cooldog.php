<?php
$msg = $_GET['msg'];
$b = $_GET['n'];
$data=curl('http://mvsearch.kugou.com/mv_search?page=1&pagesize=15&userid=-1&clientver=&platform=WebFilter&tag=em&filter=10&iscorrection=1&privilege_filter=0&keyword='.$msg);
$data=str_replace('','',$data);
$data=str_replace('<\/em>','',$data);
$json = json_decode($data, true);
$s=count($json["data"]["lists"]);
if($s==0){exit("抱歉，返回数据为空。");}
if($b==""){
for( $i = 0 ; $i < $s ; $i ++ ){
$ga=$json["data"]["lists"][$i]["MvName"];
$gb=$json["data"]["lists"][$i]["SingerName"];
echo ($i+1)."：".$ga."--".$gb."\n";
}
echo "提示:请在以上序号中选择";
}
else
{
$i=($b-1);
$ga=$json["data"]["lists"][$i]["MvName"];
$gb=$json["data"]["lists"][$i]["SingerName"];
$hash=$json["data"]["lists"][$i]["MvHash"];
$r = 'http://www.kugou.com/webkugouplayer/?isopen=0&chl=yueku_index';
$u="Mozilla/5.0 (Linux; Android 9; 16s Build/PKQ1.190202.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/045140 Mobile Safari/537.36 V1_AND_SQ_8.3.5_1392_YYB_D QQ/8.3.5.4555 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/72 SimpleUISwitch/0 QQTheme/1000";
$data=curl('http://m.kugou.com/app/i/mv.php?cmd=100&hash='.$hash.'&ismp3=1&ext=mp4',0,array('IPHONE_UA'=>0,'REFERER'=>$r,'USERAGENT'=>$u));
$json = json_decode($data, true);
$url=$json["mvdata"]["sq"]["downurl"];
if($url==""){
$url=$json["mvdata"]["le"]["downurl"];}
if($url==""){exit("抱歉，解析失败。");}
$img=str_replace(array('{size}'), array('', ''), $json["mvicon"]);
echo '±img='.$img.'±\rMV：'.$ga.'\r作者：'.$gb.'\r播放链接：'.$url;
}




function curl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".ip(),"X-FORWARDED-FOR: ".ip(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".ip(),"X-FORWARDED-FOR: ".ip(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
$header=array_merge($header_array,$header);
}
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);}
if($referer){
curl_setopt($curl,CURLOPT_REFERER,$referer);}
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
if($code){
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
}else{
$return=curl_exec($curl);
curl_close($curl);
return $return;}}
function ip(){
$ip_long = array(
array('607649792','608174079'),
array('1038614528','1039007743'),
array('1783627776','1784676351'),
array('2035023872','2035154943'),
array('2078801920','2079064063'),
array('-1950089216','-1948778497'),
array('-1425539072','-1425014785'),
array('-1236271104', '-1235419137'),
array('-770113536','-768606209'),
array('-569376768','-564133889'),);
$rand_key=mt_rand(0,9);
return $ip=long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
}
?>
