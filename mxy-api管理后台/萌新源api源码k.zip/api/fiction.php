<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
$b=$_GET['b'];
$c=$_GET['c'];
$list=file_get_contents("https://yd.sogou.com/h5/search?query=".$msg);
$list=str_replace("</em>", '', $list);
$list=str_replace("<em>", '', $list);
$list=str_replace("<h4 class=\"book-title\">' + obj.bookName + '<", '', $list);
$result = preg_match_all("/class=\"book-title\">(.*?)</",$list,$nute);
$je=$nute[1][0];
if($je==null)
{
echo "若梦没有搜到[".$msg."]";
}
else
if($b== null)
{
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[1][$x];
echo ($x+1)."：".$jec."\n";
}
echo "提示：发送以上序号选择";
}
else
if($b>10||$b<1)
{
echo "请按以上序号选择";
}
else
{
$b=$_GET['b'];
$b=($b-1);
preg_match_all("/data-echo=\"(.*?)\"/",$list,$bb1);
$b1=$bb1[1][$b];
$b1=str_replace("amp;", '', $b1);
preg_match_all("/<h4 class=\"book-title\">(.*?)</",$list,$bb2);
preg_match_all("/<p class=\"book-summary\">(.*?)</",$list,$bb3);
preg_match_all("/<span>(.*?)</",$list,$bb4);
preg_match_all("/span><span>(.*?)</",$list,$bb5);
preg_match_all("/<li stats='1' bkey=\"(.*?)\"/",$list,$bb6);
$b2=$bb2[1][$b];
$b3=$bb3[1][$b];
$b4=$bb4[1][$b];
$b5=$bb5[1][$b];
$b6=$bb6[1][$b];
echo "图片".$b1."\n小说名：".$b2."\n小说作者：".$b4."\n小说类型：".$b5."\n小说内容：".$b3."\n小说链接：https://yd.sogou.com/h5/cpt/detail?bkey=".$b6;
}
?>