<?php
header("Content-type: text/html; charset=UTF-8");
//
$name = $_GET["msg"];
$id = $_GET["id"];
$str = file_get_contents("http://mobilecdnbj.kugou.com/api/v3/rank/song?version=9209&ranktype=2&plat=0&pagesize=300&area_code=1&page=1&volid=36448&rankid=8888&with_res_tag=1");

//echo $str;exit;
$s=preg_match_all('/"320hash":"(.*?)"/',$str,$z);
$sui=range(0,$s);
shuffle($sui);
foreach($sui as $s);
$hash = $z[1][$s];
echo $hash;
$key = md5($hash . "kgcloud");
$cmd = '4';//为4则输出mp3,为3则输出m4a
$url = "http://trackercdn.kugou.com/i/?cmd=$cmd&hash=$hash&key=$key&pid=1&acceptMp3=1";
$r = 'http://www.kugou.com/webkugouplayer/?isopen=0&chl=yueku_index';
$u = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36';
$data = curl_get($url,array('IPHONE_UA'=>0,'REFERER'=>$r,'USERAGENT'=>$u));

echo $data;exit;
preg_match_all('/"url":"(.*?)"/',$data,$data);
$data=$data[1][0];
$data=str_replace('\\/','/',$data);



if(strpos($name,'我猜')!==false&&strpos($name,'开始猜歌')===false){
$name=str_replace('我猜','',$name);
$b=file_get_contents("data/caige/".$id.".json");
similar_text($name,$b,$xsd);
if($xsd<70)
{echo "抱歉，您所猜的歌名与需猜歌曲名有点点差距哦。\n\n当前所猜歌名".$name."与歌曲名相似度为：".$xsd."%\n以至于本宝宝都不能给你开后门啦！";die;}else{
$my_file = 'data/caige/'.$id.'.json';
$handle = fopen($my_file, 'w') or die('Cannot open file: '.$my_file);
fwrite($handle, $c);
if($hash==''){
echo "抱歉，获取出错了！\n请重试。";die;
}else{
echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="1" action="web" brief="猜歌" sourceMsgId="0" url="" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="http://shengapi.cn/api/caige.jpg" src="'.$lj.'" /><title>恭喜，猜对了</title><summary>请开始猜下面的歌曲名！〖'.$c.'〗</summary></item><source name="猜的名和歌曲名相似70%及以上即可" icon="https://url.cn/5rxwdzD" url="http://url.cn/5aSZ8Gc" action="app" a_actionData="com.tencent.qqmusic" i_actionData="tencent100497308://" appid="100497308" /></msg>';die;}}}
if(strpos($name,'开始猜歌')===false&&strpos($name,'我猜')===false){
echo "抱歉，格式错误。\n开始猜歌请发送：\n开始猜歌\nPS：猜歌成功将进入下一题。";
}else{
$my_file = 'data/caige/'.$id.'.json';
$handle = fopen($my_file, 'w') or die('Cannot open file: '.$my_file);
fwrite($handle, $c);
echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="1" action="web" brief="猜歌" sourceMsgId="0" url="" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="http://shengapi.cn/api/caige.jpg" src="'.$lj.'" /><title>开始猜歌〖'.$c.'〗</title><summary>请猜出歌曲名</summary></item><source name="猜的名和歌曲名相似70%及以上即可" icon="https://url.cn/5rxwdzD" url="http://url.cn/5aSZ8Gc" action="app" a_actionData="com.tencent.qqmusic" i_actionData="tencent100497308://" appid="100497308" /></msg>';
}




function curl_get($url, $array=array()){
$defaultOptions = array(
'IPHONE_UA'=>1,
'SSL'=>0,
'TOU'=>0,
'ADD_HEADER_ARRAY'=>0,
'POST'=>0,
'REFERER'=>0,
'USERAGENT'=>0,
'CURLOPT_FOLLOWLOCATION'=>0);
$array = array_merge($defaultOptions, $array);
$ch = curl_init($url);
if($array['SSL']){
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);}
if($array['IPHONE_UA']){
curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_1_2 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7D11 Safari/528.16'));
}if(is_array($array['ADD_HEADER_ARRAY'])){
curl_setopt($ch, CURLOPT_HTTPHEADER, $array['ADD_HEADER_ARRAY']);
}if ($array['POST']){
curl_setopt($ch, CURLOPT_POSTFIELDS, $array['POST']);
}if ($array['REFERER']){
curl_setopt($ch, CURLOPT_REFERER, $array['REFERER']);
}if($array['USERAGENT']){
curl_setopt($ch, CURLOPT_USERAGENT, $array['USERAGENT']);
}if($array['TOU']){
curl_setopt($ch, CURLOPT_HEADER, 1); //输出响应头
}if($array['CURLOPT_FOLLOWLOCATION'])
{
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);//自动跟踪跳转的链接 
}
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$get_url = curl_exec($ch);
curl_close($ch);
return $get_url;}


?>