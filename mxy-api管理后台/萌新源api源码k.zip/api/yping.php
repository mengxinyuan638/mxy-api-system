<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
$list=file_get_contents("http://43.250.238.179:9090/showData?callback=china_echarts");
$list=str_replace("value", "conNum", $list);
preg_match_all("/{\"name\":\"".$msg."\",\"conNum\":\"(.*?)\",\"susNum\":\"(.*?)\",\"deathNum\":\"(.*?)\",\"cureNum\":\"(.*?)\"/",$list,$aaa);
preg_match_all("/\"times\":\"截至(.*?)\",/",$list,$bbb);
$aa1=$aaa[1][0];
if($aa1==null||$msg==null)
{
echo "没有搜索到有关的信息";
}
else
{
$aa1=$aaa[1][0];
$bb1=$bbb[1][0];
$aa3=$aaa[3][0];
$aa4=$aaa[4][0];
//1确诊
//3死亡
//4治愈
echo "🌾查询地区：".$msg."\n";
echo "🌾目前确诊：".$aa1."\n";
echo "🌾目前死亡：".$aa3."\n";
echo "🌾目前治愈：".$aa4."\n";
echo "🌾更新时间：".$bb1."\n";
echo "🌾数据来自：人民网";
}
?>