<?php
header("Content-type:application/json;charset=utf-8");
 //统计

$b = $_GET['n'];
$m = $_GET[m];
$msg = $_GET['msg'];
$array=array('fanju' => '","page":1,"pagesize":20,"platform":"h5","search_type":"bangumi","main_ver":"v3","order":"totalrank"}',
'duanshipin' => '","page":1,"pagesize":100,"platform":"h5","search_type":"all","main_ver":"v3","order":"click","bangumi_num":3,"movie_num":3}');
$data=$array[$m];
if($data==""){echo "抱歉，参数m不正确或不存在！\nm=fanju时将返回番剧\nm=duanshipin时返回搜索视频。";exit;}
$data='{"keyword":"'.urlencode($msg).''.$data.'';
//获取开始，注册字段
$url="https://m.bilibili.com/search/searchengine"; 
list($return_code, $return_content) = http_post_data($url, $data);//return_code是http状态码
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $return_content);
$str=str_replace('\\/','/',$str);
function http_post_data($url, $data_string) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		"Content-Type: application/json; charset=utf-8",
		"Content-Length: " . strlen($data_string))
	);
	ob_start();
curl_exec($ch);
	$return_content = ob_get_contents();
	ob_end_clean();
	$return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
return array($return_code, $return_content);
}
//截取开始
//番剧
if($m=="fanju"){
$stre = '/{"styles":"(.*?)","status":(.*?),"typeurl":"(.*?)","spid":(.*?),"pubdate":(.*?),"newest_season":"(.*?)","evaluate":"(.*?)"(.*?)"cover":"(.*?)","is_finish":(.*?),"season_id":(.*?),"bgmlist":\[(.*?)\],"favorites":(.*?),"cv":"(.*?)","danmaku_count":(.*?),"staff":"(.*?)","play_count":(.*?),"hit_columns":\["title"\],"newest_ep_id":(.*?),"title":"(.*?)"/'; //1类型，3链接，http:9图链，16出品信息，19番剧名
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与".$msg."的相关番剧，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$ga=$trstr[19][$i];//番剧名
$gb=$trstr[1][$i];//类型
echo ($i+1)."：".$ga."--".$gb."\r";}
echo "\n搜索到与".$msg."相关的番剧信息共".$result."条，您可以点1～".$result."任一番剧。";}else{
$i=($b-1);
$ga=$trstr[19][$i];//直播间
$gb=$trstr[1][$i];//类型
$gc=$trstr[16][$i];//出品信息
$a=$trstr[9][$i];//图片链接
$a="http:".$a."";
$b=$trstr[3][$i];//链接
if(!$b == ' '){
die ('列表中暂无序号为『'.$b.'』的番剧，请输入存在的序号进行搜索。');}
echo "±","img=";
echo "".$a."±";
echo "番剧：".$ga."\n类型：".$gb."\n".$gc."\n播放链接：".$b."";exit;}}}
//短视频
if($m=="duanshipin"){
$str=str_replace('\\/','/',$str);
$stre = '/"title":"(.*?)","review":(.*?),"mid":(.*?),"is_union_video":(.*?),"rank_index":(.*?),"type":"video","arcrank":"(.*?)","play":(.*?),"pic":"(.*?)","description":"(.*?)","view_type":"(.*?)","video_review":(.*?),"is_pay":(.*?),"favorites":(.*?),"arcurl":"(.*?)","typeid":"(.*?)","author":"(.*?)","hit_columns":\["(.*?)"\],"typename":"(.*?)","aid":(.*?),"rec_tags":(.*?)}/'; //1标题，7播放量，http:8图链，11评论数，14链接，16上传者，17类型
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与".$msg."的相关视频，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$ga=$trstr[1][$i];//标题
$gb=$trstr[18][$i];//类型
echo ($i+1)."：".$ga."--".$gb."\r";}
echo "\n搜索到与".$msg."相关的视频信息共".$result."条，您可以点1～".$result."任一视频。";}else{
$i=($b-1);
$ga=$trstr[1][$i];//标题
$gb=$trstr[18][$i];//类型
$gc=$trstr[7][$i];//播放量
$gd=$trstr[11][$i];//评论数
$a=$trstr[8][$i];//图片链接
$a="http:".$a."";
$b=$trstr[14][$i];//链接
 //1标题，7播放量，http:8图链，11评论数，14链接，16上传者，17类型
if(!$b == ' '){
die ('列表中暂无序号为『'.$b.'』的视频，请输入存在的序号进行搜索。');}
echo "±","img=";
echo "".$a."±";
echo "视频：".$ga."\n类型：".$gb."\n播放量：".$gc."\n评论数：".$gd."\n播放链接：".$b."";}}}
?>