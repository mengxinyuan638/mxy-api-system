<?php
 //统计

$msg = $_GET['msg'];
$b = $_GET['n'];
$str = 'http://mobilecdn.kugou.com/api/v3/search/song?format=jsonp&keyword='.$msg.'&page=1&pagesize=400&showtype=1'; 
$str=file_get_contents($str);
$stre = "/songname_original\":\"(.*?)\",\"singername\":\"(.*?)\"(.*?)\"hash\":\"(.*?)\"/"; 
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与【$_GET['msg'] 】的相关歌词，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$ga=$trstr[1][$i];//获取歌名
$gb=$trstr[2][$i];//获取歌手
echo ($i+1)."：".$ga."--".$gb."\n";}
echo "共搜索到与【$_GET['msg'] 】的相关歌词$result 条，您可以点1～$result 任一歌词。";}else{
//
$i=($b-1);
$hash=$trstr[4][$i];//320hash
if($hash== ""){
echo "抱歉，无此歌曲歌词。";
}else{
$l="http://m.kugou.com/app/i/krc.php?cmd=100&hash=$hash&timelength=246000";
$str = file_get_contents($l);
$str=str_replace(':','',$str);
$str=str_replace('[','<',$str);
$str=str_replace(']','>',$str);
$stre = '/<(.*?)>/'; 
$result = preg_match_all($stre,$str,$trstr);
for( $i = 10 ; $i < $result && $i < 10000 ; $i ++ ){
$ga=$trstr[1][$i];//获取歌名
$str=str_replace('<'.$ga.'>','|',$str);
}
$z="|$str |";
$z =explode("|", $z);
$xh = ($_GET[d]);
if($xh==1){
for( $i = 0 ; $i < (count($z)/3) ; $i ++ ){
echo $z[$i];
if ($i< (count($z)/3)-1){
echo "";
}}}
elseif($xh==2){
for( $i = ((count($z)/3)+0.7); $i < ((count($z)/3)*2); $i ++ ){
echo $z[$i];
if ($i< ((count($z)/3)*2)-1){
echo "";}}}
elseif($xh==3){
for( $i = (((count($z)/3)*2)+0.7); $i < count($z); $i ++ )
{
echo $z[$i];
if ($i< count($z)-1){
echo "";
}}}
}
}
}
?>