<?php
header("Content-type: text/html; charset=UTF-8");

$msg=$_GET["msg"];
$msg=str_replace('/','%2F',$msg);
$msg=str_replace(':','%3A',$msg);
$a = file_get_contents("http://".$_SERVER['HTTP_HOST']."/fapi/api.php?type=zhiwushibie&msg=".$msg."");
$a = mb_convert_encoding($a,'UTF-8','GBK');
preg_match_all('/{"names":"(.*?)"/',$a,$c);
$f=$c[1][0];//植物名
$a = file_get_contents("http://".$_SERVER['HTTP_HOST']."/fapi/api.php?type=sgbaike&msg=".$f."");
preg_match_all('/category":\["(.*?)"\]/',$a,$c);
$f=$c[1][0];
$f=str_replace('","','、',$f);
$json = json_decode($a, true);
$c=$json["baikeMsg"];//判断
$lj=$json["link"];//链接
$t=$json["image"];//图片
$r=$json["content"];//百科内容
$g=$json["cardItem"];//更多
$g=str_replace('|','\\n',$g);
if($c=="词条不存在"){
echo "抱歉，找不到与".$f."有关的信息。";
}else{
echo '[img:url="'.$t.'"]';
echo "".$r."\\n".$f."\\n".$g."\\n\\n更多：".$lj."";}
?>