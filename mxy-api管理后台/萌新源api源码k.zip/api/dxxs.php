<?php
header("Content-type: text/html; charset=UTF-8");
       $name = $_GET['msg'];
       
       
       $d = file_get_contents("compress.zlib://http://ubook.3g.qq.com/8/search?key=".$name."");
       
       
preg_match_all("/updateDate\":\"(.*?)\",\"totalWords\":\"(.*?)\",\"author\":\"(.*?)\",\"finished\":\"(.*?)\",\"updateTime\":\"(.*?)\",\"title\":\"(.*?)\",\"type\":\"(.*?)\",\"lastChapterName\":\"(.*?)\",\"lastChapter\":\"(.*?)\",\"categoryInfoV4\":\"(.*?)\",\"cover\":\"(.*?)\",\"categoryInfoV4Slave\":\"\",\"id\":\"(.*?)\",\"pushName\":\"\",\"cat3Info\":\"(.*?)\"/",$d,$y);

//"updateDate\":\"2018-09-19 09:59:53\",\"totalWords\":\"5327536\",\"author\":\"天蚕土豆\",\"finished\":\"0\",\"updateTime\":\"1年前\",\"title\":\"斗破苍穹\",\"type\":\"0\",\"lastChapterName\":\"《斗破苍穹：斗帝之路》手游·角色传记（下）\",\"lastChapter\":\"1663\",\"categoryInfoV4\":\"20000:小说:小说,20001:玄幻:玄幻,20003:异世大陆:异世\",\"cover\":\"http:\/\/wfqqreader-1252317822.image.myqcloud.com\/cover\/914\/468914\/s_468914.jpg\",\"categoryInfoV4Slave\":\"\",\"id\":\"468914\",\"pushName\":\"\",\"cat3Info\":\"20000:小说:小说,20001:玄幻:玄幻,20003:异世大陆:异世\"/},
     
     
       $xy = $y[1][0];
       $sj = $y[5][0];
       $g = $y[6][0];
       $id = $y[12][0];
       $l = $y[8][0];
       $z = $y[9][0];
       $m = $y[10][0];
       $sl = $y[12][0];
       $js = $y[13][0];
       $zj = $y[15][0];
       
       
       $o = file_get_contents("compress.zlib://http://ubook.qq.com/8/read.html?bid=".$id."&cid=1&bid=".$id."&b_f=&searchClick=".$name."");
       

$string = str_replace(array('<\/b>', '<b>'), array('', ''), $m);
$jl = str_replace(array(':', '0', '1', '2', '3', '4', '4', '6', '7', '8', '9'), array('', ''), $l);

echo "书名:$string\n\n作者:$z\n\n类型:$jl\n\n简介:$js\n\n最近更新时间:$xy$sj\n\n已更新至:$zj 【全本共$g 章 共$sl 字】\n\n点此链接:http://ubook.qq.com/8/read.html?bid=$id&cid=1&bid=$id&b_f=&searchClick=$name\n进入阅读";


?>