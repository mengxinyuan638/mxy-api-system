<?php
$a = ($_GET['m']); 


$arr=range(0,43);
shuffle($arr);
foreach($arr as $values)
$k = $values;

$str = 'http://elf.static.maibaapp.com/content/json/avatars/li-15-'.$k.'.json'; 
$html=file_get_contents($str);


$result = preg_match_all('/(.*?)in\":\"(.*?)\"(.*?)/', $html, $arr);

        $arr=range(0,$result); 
        shuffle($arr); 
        foreach($arr as $values); 
        $str = "/in\":\"(.*?)\"/"; 

        preg_match_all($str,$html,$trstr); 
        
        if($a==1) 
{ 
         echo "http://webimg.maibaapp.com/content/img/avatars/";
        echo "".$trstr[1][$values].""; 
} 
else 
{ 

        
        

if($a==2) 
{ 
$img = "http://webimg.maibaapp.com/content/img/avatars/".$trstr[1][$values]."";
$img = file_get_contents($img,true);
//使用图片头输出浏览器
header("Content-Type: image/jpeg;text/html; charset=utf-8");
echo $img;
exit;

} 
else 
{ 



        echo "±img=http://webimg.maibaapp.com/content/img/avatars/";
        echo "".$trstr[1][$values]."±"; 
        }
        
        
}


?>