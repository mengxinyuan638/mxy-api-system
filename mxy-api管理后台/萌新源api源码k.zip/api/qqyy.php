<?php

$id = $_GET["id"];

$songname = $_GET["msg"];

if ($id == null) {
    $str = get_curl("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?aggr=0&cr=1&flag_qc=0&p={$p}&n={$num}&w=" . urlencode($songname));
    $str = substr($str, 9, -1);
    $json = json_decode($str, true);
    if ($json["code"] == 0) {
        $list = $json["data"]["song"]["list"];
        if (empty($list[0])) {
            echo "无搜索结果";
        } else {
            for ($i = 0; $i < 10; $i++) {
                $jsonarray = $list[$i];
                $songname = $jsonarray["songname"];
                $songid = $jsonarray["songid"];
                $singername = $jsonarray["singer"][0]["name"];
                echo $i + 1;
                echo "．";
                echo $songname;
                echo "-";
                echo $singername;
                if ($i + 1 != count($list)) {
                    echo "\n";
                }
            }
                 echo "\n";
        echo "提示：发送：选[数字]";
        }
    }
} else if ($id >= 1 & $id !=null) {
    $str = get_curl("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?aggr=0&cr=1&flag_qc=0&p={$p}&n={$num}&w=" . urlencode($songname));
    $str = substr($str, 9, -1);
    $json = json_decode($str, true);
    if ($json["code"] == 0) {
        $list = $json["data"]["song"]["list"];
        if (empty($list[0])) {
            echo "搜索无结果";
        } else {
            $jsonarray = $list[$id-1];
            $songid = $jsonarray["songid"];
            $albummid = $jsonarray["albummid"];
            $songmid = $jsonarray["songmid"];
            $songname = $jsonarray["songname"];
            $singer = $jsonarray["singer"][0]["name"];
            $singername = str_replace('&', ' ',$singer);
            $dataqq = get_curl("https://api.qq.jsososo.com/song/urls?id=" . urlencode($songmid));
            $jsonqq = json_decode($dataqq, true);
            $lj = str_replace('&', '&amp;', $jsonqq["data"][$songmid]);
         echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="12345" action="dabai" brief="[分享]' .  $songname . '" sourceMsgId="0" url="https://youxi.vip.qq.com/m/act" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="http://y.gtimg.cn/music/photo_new/T002R150x150M000' . $albummid . '.jpg" src="' . $lj . '" /><title>' .  $songname . '</title><summary>' . $singername . '</summary></item><source name="" icon="" action="" appid="-1" /></msg>';
        }
    } else {
        echo "点歌失败";
        echo "\n";
        echo "提示：code：" . $json["code"];
    }
}
function get_curl($url, $post = 0, $referer = 1, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $httpheader[] = "Accept:*/*";
    $httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
    $httpheader[] = "Connection:close";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if ($referer) {
        if ($referer == 1) {
            curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_HOST']);
        } else {
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    } else {
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.4.2; NoxW Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36');
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}