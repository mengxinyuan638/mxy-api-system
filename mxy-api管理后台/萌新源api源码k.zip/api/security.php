<php
/**
 * 提交方式GET
 * 请求参数：domain（域名url）
 * 示例：index.php?domain=blog.oioweb.cn
 */
error_reporting(0);
header('Author: QQ:599928887');
header('Access-Control-Allow-Origin:*');
function curl($url,$post_data){
    $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
    if($ip != ""){
        $arr = explode(",",$ip);
        $ip = $arr[0];
    }else{
        $ip = $_SERVER["REMOTE_ADDR"];
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3600);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:'.$ip, 'CLIENT-IP:'.$ip));
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS,$post_data);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
!empty($_GET['url']) ? $_GET['url'] : exit("{\"msg\":\"请填写网址\",\"code\":\"0\",\"data\":\"\"}");
$post_data = [
    "domain"=>$_GET['url']
];
$jsoj = json_decode(curl("https://www.toolnb.com/Tools/Api/domainsafe.html",$post_data));
exit(json_encode(
    [
        "msg"=>"ok",
        "url"=>$jsoj->data->domain,
        "name"=>[
            1=> "未知",
            2=> "危险",
            3 => "安全"
        ],
        "nameStyle"=>[
            "qq"=>$jsoj->data->qq,
            "wx"=>$jsoj->data->wx
        ]
    ]
,JSON_UNESCAPED_UNICODE));
