<?php
include("./tongji/tongji.php"); //统计
$name = urlencode($_GET['msg']);
$data = file_get_contents("compress.zlib://http://www.tuling123.com/openapi/api?key=9078f28c18414afabe679d3cb41f38a4&info=".$name."");
preg_match_all("/{\"code\":(.*?),\"text\":\"(.*?)\"}/",$data,$v);
echo $v[2][0];
?>