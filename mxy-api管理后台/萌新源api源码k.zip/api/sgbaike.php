<?php
$a = file_get_contents("http://pic.sogou.com/ris/risBaike?query=1&name=".$_GET["msg"]."&baike_xiaoqi=false");
preg_match_all('/category":\["(.*?)"\]/',$a,$c);
$f=$c[1][0];
$f=str_replace('","','、',$f);
$json = json_decode($a, true);
$c=$json["baikeMsg"];//判断
$lj=$json["link"];//链接
$t=$json["image"];//图片
$r=$json["content"];//百科内容
$g=$json["cardItem"];//更多
$g=str_replace('|','\\n',$g);
if($c=="词条不存在"){
echo "抱歉，不存在词条".$_GET["msg"]."的信息。";
}else{
echo '±img='.$t.'±';
echo "图片:".$r."\n".$f."\n".$g."\n\n更多：".$lj."";
}?>