<?php 
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$name = urlencode($_GET['msg']); 
$a = urlencode($_GET[m]); 
$html = file_get_contents("./shouji/miyu.txt"); 
$result = preg_match_all('/topic":"(.*?)",answer":"(.*?)",type":"(.*?)",ps":"(.*?)"/', $html, $arr);
if($result== 0){
echo "抱歉，出错了！请至官网反馈您所遇到的问题。";
}else{
$arrr=range(0,$result); 
shuffle($arrr); 
foreach($arrr as $values); 
echo "谜题：".$arr[1][$values]."\n谜底：".$arr[2][$values]."\n类型：".$arr[3][$values]."\n提示：".$arr[4][$values]."";}
?>