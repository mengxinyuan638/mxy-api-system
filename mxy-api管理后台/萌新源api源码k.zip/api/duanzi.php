<?php
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$html = file_get_contents("./shouji/duanzi.txt"); 
$result = preg_match_all('/"content":"(.*?)"/', $html, $arr);
if($result== 0){
echo "抱歉，出错了！";
}else{
$arrr=range(0,$result); 
shuffle($arrr); 
foreach($arrr as $values); 
echo $arr[1][$values];
}
?>