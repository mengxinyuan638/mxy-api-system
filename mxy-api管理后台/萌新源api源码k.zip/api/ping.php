<?php
$ip=$_GET["ip"];
$res0 = file_get_contents("http://api.yum6.cn/ping.php?host=$ip");
$arr = json_decode($res0, true);
$cc=$arr["state"];
$a=$arr["host"];$b=$arr["ip"];
$c=$arr["ping_time_max"];
$d=$arr["ping_time_min"];
$f=$arr["location"];
if($arr["state"]=="1000"){
echo "网站域名:",$a,"\n","网站IP:",$b,"\n","最大延迟:",$c,"\n","最小延迟:",$d,"\n","服务器归属:",$f;
exit;}
echo "请查看是否有误";
?>