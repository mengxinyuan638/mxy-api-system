<?php
header("Content-type: text/html; charset=UTF-8");
 //统计

$xxxff = $_GET['msg'];
$name = urlencode($_GET['msg']);
$b = urlencode($_GET['n']);
$str = file_get_contents("compress.zlib://http://www.tuku33.com/index.php/vosh/-------------.html?wd=$name");
$stre = "/<a class=\"yun-link\" href=\"(.*?)\/\" title=\"(.*?)\"/"; 
$result = preg_match_all($stre,$str,$trstr);
$y = "/class=\"actor\">(.*?)</"; 
preg_match_all($y,$str,$y);
if($result== 0){
echo "搜索不到与【$xxxff】的相关视频，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 5 ; $i ++ ){
$ga=$trstr[2][$i];//获取名
$gb=$y[1][$i];//主演
echo ($i+1)."：".$ga."\r".$gb."\r\r";}
echo "共搜索到与【$xxxff 】的相关视频$result 条，您可以点1～$result 任一作品。";
}else{
$i=($b-1);
$ga=$trstr[2][$i];//获取名
$gb=$y[1][$i];//主演
$zj=$trstr[1][$i];//链接
if(!$zj == ' '){
die ('列表中暂无序号为『'.$b.'』的福利视频，请输入存在的序号进行搜索。');}
echo "名称:$ga\n\n$gb\n\n点击以下链接：\n1、http://www.tuku33.com$zj\n\n2、http://www.tuku33.com$zj\n观看";}}
?>