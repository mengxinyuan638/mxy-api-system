<?php
header("Content-type: text/html; charset=UTF-8");
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$name = urlencode($_GET['msg']);
$b = urlencode($_GET['n']);
$str = file_get_contents("compress.zlib://http://mapp.qzone.qq.com/cgi-bin/mapp/mapp_search_result?keyword=$name");
$stre = '/iconUrl":"(.*?)"(.*?)name":"(.*?)","pName":"(.*?)","prelen":(.*?),"shortDes":"(.*?)","size":"(.*?)","sourcetype":(.*?)"url":"(.*?)","userCount":(.*?),"versionCode":(.*?),"versionName":"(.*?)"/'; 
$result = preg_match_all($stre,$str,$trstr);//1软件名，4为游戏类型，5大小，7链接，8下载次数，10已更新至        
if($result== 0){
echo "搜索不到与".$_GET['msg']."的相关应用，请稍后重试或换个关键词试试。";
}else{
if($b== null)
{
for( $i = 0 ; $i < $result && $i < 7 ; $i ++ )
{
$a=$trstr[3][$i];//获取名
$c=$trstr[7][$i];//大小
$b=$trstr[10][$i];//下载次数
echo ($i+1)."：".$a."   下载次数：".$b."   大小：".$c."\r\r";
}
echo "共搜索到与".$_GET['msg']."的相关软件$result 条，您可以点1～".$result."任一软件。";
}else{
$i=($b-1);
$t=$trstr[1][$i];
$a=$trstr[3][$i];//获取名
$d=$trstr[6][$i];
$c=$trstr[7][$i];//大小
$e=$trstr[9][$i];
$b=$trstr[10][$i];//下载次数
$f=$trstr[12][$i];
if(!$e == ' '){
die ('抱歉，出错了！');
}
echo "图片:".$t."名称:$a类型：$d  已更新至：$f\n\n下载次数：$b  大小：$c\n\n点击链接：$e 下载";
}}?>