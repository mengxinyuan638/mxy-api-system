<?php 
    $arr=file('wenben/tg.txt');
    $n=rand(0,count($arr));
    echo "舔狗日记
    ".date("Y年m月d日")." 晴
    ".$arr[$n];
    ?>