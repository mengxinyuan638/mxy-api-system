<?php
$name = urlencode($_GET["msg"]);

if($name==""){echo "抱歉，输入为空。";exit;}
$html = file_get_contents("http://app.dict.baidu.com/dictapp/v3/s?osVersionName=9&model=meizu_16s&ptype=zici&source=wenzi&versionName=2.7.3&deviceid=02%3A00%3A00%3A00%3A00%3A00%7C867401041651110&wd=".$name."&versionCode=55&platform=Android");
function replace_unicode_escape_sequence($match){
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');}
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);
$str=str_replace(' ','',$str);
preg_match_all('/"stroke_order_gif":\["(.*?)"/',$str,$q);
$t=$q[1][0];
$t=str_replace('\\/','/',$t);
if($t!=""){echo "图片：".$t."\n";}
preg_match_all('/"pinyin":\["(.*?)"/',$str,$q);
$py=$q[1][0];
if($py!=""){echo "".$_GET["msg"]."\n拼音：".$py."";}
//笔画
preg_match_all('/"stroke_order":\[(.*?)\]/',$str,$q);
$bh=$q[1][0];
$s = preg_match_all('/{"img":"(.*?)","value":"(.*?)"}/',$bh,$bh1);
if($s!="0"){
echo "\n笔画顺序：";
for( $i = 0 ; $i < $s ; $i ++ )
{
$bh=$bh1[2][$i];
$bh=str_replace('\\/','或',$bh);
echo $bh." ";
}}
preg_match_all('/"struct_type":\["(.*?)"/',$str,$q);
$j=$q[1][0];
if($j!=""){echo "\n字形：".$j."";}
preg_match_all('/"traditional":\["(.*?)"/',$str,$q);
$f=$q[1][0];
if($f!=""){echo "\n繁体字：".$f."";}
preg_match_all('/"word_wubi":\["(.*?)"/',$str,$q);
$wb=$q[1][0];
if($wb!=""){echo "\n五笔输入：".$wb."";}
preg_match_all('/{"baike_mean":"(.*?)","baike_url":"(.*?)"/',$str,$q);
$bk=$q[1][0];
$bkl=$q[2][0];
$bkl=str_replace('\\/','/',$bkl);
if($bk!=""){echo "\n释意：".$bk."";}
if($bkl!=""){echo "\n更多：".$bkl."";}
?>