<?php
 //统计

$name = urlencode($_GET['msg']);
$b = $_GET['n'];
$str = "https://c.y.qq.com/soso/fcgi-bin/client_search_cp?ct=24&qqmusic_ver=1298&remoteplace=txt.yqq.mv&searchid=137147982373372006&aggr=0&catZhida=1&lossless=0&sem=1&t=12&p=1&n=28&g_tk=257422069&jsonpCallback=MusicJsonCallback6287496927839289&loginUin=1075888691&hostUin=0&format=jsonp&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&w=".$name.""; 
$str=file_get_contents($str);

/*
{"docid":"6937450681958954144","duration":83,"msg":"","mvName_hilight":"美女浴室献唱（&lt;em&gt;呵呵&lt;/em&gt;） (饭制版)","mv_id":842463,"mv_name":"美女浴室献唱（呵呵） (饭制版)","mv_pic_url":"http://y.gtimg.cn/music/photo_new/T015R640x360M0000027nyID0j1m7P.jpg","pay":0,"play_count":1947,"publish_date":"2013-07-10","singerMID":"002yv8uj0fr0jY","singerName_hilight":"动画视频","singer_list":[{"id":1159586,"mid":"002yv8uj0fr0jY","name":"动画视频","name_hilight":"动画视频"}],"singer_name":"动画视频","singerid":1159586,"type":0,"uploader_nick":"黑山老妖","uploader_uin":"434393316","v_id":"a0021imbj5c","version":7,"video_switch":31}

duration\":(.*?),(.*?)mv_name\":\"(.*?)\"(.*?)mv_pic_url\":\"(.*?)\"(.*?)singer_name\":\"(.*?)\"(.*?)v_id\":\"(.*?)\"(.*?)singerName_hilight\":\"(.*?)\"
*/

$stre = '/{"docid":"(.*?)","duration":(.*?),"msg":"(.*?)","mvName_hilight":"(.*?)","mv_id":(.*?),"mv_name":"(.*?)","mv_pic_url":"(.*?)","pay":(.*?),"play_count":(.*?),"publish_date":"(.*?)","singerMID":"(.*?)","singerName_hilight":"(.*?)","singer_list":\[{"id":(.*?),"mid":"(.*?)","name":"(.*?)","name_hilight":"(.*?)"}\],"singer_name":"(.*?)","singerid":(.*?),"type":(.*?),"uploader_nick":"(.*?)","uploader_uin":"(.*?)","v_id":"(.*?)","version":(.*?),"video_switch":(.*?)}/'; 

$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与【$_GET['msg'] 】的相关mv作品，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$ga=$trstr[6][$i];//获取mv名
$gb=$trstr[12][$i];//获取来源
echo ($i+1)."：".$ga."--".$gb."\r";}
echo "\n搜索到与【$_GET['msg'] 】相关的mv共$result 条，您可以点1～$result 任一mv。";}else{
$i=($b-1);
$ga=$trstr[6][$i];//获取mv名
$gb=$trstr[12][$i];//获取来源
$b1=$trstr[2][$i];//获取duration
$a=$trstr[7][$i];//图片链接
$b=$trstr[22][$i];//id

              if(!$b == ' '){
die ('列表中暂无序号为『'.$b.'』的mv，请输入存在的序号进行搜索。');
}
echo "card:1<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><msg serviceID=\"1\" templateID=\"1\" action=\"web\" brief=\"[MV]$ga\" sourcePublicUin=\"1828222534\" sourceMsgId=\"0\" url=\"\" flag=\"1\" adverSign=\"0\" createTime=\"2099-01-01\" multiMsgFlag=\"0\"><item layout=\"5\"><video cover=\"$a\" vInfo=\"$b\" tInfo=\"$b\" preStartPosi=\"0\" preTime=\"$b1\" preWidth=\"848\" preHeight=\"480\" fullTime=\"$b1\" busiType=\"1\" aID=\"\" isJump2Web=\"0\" /><title>$ga  $gb</title></item><source name=\"MV\" icon=\"https://q.url.cn/s/jBJuV\" url=\"\" action=\"web\" appid=\"\" /></msg>";


}}

?>