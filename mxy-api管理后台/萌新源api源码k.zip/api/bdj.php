<?php
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$html=file_get_contents("http://d.api.budejie.com/v2/topic/list/29/29330768-28165283/budejie-android-8.0.5/0-25.json?jdk=1&market=b-meizu&uid=&ver=8.0.5&appname=budejie&t=1553618126280&client=android&from=android&udid=86845503329529&device=16th%20Plus");
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');}
$html = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);
$a = preg_match_all('/"text": "(.*?)"/', $html, $trstr);
$arr=range(0,$result); 
shuffle($arr); 
foreach($arr as $values); 
$w = "".$trstr[1][$values]."";
if($a==0){
echo "抱歉，出错了";
}else {
echo $w;
}?>