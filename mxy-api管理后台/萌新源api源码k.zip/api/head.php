<?php
header("Content-type: text/html; charset=utf-8");
$type=$_GET["type"];
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,"https://api.uomg.com/api/rand.avatar?sort=$type&format=json");
curl_setopt($curl,CURLOPT_TIMEOUT,30);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
$return=curl_exec($curl);
curl_close($curl);
$return=json_decode($return,true);
if($return["code"]==1){
echo "±img=".$return["imgurl"]."±";
}
?>
