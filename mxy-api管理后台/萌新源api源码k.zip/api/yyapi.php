<?php

class TencentMusicAPI{
    // General
    protected $_USERAGENT='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.30 Safari/537.36';
    protected $_COOKIE='qqmusic_uin=12345678; qqmusic_key=12345678; qqmusic_fromtag=30; ts_last=y.qq.com/portal/player.html;';
    protected $_REFERER='http://y.qq.com/portal/player.html';
    // CURL
    protected function curl($url,$data=null){
        $curl=curl_init();
        curl_setopt($curl,CURLOPT_URL,$url);
        if($data){
            if(is_array($data))$data=http_build_query($data);
            curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
            curl_setopt($curl,CURLOPT_POST,1);
        }
        
        curl_setopt($curl,CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl,CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl,CURLOPT_REFERER,$this->_REFERER);
        curl_setopt($curl,CURLOPT_COOKIE,$this->_COOKIE);
        curl_setopt($curl,CURLOPT_USERAGENT,$this->_USERAGENT);
        $result=curl_exec($curl);
        curl_close($curl);
        return $result;
    }
    // main function
    public function search($s,$limit=30,$offset=0,$type=1){
        $url='http://c.y.qq.com/soso/fcgi-bin/search_cp?';
        $data=array(
            'p'=>$offset+1,
            'n'=>$limit,
            'w'=>$s,
            'aggr'=>1,
            'lossless'=>1,
            'cr'=>1,
        );
        return substr($this->curl($url.http_build_query($data)),9,-1);
    }
    public function artist($artist_mid){
        $url='http://c.y.qq.com/v8/fcg-bin/fcg_v8_singer_track_cp.fcg?';
        $data=array(
            'singermid'=>$artist_mid,
            'order'=>'listen',
            'begin'=>0,
            'num'=>30,
        );
        return substr($this->curl($url.http_build_query($data)),0,-1);
    }
    public function album($album_mid){
        $url='http://c.y.qq.com/v8/fcg-bin/fcg_v8_album_info_cp.fcg?';
        $data=array(
            'albummid'=>$album_mid,
        );
        return substr($this->curl($url.http_build_query($data)),1);
    }
    public function detail($song_mid){
        $url='http://c.y.qq.com/v8/fcg-bin/fcg_play_single_song.fcg?';
        $data=array(
            'songmid'=>$song_mid,
            'format'=>'json',
        );
        return $this->curl($url.http_build_query($data));
    }
    
    public function get_millisecond(){
        list($usec, $sec) = explode(" ", microtime());
        $msec=round($usec*1000);
        return $msec;
        }
        
    private function genkey($song_mid){
        //$this->_GUID=rand(1,2147483647)*(microtime()*1000)%10000000000;
        $this->_GUID = round((mt_rand()/mt_getrandmax())*2147483647) * $this->get_millisecond() % 10000000000;
        $post = '{"comm":{"uin":"1486191867","authst":"Q_H_L_2GkSAt50ee8gzIxBfwVxm4zic4SoFWtBe7jn4KeVgsdv-i16zip19RIMmP_JJ59","mina":1,"appid":1109523715,"ct":29},"urlReq":{"module":"vkey.GetVkeyServer","method":"CgiGetVkey","param":{"guid":"'.$this->_GUID.'","songmid":["'.$song_mid.'"],"songtype":[0],"uin":"1486191867","loginflag":1,"platform":"23","h5to":"speed"}}}';
        $data=$this->curl("https://u.y.qq.com/cgi-bin/musicu.fcg",$post);
        preg_match_all('/"purl":"(.*?)"/',$data,$mp);
preg_match_all('/"testfilewifi":"(.*?)"/',$data,$mp1);
if($mp[1][0]==null){
$this->_KEY=$mp1[1][0];
}else{
$this->_KEY=$mp[1][0];
}
        $this->_CDN='http://dl.stream.qqmusic.qq.com/';
    }
    public function url($song_mid){
        self::genkey($song_mid);

        $url=$this->_CDN.$this->_KEY;

        return $url;
    }
    public function playlist($playlist_id){
        $url='http://c.y.qq.com/qzone/fcg-bin/fcg_ucc_getcdinfo_byids_cp.fcg?';
        $data=array(
            'disstid'=>$playlist_id,
            'utf8'=>1,
            'type'=>1,
        );
        return substr($this->curl($url.http_build_query($data)),13,-1);
    }
    public function lyric($song_mid){
        $url='http://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric.fcg?';
        $data=array(
            'songmid'=>$song_mid,
            'nobase64'=>'1',
        );
        return substr($this->curl($url.http_build_query($data)),18,-1);
    }
}
$api = new TencentMusicAPI();
if($_GET['mid']==""){

echo $api->lyric($_GET['id']);exit;}

echo $api->url($_GET['mid']);

?>