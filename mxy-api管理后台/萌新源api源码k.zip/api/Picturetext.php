<?php
header("Content-type: text/html; charset=utf-8");
	$ul = 'https://aip.baidubce.com/oauth/2.0/token';
    $post_data['grant_type']       = 'client_credentials';
    $post_data['client_id']      = '';//API Key
    $post_data['client_secret'] = '';//Secret Key
    $o = "";
    foreach ( $post_data as $k => $v ) 
    {
    	$o.= "$k=" . urlencode( $v ). "&" ;
    }
    function post($url = '', $param = '') {
        if (empty($url) || empty($param)) {
            return false;
        }
        
        $postUrl = $url;
        $curlPost = $param;
        $curl = curl_init();//��ʼ��curl
        curl_setopt($curl, CURLOPT_URL,$postUrl);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($curl);
        curl_close($curl);
        
        return $data;
    }
    $post_data = substr($o,0,-1);
    $res = post($ul, $post_data);
    $json1=json_decode($res);
    $token = $json1->access_token;
function request_post($url = '', $param = '')
{
    if (empty($url) || empty($param)) {
        return false;
    }

    $postUrl = $url;
    $curlPost = $param;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $postUrl);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
    $data = curl_exec($curl);
    curl_close($curl);

    return $data;
}
//    $token="24.8781d7f0bf8c9e2d6d8cf984138664d7.2592000.1616695569.282335-23690485";
$url = 'https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic?access_token=' . $token;
$bodys = array(
    'url' =>$_GET["msg"]
);
$res = json_decode(request_post($url, $bodys));

for($i=0;$i<count($res->words_result);$i++){
$f.=$res->words_result[$i]->words;
}
echo $f;
?>