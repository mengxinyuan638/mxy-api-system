<?php
header("Content-type: text/html; charset=utf-8");
$time=date("md");
$list=file_get_contents("https://lishishangdejintian.51240.com/".$time."__lishishangdejintian/");
preg_match_all("/<ul class=\"list\">(.*?)<\/li><\/ul>/",$list,$lit);
$lit=$lit[1][0];
$lit=str_replace("&nbsp;",'',$lit);
$result = preg_match_all("/<li>(.*?)<a href='(.*?)' target='_blank'>(.*?)<\/a>/",$lit,$nute);
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[3][$x];
$je=$nute[1][$x];
echo ($x+1)."：".$je."-".$jec."\n";
}
echo "注意：由内容过长，只显示10个列";
?>