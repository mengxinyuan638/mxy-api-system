<?php
$msg = $_GET['msg'];
$A=file_get_contents("http://api.qingyunke.com/api.php?key=free&appid=0&msg=".$msg."");
$B=str_replace("{br}","\\n","$A");
$json=json_decode($B, true);
$txt=$json["content"];//����
echo $txt;
?>