<?php
header("Content-type: text/html; charset=UTF-8");
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
       $name = urlencode($_GET['msg']);
       if(is_numeric($name)){   
$data = file_get_contents("compress.zlib://http://qzone-music.qq.com/fcg-bin/fcg_vip_getlevel.fcg?json=1&uin=".$name."");

$d = file_get_contents("compress.zlib://http://i.itpk.cn/api.php?question=@qq".$name."");


preg_match_all("/(.*?){\"code\":0, \"subcode\":(.*?), level:(.*?),vip:(.*?),score:(.*?),place:(.*?),payway:(.*?),isyear:(.*?),vendor:\"(.*?)\"}(.*?)/",$data,$v);


$w = $v[4][0];//判断是否是会员
$m = $v[3][0];//等级
$q = $v[5][0];//成长值
$x = $v[8][0];//是否是年费

echo "±img";
echo "=http://qlogo3.store.qq.com/qzone/".$name."/".$name."/100±";

echo "$d";

if($w==0) 
{ 
} 
else 
{ 



if($x==0) 
{ 
echo "\n\n绿钻等级：$m\n成长值：$q\n是否年费：否";
} 
else 
{ 
echo "\n\n\n\n绿钻等级：$m\n成长值：$q\n是否年费：是";

}


}
}else{


echo "请输入数字。";
}


?>