<?php
$w=date('w'); 
$week=array( 
    "0"=>"星期日", 
    "1"=>"星期一", 
    "2"=>"星期二", 
    "3"=>"星期三", 
    "4"=>"星期四", 
    "5"=>"星期五", 
    "6"=>"星期六" 
); 
$asd=date("d")+1;
$jec=date("H");
if($jec=='16'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo date("H")+8;
echo date(":i:s  $week[$w]");
}else
if($jec=='17'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 1;
echo date(":i:s  $week[$w]");
}else
if($jec=='18'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 2;
echo date(":i:s  $week[$w]");
}else
if($jec=='19'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 3;
echo date(":i:s  $week[$w]");
}else
if($jec=='20'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 4;
echo date(":i:s  $week[$w]");
}else
if($jec=='21'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 5;
echo date(":i:s  $week[$w]");
}else
if($jec=='22'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 6;
echo date(":i:s  $week[$w]");
}else
if($jec=='23'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 7;
echo date(":i:s  $week[$w]");
}else
if($jec=='24'){
echo date("现在时间:\rY年m月");
echo ''.$asd.'日\r';
echo 8;
echo date(":i:s  $week[$w]");
}else
if($jec!='24'){
echo date("现在时间:\rY年m月d日\r");
echo date("H")+8;
echo date(":i:s  $week[$w]");
}
?>
