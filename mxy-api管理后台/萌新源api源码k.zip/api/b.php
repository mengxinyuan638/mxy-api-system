<?php
$str = 'http://guyuapi.xyz/lsdd/api.php?id='.$_GET['id'].''; 
$str=file_get_contents($str);
$stre = '/歌曲：(.*?).mp3/'; 
preg_match_all($stre,$str,$trstr);
$a=$trstr[1][0];
echo $a.".mp3";

?>