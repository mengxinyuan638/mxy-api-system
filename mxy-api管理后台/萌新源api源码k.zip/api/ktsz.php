<?php
$msg=$_GET['img'];
$url=file_get_contents("http://jnapi666.wankamc.site/ktsz/api.php?img=".$msg);
echo $url;
?>