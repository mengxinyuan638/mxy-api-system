<?php
header("Content-type: text/html; charset=UTF-8");

function th($data){
$search = array(" ","　","\n","\r","\t");
$replace = array("","","","","");
return str_replace($search, $replace, $data);
}
$msg=$_GET["msg"];
$m=$_GET["m"]?:10;

$data=file_get_contents("http://main.shoujiduoduo.com/ring.php?type=searchwp&keyword=".$msg."&page=&pagesize=".$m."&randnum=0.".time()."");
$data=th($data);
$s=preg_match_all('/<ringname="(.*?)"(.*?)"artist="(.*?)"(.*?)lurl="(.*?)"/',$data,$v);

if($s=="0"){echo "抱歉，暂无【".$msg."】的相关铃声。";exit;}
$b=$_GET["n"];
if($b==""){
for( $i = 0 ; $i < $s && $i < 20 ; $i ++ ){
$name=$v[1][$i];
$gs=$v[3][$i];
echo ($i+1)."、".$name."——".$gs."\n";
}
}else{
$i=($b-1);
$name=$v[1][$i];
$gs=$v[3][$i];
$id=$v[5][$i];
//$data=file_get_contents("http://360web.shoujiduoduo.com/ringweb/ringweb.php?type=geturl&act=down&rid=".$id."");
echo "歌名：".$name."——".$gs."\n播放链接：http://cdnringuc.shoujiduoduo.com".$id;
}
?>