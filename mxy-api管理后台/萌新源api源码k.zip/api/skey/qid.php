<?php
include("./API.php");
include("./qq.class.php");
$qq=$_GET["qq"];
$uin=$_GET["uin"];
$skey=$_GET["skey"];
$pskey=$_GET["pskey"];
$type=$_GET["type"];
if($type=="1"){
$uin=$robot["qq"];
$skey=QQROT::getSkey();
$pskey=QQROT::getPskey("vip.qq.com");
}
if(!$qq || !$uin || !$skey || !$pskey){
echo "参数不完整";
exit();
}

$bkn=getGTK($pskey);
$url="https://club.vip.qq.com/api/trpc/qid_server/GetQid";
$post="g_tk=".$bkn."&uin=".$qq."";
$header=[
"Referer: https://club.vip.qq.com/",
"Cookie: uin=".$uin."; skey=".$skey."; p_skey=".$pskey.";",
];
$data=json_decode(curl($url,$post,$header),true);
// print_r ($data);
  	$data = array(
        'uin'		=>	$qq//qq号
  		,'QID'	=>	$data['data']['qid']//qid
  	);
// 	//return $data;
$data=json_encode($data,320);
echo $data;
?>