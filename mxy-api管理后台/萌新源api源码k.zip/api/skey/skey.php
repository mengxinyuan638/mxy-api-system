<?php
include("./qq.class.php");
echo '{"code":200,"data":{"uin":'.$robot['qq'].',"skey":"'.QQROT::getSkey().'"}}';
?>