<?php
$qq = $_GET['qq'];
$type = $_GET['type'];
include("./qq.class.php");
if($qq==''||$qq==null){
echo "抱歉，qq参数不存在！";
exit();}
$data=QQROT::queryUserInfo($qq);
if($data["ret"]=='false'){
echo "获取失败";
exit();
}else 
$qq=$data["Info"]["UIN"];//qq号
$NickName=$data["Info"]["NickName"];//昵称
$Remark=$data["Info"]["Remark"];//个性签名
$Email=$data["Info"]["Email"];//邮箱
if($Email==''||$Email==null){$Email="未设置";}
$CLike=$data["Info"]["CLike"];//获赞数
$Sign=$data["Info"]["Sign"];//个性签名
$QQLevel=$data["Info"]["QQLevel"];//QQ等级
$Age=$data["Info"]["Age"];//年龄
$Country=$data["Info"]["Country"];//国家
$Province=$data["Info"]["Country"];//省份
$City=$data["Info"]["City"];//城市
if($Country==$Province){
$dz=$Province.$City;
}else if($Province==$City){
$dz=$Country.$Province;
}else{
$dz=$Country.$Province.$City;
}
if($dz==''||$dz==null){$dz="未设置";}
if($type=="json"){
  	$data = array(
        'uin'		=>	$qq//qq号
  		,'NickName'	=>	$NickName//昵称
  		,'Remark'	=>	$Remark//个性签名
  		,'Email'	=>	$Email//邮箱
  		,'CLike'	=>	$CLike//获赞数
  		,'Sign'	    =>	$Sign//个性签名
  		,'QQLevel'	=>	$QQLevel//QQ等级
  		,'Age'	    =>	$Age//年龄
  		,'Country'	=>	$Country//国家
  		,'Province'	=>	$Province//省份
  		,'City'	    =>	$City//城市
  	);
// 	//return $data;
$data=json_encode($data,320);
echo $data;
}else{
echo "QQ号：".$qq."\n";
echo "昵称：".$NickName."\n";
echo "年龄：".$Age."岁\n";
echo "等级：".$QQLevel."\n";
echo "个性签名：".$Remark."\n";
echo "获赞数：".$CLike."\n";
echo "邮箱：".$Email."\n";
echo "现居地：".$dz;
}
?>