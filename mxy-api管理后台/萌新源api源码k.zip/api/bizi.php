<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
$list=file_get_contents("http://service.picasso.adesk.com/v1/lightwp/category");
function replace_unicode_escape_sequence($match) {
return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
$list=preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $list);
$result=preg_match_all('/{\"count\": (.*?), \"ename\": \"(.*?)\", \"rname\": \"(.*?)\", \"cover_temp\": \"(.*?)\", \"name\": \"(.*?)\", \"cover\": \"(.*?)\", \"rank\": (.*?)\"id\": \"(.*?)\"/',$list,$nute);
if($msg==null)
{
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[5][$x];
echo ($x+1)."：".$jec."图-壁纸\n";
}
echo "提示：发送以上序号选择(msg=)";
}
else
{
$b=$_GET['msg'];
$b=($b-1);
$bb=$nute[8][$b];
$ar=mt_rand(1,30);
$lis=file_get_contents("http://service.picasso.adesk.com/v1/vertical/category/".$bb."/vertical?limit=100&skip=0&order=new");
preg_match_all("/wp\": \"(.*?)\"/",$lis,$bb);
$bb=$bb[1][$ar];
echo "±img=".$bb."±";
}
?>