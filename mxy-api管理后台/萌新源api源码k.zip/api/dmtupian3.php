<?php
$A=file_get_contents("https://tuapi.eees.cc/meinv.php?type=json");
$a = json_decode($A);
echo $a->img;
?>