<?php
include("./tongji/tongji.php");
$arr=range(0,25);
shuffle($arr);
foreach($arr as $values);
$aaa=file_get_contents("http://ring.djduoduo.com//ring_enc.php?cmd=getlist&q=Ao4N2N2CMUnCTUNaOOC%2FELMqq3cDNeTIoixgzDPIYbW9LWMHXrYRZ4AF271Ox0IxatF2qKy079S9LWMHXrYRZ6UNtm%2FaczBAiX7IAEsTEFBQ%2FdTj2GbNN727OeVlFIVrSm%2FzB4%2FlUaborsOKJkFoPzzvRWUuqCjkSbAEXSqQ0eQvzv8QvJvvhD2W7AOdl3yBEfh0bpzd2ESAQHGYckurpFyP9KZF3Sjc%2F7lsi1Sg84iqHWG1FKA9CLSCR%2FwMuA4SoVCnxHvba9toTvzAHjHa4Dlh4erDEcVSqzlpoe9Zf%2FEaANJ2br4dqg%3D%3D");
preg_match_all("/name=\"(.*?)\"/",$aaa,$bbb);
$bbb=$bbb[1][$values];
preg_match_all("/artist=\"(.*?)\"/",$aaa,$fff);
$fff=$fff[1][$values];
preg_match_all("/head_url=\"(.*?)\"/",$aaa,$ccc);
$ccc=$ccc[1][$values];
preg_match_all("/mp3url=\"(.*?)\"/",$aaa,$eee);
$eee=$eee[1][$values];
if($_GET['type']=="xml"){
echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="12345" action="dabai" brief="最嗨铃声" sourceMsgId="0" url="https://youxi.vip.qq.com/m/act" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="http://cdnringbd.shoujiduoduo.com'.$ccc.'" src="http://cdnringbd.shoujiduoduo.com'.$eee.'" /><title>'.$bbb.'</title><summary>'.$fff.'</summary></item><source name="最嗨铃声" icon="" action="web" appid="-1" /></msg>';
exit;}
echo "图片：http://cdnringbd.shoujiduoduo.com".$ccc."\n歌名：".$bbb."\n歌手：".$fff."\n播放链接：http://cdnringbd.shoujiduoduo.com".$eee."";
?>
