<?php
$msg = $_GET['msg'];
$A=file_get_contents("https://api.66mz8.com/api/qq.level.php?qq=".$msg."");
$json=json_decode($A, true);
$B=$json["code"];
if($B=='203'){
echo "错误信息";
}else
if($B=='200'){
$qq=$json["qq"];//QQ账号
$name=$json["name"];//QQ昵称
$autograph=$json["autograph"];//QQ签名
$gender=$json["gender"];//QQ性别
$qqage=$json["qqage"];//QQ年龄
$level=$json["level"];//QQ等级
echo "QQ:".$qq."\n昵称:".$name."\n签名:".$autograph."\n性别:".$gender."\n年龄:".$qqage."\n等级:".$level."";
}
?>