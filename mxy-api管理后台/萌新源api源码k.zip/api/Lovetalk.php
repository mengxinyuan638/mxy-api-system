<?php
$url=file_get_contents("https://api.lovelive.tools/api/SweetNothings");
echo $url;
?>
