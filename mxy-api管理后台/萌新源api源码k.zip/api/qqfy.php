<?php
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
if($_GET['msg']){}
else{
echo "抱歉，msg参数不存在！\n此为必填项。";exit;}

$url = "https://wxapp.translator.qq.com/api/translate?sourceText=".urlencode($_GET["msg"])."&source=auto&target=auto&platform=MQQAPP&candidateLangs=zh%7Cen&guid=wxapp_openid_1576171882_ptxba365xp";
$data = "0";
$rst= get_curl($url,$data);
$nr1 = '/"targetText":"(.*?)"/';
preg_match_all($nr1,$rst,$nr1);
if($_GET['type']=="tts"){
echo mp3($nr1[1][0]);exit;}
echo "内容：".$_GET['msg']."\n结果：".$nr1[1][0];
function mp3($msg){
$cookie = '0';
$url = "https://fanyi.baidu.com/gettts?lan=zh&text=".$msg."&spd=5&source=wise";
$post = '0';
$str= get_curl($url,$post,0,$cookie);
$rand=rand(100000,99999999);
$shuju="yuyin/".$rand.".amr";
$handle = fopen($shuju, 'w') or die('Cannot open file: '.$shuju);
fwrite($handle, $str);
echo "http://".$_SERVER['HTTP_HOST']."/api/yuyin/".$rand.".amr";
fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+60);//延迟30秒后执行下面的命令
unlink("yuyin/".$rand.".amr");

}

function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=1,$nobaody=0,$json=0)
{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		if($json){
			$httpheader[] = "Content-Type:application/json; charset=utf-8";
		}
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Dalvik/2.1.0 (Linux; U; Android 9; 16s Build/PKQ1.190202.001)');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
		return $ret;
}

?>