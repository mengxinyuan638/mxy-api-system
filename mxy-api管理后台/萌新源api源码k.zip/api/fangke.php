<?php
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$name = isset($_GET['qq']) ? urlencode($_GET['qq']) : '';
if(is_numeric($name)){
$data = file_get_contents("compress.zlib://http://h5.qzone.qq.com/p/r/cgi-bin/qzone_dynamic_v7.cgi?uin=".$name."&param=848&format=json");
preg_match_all('/"todaycount":(.*?),/',$data,$j);
$j=$j[1][0];
preg_match_all('/"totalcount":(.*?)}/',$data,$z);
$z=$z[1][0];
if($j== ""&&$z== ""){
echo "搜索不到与【".$name."】的相关信息，请稍后重试。";
}else{
echo "今日访客：".$j."\n空间总访客：".$z."";
}}else{
echo "抱歉，您输入的不是数字。";
}?>