<?php
$A=file_get_contents("https://api.apiopen.top/getJoke?count=1&type=video");
echo $A;