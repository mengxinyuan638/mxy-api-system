<?php
header('Content-type:text/html;charset=utf-8');
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
require_once 'city.php';
@error_reporting(0);

    $client = new SoapClient('http://www.webxml.com.cn/WebServices/WeatherWebService.asmx?wsdl');
    $code = $_GET['msg'];
    
    $para = array('theCityName'=>$code);
    $res = $client->__Call('getWeatherbyCityName',array('paramters'=>$para))->getWeatherbyCityNameResult->string;
if($res[1]=='') 
{ 
echo "抱歉，暂不支持该地区！";
} 
else 
{
    echo "城市：".$res[1];
    echo "\n气温：".$res[5];
    echo "\n".$res[10];
    echo "\n".$res[11];}
?>