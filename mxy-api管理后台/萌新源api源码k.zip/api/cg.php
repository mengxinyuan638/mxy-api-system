<?php
 //统计

$msg = $_GET['msg'];
$b = $_GET['n'];
$str = "http://api.ring.kugou.com/ring/search?q=".$_GET["msg"]."&t=3&subtype=1&p=1&pn=50&st=2";
$str=file_get_contents($str);
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');}
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $str);
$stre = '/"url":"(.*?)"(.*?)"singerName":"(.*?)"(.*?)"ringName":"(.*?)"/'; 
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与".$_GET['msg']."的相关歌曲，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 1 ; $i < $result && $i < 11 ; $i ++ )
{
$ga=$trstr[3][$i];//获取歌名
$gb=$trstr[5][$i];//获取歌手
echo ($i)."：".$ga."--".$gb."\n";
}
echo "\n共搜索到与".$_GET['msg']."的相关歌曲".$result."条，您可以点1～".$result."任一曲。";
}
else
{
//
$i=($b);
$l=$trstr[1][$i];
$ga=$trstr[3][$i];//获取歌名
$gb=$trstr[5][$i];//获取歌手
if(!$l == ' '){
die ('列表中暂无序号为『'.$b.'』的歌。');
}
echo $l;
//echo "\$群语音 ".$l."$";
//echo "\$发送 群 ptt %群号% -1 ".$l."\$";
}
}

//{"filename":"115b494db7fd8093c648fb3dbd6c80df.mp3","diy":{},"url_valid_duration":3600,"comment_cnt":0,"tracker_url":"http:\/\/ring.bssdlbig.kugou.com\/115b494db7fd8093c648fb3dbd6c80df.mp3","hash":"115b494db7fd8093c648fb3dbd6c80df","type":0,"crbtValidity":"20380101","gotoEnable":0,"is_kugou":0,"image":{"small":"http:\/\/singerimg.kugou.com\/uploadpic\/mobilehead\/20161008\/20161008114620925.jpg","big":"http:\/\/singerimg.kugou.com\/uploadpic\/softimage\/20140211\/20140211181016925.jpg","hd":"http:\/\/singerimg.kugou.com\/singer_portrait\/20150115\/20150115151235372.jpg","id":"88881","name":"唐古","head":"http:\/\/singerimg.kugou.com\/uploadpic\/softhead\/100\/20200825\/20200825104714745519.jpg"},"thumb_cnt":0,"url":"http:\/\/ring.bssdlbig.kugou.com\/115b494db7fd8093c648fb3dbd6c80df.mp3","gotourl":"","collect":265,"flag":1,"is_np":0,"price":0,"duration":"34","gotoRemarks":"","playtimes":29935754,"ringId":"38773","coverurl":"","singerName":"唐古","gotoName":"","ringName":"我在前世约了你","subtype":0,"ext":"mp3","remarks":"","tone_quality":3,"ringDesc":"","settingtimes":6092}

?>