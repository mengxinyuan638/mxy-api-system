<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
$b=$_GET['b'];
$list=file_get_contents("https://zuowen.jupeixun.cn/zuowen/search?name=".$msg);
$list=str_replace("	", '', $list);
$list=str_replace("\n", '', $list);
$result = preg_match_all("/<a target=\"_blank\" href=\"(.*?)\"><h3 class=\"title\">(.*?)<\/h3><\/a><!-- <p>(.*?)<\/p>/",$list,$nute);
if($b==null)
{
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[2][$x];
echo ($x+1)."：".$jec."\n";
}
echo "提示：发送以上序号选择";
}
else
if($b>10||$b<1)
{
echo "请按以上序号选择";
}
else
{
$i=($b-1);
$aa=$nute[2][$i];
$bb=$nute[3][$i];
$cc=$nute[1][$i];
echo "作文名字：".$aa."\n";
echo "作文内容：".$bb."...\n";
echo "作文链接：".$cc."\n";
echo "作文提示：作文只提供参考";
}
?>