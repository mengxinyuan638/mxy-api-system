<?php
$id=$_GET["qq"];
$data1 = array('foo','bar','baz','boom','cow'=>'milk','php'=>'hypertext processor');
$data = http_build_query($data1);
$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Content-type:application/x-www-form-urlencoded',
        'content' => $data,
        'timeout' => 60 * 60
    )
);
$url = "http://new.fulimcp.cn/qb-api.php?mod=cha&qq=$id";
$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
echo $result;