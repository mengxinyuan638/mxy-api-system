<?php
     $msg = $_GET['msg'];
			$url = 'http://image.so.com/i?q='.$msg;
			$content = file_get_contents($url);
			preg_match_all('/"thumb":"[^,]*,/', $content, $result);
			$rep = array('"thumb":"','",','\\');
			$str = rand(0,count($result[0])-1);
			$str = str_replace($rep, '', $result[0][$str]);
			echo ''.$str.'';
		
?>