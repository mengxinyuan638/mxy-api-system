<?php
$name=$_GET["msg"];
if($name==""){exit("抱歉，输入为空。");}
$name=str_replace('座','',$name);
$jk=Array(
"白羊"=>"1",
"金牛"=>"2",
"双子"=>"3",
"巨蟹"=>"4",
"狮子"=>"5",
"处女"=>"6",
"天秤"=>"7",
"天蝎"=>"8",
"射手"=>"9",
"摩羯"=>"10",
"水瓶"=>"11",
"双鱼"=>"12");
$l=$jk[$name];
if($l==""){
exit('不存在此类型，请查证后重试。');}


$z=file_get_contents("http://cal.meizu.com/android/unauth/horoscope/gethoroscope.do?type=".$l."&date=".date("Y-m-d")."&searchType=0");
$z=myTrim($z);
$p=preg_match_all('/{"contentAll":"(.*?)","contentCareer":"(.*?)","contentFortune":"(.*?)","contentHealth":"(.*?)","contentLove":"(.*?)","contentTravel":"(.*?)","date":(.*?),"direction":"(.*?)","enemies":"(.*?)","friends":"(.*?)","horoscopeType":(.*?),"id":(.*?),"lucklyColor":"(.*?)","lucklyTime":"(.*?)","mark":(.*?),"numbers":(.*?),"pointAll":(.*?),"pointCareer":(.*?),"pointFortune":(.*?),"pointHealth":(.*?),"pointLove":(.*?),"pointTravel":(.*?),"shorts":"(.*?)"}/',$z,$z);
if($p==0){exit("抱歉，获取出错。");}
$zt=$z[1][0];//整体运势
$sy=$z[2][0];//事业运势
$cf=$z[3][0];//财富运势
$aq=$z[5][0];//爱情运势
$fw=$z[8][0];//贵人方位
$py=$z[10][0];//贵人星座
$ys=$z[13][0];//幸运颜色
$sz=$z[16][0];//幸运数字
$ts=$z[23][0];//提示

$data="星座：".$name."\n贵人方位：".$fw."\n贵人星座：".$py."\n幸运数字：".$sz."\n幸运颜色：".$ys."\n爱情运势：".$aq."\n财富运势：".$cf."\n事业运势：".$sy."\n整体运势：".$zt."\n提示：".$ts;

echo $data;

function myTrim($str)
{
 $search = array(" ","　","\n","\r","\t");
 $replace = array("","","","","");
 return str_replace($search, $replace, $str);
}

?>