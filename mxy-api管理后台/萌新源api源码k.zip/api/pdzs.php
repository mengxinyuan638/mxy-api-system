<?php
echo mb_strlen($_GET["msg"], 'UTF-8') . "";
?>