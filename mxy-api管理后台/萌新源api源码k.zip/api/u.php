<?php
header("Content-type: text/html; charset=UTF-8");
include("./tongji/tongji.php"); //统计
$data = $_GET['msg'];
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}


$data = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $data);
echo $data;
?>