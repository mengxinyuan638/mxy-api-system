<?php
$m=(((59-date("i", time()))*60)+(60-date("s", time())))*1000;//获得延时时间
echo "".$m."";
?>