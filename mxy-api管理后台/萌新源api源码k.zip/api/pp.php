<?php
 //统计

$id=$_GET["id"];
function post_data_test($url,$data){
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
$header = array(
'User-Agent' => 'Mozilla/5.0(Linux;Android8.1.0;16th Plus Build/OPM1.171019.026;wv)AppleWebKit/537.36(KHTML,like Gecko)Version/4.0Chrome/66.0.3359.126MQQBrowser/6.2TBS/044506Mobile Safari/537.36V1_AND_SQ_7.9.9_1010_YYB_DQQ/7.9.9.3965NetType/WIFI WebP/0.3.0Pixel/1080StatusBarHeight/90',
'Referer' => 'http://m.kugou.com/',
'Cookie'=>'');
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
curl_setopt($curl, CURLOPT_POST, 1);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
curl_setopt($curl, CURLOPT_TIMEOUT, 30);
curl_setopt($curl, CURLOPT_HEADER, 0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
if (curl_errno($curl)){
echo '错误信息;'.curl_error($curl);}
curl_close($curl);
return $result;}

if($id==1||$id==2){
if($id==1){
$url = 'http://api.ippzone.com/index/recommend?sign=edc890b90d59334e3f356e0ebb6541f1';
$a = post_data_test($url,$data);
$s = preg_match_all('/"content":"(.*?)"(.*?),"urls":\["(.*?)"(.*?)"videos":{"(.*?)":{"dur":(.*?),"thumb":(.*?),"playcnt":(.*?),"url":"(.*?)"/',$a,$x);
$i=rand(0,$s);
$n=$x[1][$i];
$t=$x[3][$i];
$l=$x[9][$i];
echo "图片：".$t."\\n".$n."\\n链接：".$l;
}else{
$url = "http://api.ippzone.com/index/recommend?sign=0969f51dc083fe666d49389bc49e4f90";
$data = '{"audio":1,"auto":0,"c_types":[1,2,101,102,103,104,20,21,22,23,8],"direction":"down","filter":"txt","tab":"段子","h_av":"4.9.1","h_pipi":"1.9.1","h_dt":0,"h_os":28,"h_app":"zuiyou_lite","h_model":"16s","h_did":"09ae280daeb4bd43","h_nt":1,"h_m":354620183516,"h_ch":"meizu","h_ts":1567257424847,"token":"T6K2NcLyBqFuFmLnHVVOLBS19IYVvmbokJUbd2VhbT8bvXjH7iK3eARMfhyJDNBA6jlwc","android_id":"09ae280daeb4bd43"}';
$a = post_data_test($url,$data);
$s = preg_match_all('/"content":"(.*?)"/',$a,$x);
$i=rand(0,$s);
$n=$x[1][$i];
echo $n;}}else{
echo "ID不存在。";}
?>