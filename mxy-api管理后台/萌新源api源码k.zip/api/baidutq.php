<?php
$name = urlencode($_GET['msg']);

 //统计
$str = file_get_contents("compress.zlib://http://api.map.baidu.com/telematics/v3/weather?output=json&ak=QOXc6o4y3rwbAs7i74ITwDHUXyqMAYUK&location=".$name."");
$stre = "/{\"date\":\"(.*?)\",\"dayPictureUrl\":\"(.*?)\",\"nightPictureUrl\":\"(.*?)\",\"weather\":\"(.*?)\",\"wind\":\"(.*?)\",\"temperature\":\"(.*?)\"/"; 
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与".$_GET["msg"]."的相关天气信息，请检测城市名或稍后重试。";
}else{
echo "$_GET['msg']\n\n";
for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$a=$trstr[1][$i];//时间
$d=$trstr[4][$i];//天气
$e=$trstr[5][$i];//风向
$f=$trstr[6][$i];//温度
echo "$a\n天气情况：$d\n温度：$f\n风向：$e\n\n";}
}
?>