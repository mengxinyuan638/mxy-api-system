<?php 
header("Content-type: text/html; charset=UTF-8");
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$name = $_GET["type"]; 

$array=array("网红" => "5930e061e7bce72ce01371ae",
"明星" => "5930e046e7bce72ce013719c",
"热舞" => "5930e081e7bce72ce01371c8",
"风景" => "5930e16ee7bce72ce013725f",
"游戏" => "5930e009e7bce72ce0137170",
"动物" => "5930e22ee7bce72ce01372f3");
$id=$array[$name];
if($id==""){
echo "抱歉，type参数错误\n参数说明：type可为网红、明星、热舞、风景、游戏、动物";exit;
}


$array1=array("网红" => "556",
"明星" => "597",
"热舞" => "330",
"风景" => "636",
"游戏" => "770",
"动物" => "207");
$s=$array1[$name];


$arr=range(0,$s); 
shuffle($arr);
foreach($arr as $values);
$html = file_get_contents("https://service.videowp.adesk.com/v1/videowp/category/".$id."?limit=30&skip=".$values."&adult=false&first=0&order=hot"); 
//网红

//明星https://service.videowp.adesk.com/v1/videowp/category/5930e046e7bce72ce013719c?limit=30&adult=false&first=1&order=hot&skip=

//歌曲热舞https://service.videowp.adesk.com/v1/videowp/category/5930e081e7bce72ce01371c8?limit=30&adult=false&first=1&order=hot&skip=

//风景名胜https://service.videowp.adesk.com/v1/videowp/category/5930e16ee7bce72ce013725f?limit=30&adult=false&first=1&order=hot&skip=

//游戏专区https://service.videowp.adesk.com/v1/videowp/category/5930e009e7bce72ce0137170?limit=30&adult=false&first=1&order=hot&skip=

//动物萌宠https://service.videowp.adesk.com/v1/videowp/category/5930e22ee7bce72ce01372f3?limit=30&adult=false&first=1&order=hot&skip=

function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');}
$html = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);
$result = preg_match_all('/"tag": "(.*?)", "video": "(.*?)", "(.*?)": (.*?), "click": (.*?), "category": "(.*?)", "img": "(.*?)"/', $html, $arr);//1类型(把\t替换为|，2视频链接，6图片链接

//"tag": "\u5c0f\u9c9c\u8089\t\u5e05\u6c14\t\u660e\u661f\t\u9ec4\u660e\u660a", "video": "http://cdn.video.picasso.dandanjiang.tv/5c92018704220827a21cfaa9.mp4?sign=e847d7655d1283d6e711e6018eb8a815&t=5c960706", "duration": 15, "click": 821, "favnum": 5, "category": "5930e046e7bce72ce013719c", "img": "http://cdn.video.picasso.dandanjiang.tv/5c92018704220827a21cfaa9.jpg?imageMogr2/thumbnail/!350x540r/gravity/Center/crop/350x540&sign=e779f7d675e37b40e358b8d1d9f4196a&t=5c960706"

if($result== 0){
echo "抱歉，出错了！请至官网反馈问题！";
}else{
$arr=range(0,$result); 
shuffle($arr);
foreach($arr as $values); 
preg_match_all('/"tag": "(.*?)", "video": "(.*?)", "(.*?)": (.*?), "click": (.*?), "category": "(.*?)", "img": "(.*?)"/',$html,$trstr); 
$img = "".$trstr[2][$values]."";
$t = "".$trstr[7][$values]."";
$l = "".$trstr[1][$values]."";
$l=str_replace('\t','|',$l);

echo "±img";
echo "=$t";
echo "±\n类型：$l\n播放链接：";
echo $img;

}

?>
