<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
$b=$_GET['n'];
$list=file_get_contents("https://m.ac.qq.com/search/result?t=1566829773805&word=".$msg."&page=1&pageSize=10&style=items");
$result = preg_match_all("/<strong class=\"comic-title\">(.*?)</",$list,$nute);
$je=$nute[1][0];
if($je==null)
{
echo "没有搜到[".$msg."]";
}
else
if($b== null)
{
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[1][$x];
echo ($x+1)."：".$jec."\n";
}
echo "提示：发送以上序号选择";
}
else
if($b>10||$b<1)
{
echo "请按以上序号选择";
}
else
{
$b=$_GET['n'];
$b=($b-1);
preg_match_all("/src=\"(.*?)\">/",$list,$bb1);
preg_match_all("/<strong class=\"comic-title\">(.*?)</",$list,$bb2);
preg_match_all("/<small class=\"comic-update\">(.*?)</",$list,$bb3);
preg_match_all("/<small class=\"comic-tag\">(.*?)</",$list,$bb4);
preg_match_all("/<small class=\"comic-desc\">(.*?)</",$list,$bb5);
preg_match_all("/href=\"(.*?)\">/",$list,$bb6);
$b1=$bb1[1][$b];
$b2=$bb2[1][$b];
$b3=$bb3[1][$b];
$b4=$bb4[1][$b];
$b5=$bb5[1][$b];
$b6=$bb6[1][$b];
echo "图片：".$b1."\n漫画名：".$b2."\n更新时间：".$b3."\n漫画类型：".$b4."\n漫画介绍：".$b5."\n漫画链接：https://m.ac.qq.com".$b6;
}
?>