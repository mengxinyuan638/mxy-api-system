<?php
$A=file_get_contents("http://api.dongmanxingkong.com/suijitupian/acg/1080p/index.php?return=json");
$a = json_decode($A);
echo $a->imgurl;
?>