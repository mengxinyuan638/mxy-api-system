<?php
 //统计

$msg=$_GET['msg'];
if($_GET['msg']){}
else{
echo "你特么发了个空气？？";exit;}

$url = "http://m.mengbaotao.com/api.php?cmd=chatCallback";
$data = "msg=".$_GET["msg"]."&channelid=2001&openid=9".$_GET["id"];
$rst= curl_post_https($url,$data);
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
$rst = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $rst);
//echo $rst;
$nr1 = "/\"ref\":\"(.*?)\",/";
$nr2 = "/\"ret_message\":\"(.*?)\",/";
preg_match_all($nr1,$rst,$nr1);//内容1
preg_match_all($nr2,$rst,$nr2);
if (empty($nr1[1][0].$nr2[1][0]))
exit(" 主人你说慢点，我跟不上节奏了。");
else if( preg_match('/^(以后叫你) ?(.*)\$/', $_GET["msg"]))
{
$s1 = mb_strpos($_GET["msg"]."}",'以后叫你')+4;
$s2 = mb_strpos($_GET["msg"]."}",'}');
$ss = mb_substr($_GET["msg"]."}",$s1,$s2-$s1);
$url ="http://m.mengbaotao.com/api.php?cmd=updUserNick";
$data = "type=0&channelid=2001&nick=".$ss."&openid=9".$_GET["id"];
$rst= curl_post_https($url,$data);
echo sjbq()."好的，以后我就叫".$ss."了！";
//普通回复
}
else if( preg_match('/^(以后叫我) ?(.*)\$/', $_GET["msg"]))
{
$s1 = mb_strpos($_GET["msg"]."}",'以后叫我')+4;
$s2 = mb_strpos($_GET["msg"]."}",'}');
$ss = mb_substr($_GET["msg"]."}",$s1,$s2-$s1);
$url ="http://m.mengbaotao.com/api.php?cmd=updUserNick";
$data = "type=1&channelid=2001&nick=".$ss."&openid=9".$_GET["id"];
$rst= curl_post_https($url,$data);
echo sjbq()."好的，以后我就叫你".$ss."了！";
//普通回复
}
else if( preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/', $nr1[1][0]))
{
//普通回复
echo " 🍀";
echo '±img='.$nr1[1][0].'±'.$nr2[1][0];//输出：
//输出
}
else if( preg_match('/.*(\.mp3)$/', $nr1[1][0]))
{

$nr=$nr1[1][0];
//普通回复
$yl=str_replace("\\/","/",$nr);
echo $nr2[1][0];
echo $yl;}
else if($nr1[1][0]=="")
{
if($_GET['type']=="text"){echo $nr2[1][0];exit;}
echo mp3($nr2[1][0]);
}



function curl_post_https($url,$data){
// 模拟提交数据函数
$curl = curl_init(); // 启动一个CURL会话
curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包
curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
$tmpInfo = curl_exec($curl); // 执行操作
if (curl_errno($curl))
{
echo 'Errno'.curl_error($curl);//捕抓异常
}
curl_close($curl); // 关闭CURL会话
//return $tmpInfo; // 返回数据，json格式
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $tmpInfo);
$str = str_replace("\\n","\n",$str);
$str = str_replace("\\r","",$str);
$str = str_replace("【发送任意内容触发接下来的剧情】","Tips：发送任意内容触发接下来的剧情",$str);return $str;}










function mp3($msg){
$cookie = '0';
$url = "https://fanyi.baidu.com/gettts?lan=zh&text=".$msg."&spd=5&source=wise";
$post = '0';
$str= get_curl($url,$post,0,$cookie);
$rand=rand(100000,99999999);
$shuju="yuyin/".$rand.".amr";
$handle = fopen($shuju, 'w') or die('Cannot open file: '.$shuju);
fwrite($handle, $str);
echo "http://".$_SERVER['HTTP_HOST']."/api/yuyin/".$rand.".amr";}

function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=1,$nobaody=0,$json=0)
{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		if($json){
			$httpheader[] = "Content-Type:application/json; charset=utf-8";
		}
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Dalvik/2.1.0 (Linux; U; Android 9; 16s Build/PKQ1.190202.001)');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
		return $ret;
}
fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+60);//延迟30秒后执行下面的命令
unlink("yuyin/".$rand.".amr");
?>