<?php
 //统计

$zskey=file_get_contents("http://".$_SERVER['HTTP_HOST']."/key/skey.dat");
$s=preg_match_all('/"uin":"(.*?)","skey":"(.*?)","pskey":"(.*?)"/',$zskey,$j);
$uin=$j[1][0];
$skey=$j[2][0];
$pskey=$j[3][0];
@$uin=$_GET['uin']?:$uin;
@$skey=$_GET['skey']?:$skey;
@$pskey=$_GET['pskey']?:$pskey;
if($_GET['qq']){}
else{
echo "抱歉，qq参数不存在！\\n此为必填项。";exit;}
//$cookie = 'uin=o'.$uin.'; skey=@'.$skey.'; p_uin=o'.$uin.'; p_skey='.$pskey.'';
//$url = "https://h5.qzone.qq.com/mqzone/profile?starttime=1568300177601&hostuin=".$_GET['qq']."";
$cookie='uin=o'.$uin.';p_uin=o'.$uin.';skey=@'.$skey.';pgv_info=ssid=s4743796976;pgv_pvid=3623275736;ptisp=cnc;RK=D2jAzGccsb;ptcz=dba0d94696b54de726ada132164e541a7ab97d73acaf35a3f27f4c18995fb017;p_skey='.$pskey.'';

$url = "https://h5.qzone.qq.com/mqzone/profile?sid=&hostuin=".$_GET['qq']."&no_topbar=1&srctype=10&stat=&g_f=2000000209";


//uin=o2657595205;p_uin=o2657595205;skey=MPHeKmCzqZ;pgv_info=ssid=s4743796976;pgv_pvid=3623275736;ptisp=cnc;RK=D2jAzGccsb;ptcz=dba0d94696b54de726ada132164e541a7ab97d73acaf35a3f27f4c18995fb017;p_skey=VrqkIOPCxidlb-Zpxvil-lA9o5QyVzWTer1TrC*qWn0_


$post = '0';
$data = get_curl($url,$post,$url,$cookie);
//sleep(2);
//echo htmlentities($data,ENT_QUOTES,"UTF-8");  exit;
$data=str_replace(' ','',$data);
$data = trim($data);
$data = preg_replace('/\s(?=\s)/','', $data); 
$data = preg_replace('/[\n\r\t]/','', $data);
$data = myTrim($data);
function myTrim($str){
$search = array(" ","　","\\n","\\r","\\t");
$replace = array("","","","","");
return str_replace($search, $replace, $str);}
preg_match_all('/window.g_Host={"userid":(.*?),"realname":"(.*?)","gender":(.*?),"isAlpha":(.*?),"faceurl":"(.*?)","userTitle":"(.*?)"/',$data,$x);
$q=$x[1][0];
$name=$x[2][0];
$t=$x[5][0];
$t=str_replace('/30','/100',$t);
$x=$x[6][0];
echo "QQ：".$q."\n昵称：".$name."\n头像：http:".$t."\n".$x."的空间信息如下：\n";
$s=preg_match_all('/<spanclass="txt">(.*?)<\/span><spanclass="num">(.*?)</',$data,$trstr);
if($s==0){}else{
for( $i = 0 ; $i < $s && $i < 4 ; $i ++ ){
$yw=$trstr[1][$i];//
$dj=$trstr[2][$i];//
echo "".$yw."：".$dj."\n";}}
//访客开始
$data1 = file_get_contents("compress.zlib://http://h5.qzone.qq.com/p/r/cgi-bin/qzone_dynamic_v7.cgi?uin=".$_GET['qq']."&param=848&format=json");
preg_match_all('/"todaycount":(.*?),/',$data1,$j);
$j=$j[1][0];
preg_match_all('/"totalcount":(.*?)}/',$data1,$z);
$z=$z[1][0];
if($j== ""&&$z== ""){}else{
echo "今日访客：".$j."\n空间总访客：".$z."";
}
function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept:application/json";
$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
$httpheader[] = "Connection:close";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if($post){
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
if($header){
curl_setopt($ch, CURLOPT_HEADER, TRUE);}
if($cookie){
curl_setopt($ch, CURLOPT_COOKIE, $cookie);}
if($referer){
if($referer==1){
curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
}else{
curl_setopt($ch, CURLOPT_REFERER, $referer);}}
if($ua){
curl_setopt($ch, CURLOPT_USERAGENT,$ua);
}else{
curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');}
if($nobaody){
curl_setopt($ch, CURLOPT_NOBODY,1);}
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;}

/*
$gtk= getGTK($skey);
function getGTK($skey){
$len = strlen($skey);
$hash = 5381;
for($i = 0; $i < $len; $i++){
$hash += ($hash << 5) + ord($skey[$i]);}
return $hash & 0x7fffffff;}
*/
?>