<?php
$msg = $_GET['msg'];
$b = $_GET['n'];
$str = 'http://s.music.163.com/search/get/?src=lofter&type=1&filterDj=true&limit=9&offset=0&s='.$msg.''; 
$str=file_get_contents($str);
$stre = '/{"id":(.*?),"name":"(.*?)","artists":\[{"id":(.*?),"name":"(.*?)","picUrl":(.*?)}\],"album":{"id":(.*?),"name":"(.*?)","artist":{"id":(.*?),"name":"(.*?)","picUrl":(.*?)},"picUrl":"(.*?)"},"audio/'; 
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与".$_GET["msg"]."的相关歌曲，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 9 ; $i ++ ){
$ga=$trstr[2][$i];//获取歌名
$gb=$trstr[4][$i];//获取歌手
echo ($i+1)."：".$ga."--".$gb."\n";
}
echo "\n共搜索到与".$_GET["msg"]."的相关歌曲".$result."条，您可以点1～".$result."任一曲。";
}else{
$i=($b-1);
$id=$trstr[1][$i];//id
$ga=$trstr[2][$i];//获取歌名
$t=$trstr[11][$i];//图
$gb=$trstr[4][$i];//获取歌手
if(!$id == ' '){die ('列表中暂无序号为『'.$b.'』的歌曲。');}
if($_GET['type']=="xml"){
echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="12345" action="dabai" brief="网易音乐" sourceMsgId="0" url="https://youxi.vip.qq.com/m/act" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="'.$t.'" src="http://music.163.com/song/media/outer/url?id='.$id.'" /><title>'.$ga.'</title><summary>'.$gb.'</summary></item><source name="网易音乐" icon="" action="web" appid="-1" /></msg>';
exit;}
if($_GET['type']=="json"){
echo 'json:{"app":"com.tencent.structmsg","desc":"音乐","view":"music","ver":"0.0.0.1","prompt":"[分享]'.$ga.'","appID":"","sourceName":"","actionData":"","actionData_A":"","sourceUrl":"","meta":{"music":{"action":"","android_pkg_name":"","app_type":1,"appid":100497308,"desc":"'.$gb.'","jumpUrl":"http://shengapi.cn/","musicUrl":"http://music.163.com/song/media/outer/url?id='.$id.'","preview":"'.$t.'","sourceMsgId":"0","source_icon":"","source_url":"","tag":"网易云音乐","title":"'.$ga.'"}},"config":{"autosize":true,"ctime":1575625127,"forward":true,"token":"7fef9b7d1e63b3500a42462126e9bc3d","type":"normal"},"text":"","sourceAd":""}';
exit;}
echo "图片：".$t."歌名：".$ga."歌手：".$gb."播放链接：http://music.163.com/song/media/outer/url?id=".$id."";
}}
?>