<?php
header("Content-type: text/html; charset=utf-8");
$A=file_get_contents("https://api.uomg.com/api/rand.music?sort=热歌榜&format=json");
$json=json_decode($A, true);
$qq=$json["data"]["name"];//歌名
$name=$json["data"]["artistsname"];//歌手
$autograph=$json["data"]["picurl"];//图片
$gender=$json["data"]["url"];//id
if($_GET['type']=="json"){
echo '{"歌名":"'.$qq.'","歌手":"'.$name.'","图片":"'.$autograph.'","链接":"'.$gender.'"}';
exit;}
if($_GET['type']=="xml"){
echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="12345" action="dabai" brief="随机音乐" sourceMsgId="0" url="https://youxi.vip.qq.com/m/act" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="'.$autograph.'" src="'.$gender.'" /><title>'.$qq.'</title><summary>'.$name.'</summary></item><source name="网易音乐" icon="" action="web" appid="-1" /></msg>';
exit;}
echo "图片:".$autograph."\n歌名:".$qq."\n歌手:".$name."\n链接:".$gender."";
?>