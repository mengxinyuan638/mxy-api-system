<?php
header("Content-type: text/html; charset=UTF-8");

$name = urlencode($_GET['msg']);
$data = file_get_contents("compress.zlib://http://www.ff6.wang/?mode=search&k=".$name."");


preg_match_all("/(.*?)<div class=\"box g-clear\"><a href=\"(.*?)\" class=\"img\" target=\"_blank\"><img src=\"(.*?)\">(.*?)/",$data,$t);

preg_match_all("/(.*?)<a href=\"(.*?)\">(.*?)<b>(.*?)<(.*?)b><(.*?)a><(.*?)h3><p><span class=\"base-info\">(.*?)<(.*?)span><span class=\"base-info\"><span>(.*?)<(.*?)<p><b>(.*?)<(.*?)b><a title='(.*?)'(.*?)/",$data,$x);

$l = $t[2][0];
$img = $t[3][0];


$lxx = $x[8][0];
$la = $x[10][0];
$lb = $x[12][0];
$lc = $x[14][0];

echo "图片链接:\n$img\n\n播放链接:\n$l\n\n片名:$_GET['msg']\n$lxx$la\n$lb$lc\n注:片名来自模糊搜索，不代表其观看内容，大片免VIP观看，不要会员哦！不能保证所有影片都能正常观看。";
?>