<?php
$ip = $_SERVER["REMOTE_ADDR"];
$A = file_get_contents("http://whois.pconline.com.cn/ipJson.jsp?ip=".$ip."&json=true");
$encode = mb_detect_encoding($A, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encode = mb_convert_encoding($A, 'UTF-8', $encode);
preg_match("/addr\":\"(.*?)\"/",$str_encode,$addr);
$B=urlencode($addr[1]);
echo $addr[1];
?>