<?php
header("Content-type: tg.gif");
$sjs=rand(1,16);
$png=file_get_contents("tg.gif");
$ppp=$_GET["a"];
preg_match('/(.*)b/',$ppp,$a);
preg_match('/b(.*)/',$ppp,$b);
$a=$a[1];
$b=$b[1];
$ip=$_SERVER["REMOTE_ADDR"];
$mm = file_get_contents("http://whois.pconline.com.cn/ipJson.jsp?callback=&ip=$ip");
$encode = mb_detect_encoding($mm, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encode = mb_convert_encoding($mm, 'UTF-8', $encode);
preg_match("/city\":\"(.*?)\"/",$str_encode,$add);
preg_match("/addr\":\"(.*?)\"/",$str_encode,$add1);
$name = $add[1];
$data = file_get_contents("compress.zlib://http://wthrcdn.etouch.cn/weather_mini?city=".$name."");
$encodea = mb_detect_encoding($data, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encodea = mb_convert_encoding($data, 'UTF-8', $encodea);
preg_match_all("/date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fx\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fl\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)city\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)ganmao\":\"(.*?)\"/",$str_encodea,$c);
$l=$c[37][0];

$cnm ="[".$ip."]\n地址：".$add1[1]."\n[明日]:".$l."\n";
mkdir($a);
$mmp=fopen("$a/$b.txt", "a+");
fwrite($mmp, "\n".$cnm."窥屏时间：".date("Y-m-d H:i:s")."\n");

echo $add[1];
?>