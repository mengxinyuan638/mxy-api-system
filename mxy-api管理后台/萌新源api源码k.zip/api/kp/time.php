<?php
$asd=date("d")+1;
$jec=date("H");
if($jec=='16'){
echo date("H")+8;
echo date(":i:s");
}else
if($jec=='17'){
echo 1;
echo date(":i:s");
}else
if($jec=='18'){
echo 2;
echo date(":i:s");
}else
if($jec=='19'){
echo 3;
echo date(":i:s");
}else
if($jec=='20'){
echo 4;
echo date(":i:s");
}else
if($jec=='21'){
echo 5;
echo date(":i:s");
}else
if($jec=='22'){
echo 6;
echo date(":i:s");
}else
if($jec=='23'){
echo 7;
echo date(":i:s");
}else
if($jec=='24'){
echo 8;
echo date(":i:s");
}else
if($jec!='24'){
echo date("H")+8;
echo date(":i:s");
}
?>
