<?php
$msg = $_GET['msg'];
$b = $_GET['n'];
$str = 'http://mobilecdnbj.kugou.com/api/v3/search/song?showtype=14&highlight=&pagesize=9&tag_aggr=1&plat=0&sver=5&correct=1&api_ver=1&version=9051&page=1&area_code=1&tag=1&with_res_tag=1&keyword='.$msg.''; 
$str=file_get_contents($str);
$stre = "/songname_original\":\"(.*?)\",\"singername\":\"(.*?)\",\"pay_type\":(.*?),(.*?)\"hash\":\"(.*?)\"/";
$result = preg_match_all($stre,$str,$trstr);

preg_match_all('/"filename":"(.*?)","price_320":(.*?),"songname":"(.*?)","album_audio_id":(.*?),"/',$str,$trstr1);
if($result== 0){
echo "搜索不到与".$_GET["msg"]."的相关歌曲，请稍后重试或换个关键词试试。";
}else{
if($b== null){
for( $i = 0 ; $i < $result && $i < 9 ; $i ++ )
{
$ga=$trstr[1][$i];//获取歌名
$ga=str_replace('<em>','',$ga);
$ga=str_replace('<\/em>','',$ga);
$gb=$trstr[2][$i];//获取歌手
$pay=$trstr[3][$i];
if($pay=="0"){$pay="[免费]";}else{$pay="[收费]";}
echo ($i+1)."：".$ga."--".$gb.$pay."\n";
}echo "\n共搜索到与".$_GET["msg"]."的相关歌曲".$result."条，您可以点1～".$result."任一曲。注：收费不可听。";
}else{
//
$i=($b-1);
$pay=$trstr[3][$i];
if($pay!="0"){echo "抱歉，该歌曲暂不支持免费播放。";exit;}
$ga=$trstr[1][$i];//获取歌名
$ga=str_replace('<em>','',$ga);
$ga=str_replace('<\/em>','',$ga);
$gb=$trstr[2][$i];//获取歌手
$hash=$trstr[5][$i];//320hash
$c=$trstr1[1][$i];//fname
$d=$trstr1[4][$i];//歌曲id
$img=file_get_contents('http://kmrcdn.service.kugou.com/container/v1/image?appid=1005&clientver=10009&author_image_type=4,5&album_image_type=-3&data=[{"hash":"'.$hash.'","filename":"'.$c.'","album_audio_id":'.$d.'}]');
preg_match_all('/"sizable_cover":"(.*?)"/',$img,$img);
$img=$img[1][0];//http:\/\/imge.kugou.com\/stdmusic\/{size}\/20150717\/20150717134800720552.jpg
$img=str_replace('\\/','/',$img);
$img=str_replace(array('{size}'), array('', ''), $img);
if($img==""){$img="http://".$_SERVER['HTTP_HOST']."/api/kg.jpg";

}


$key = md5($hash . "kgcloud");
$cmd = '4';//为4则输出mp3,为3则输出m4a
$url = "http://trackercdn.kugou.com/i/?cmd=$cmd&hash=$hash&key=$key&pid=1&acceptMp3=1";
$r = 'http://www.kugou.com/webkugouplayer/?isopen=0&chl=yueku_index';
$u = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36';
$data = curl_get($url,array('IPHONE_UA'=>0,'REFERER'=>$r,'USERAGENT'=>$u));
preg_match_all('/"url":"(.*?)"/',$data,$data);
$data=$data[1][0];
$data=str_replace('\\/','/',$data);

if($_GET['type']=="xml"){
echo '<?xml version=\'1.0\' encoding=\'UTF-8\' standalone=\'yes\' ?><msg serviceID="2" templateID="12345" action="dabai" brief="酷狗音乐" sourceMsgId="0" url="https://youxi.vip.qq.com/m/act" flag="0" adverSign="0" multiMsgFlag="0"><item layout="2"><audio cover="'.$img.'" src="'.$data.'" /><title>'.$ga.'</title><summary>'.$gb.'</summary></item><source name="酷狗音乐" icon="" action="web" appid="-1" /></msg>';
exit;}
if($_GET['type']=="json"){
echo 'json:{"app":"com.tencent.structmsg","desc":"音乐","view":"music","ver":"0.0.0.1","prompt":"[分享]'.$ga.'","appID":"","sourceName":"","actionData":"","actionData_A":"","sourceUrl":"","meta":{"music":{"action":"","android_pkg_name":"","app_type":1,"appid":100497308,"desc":"'.$gb.'","jumpUrl":"http://shengapi.cn/","musicUrl":"'.$data.'","preview":"'.$img.'","sourceMsgId":"0","source_icon":"","source_url":"","tag":"酷狗云音乐","title":"'.$ga.'"}},"config":{"autosize":true,"ctime":1575625127,"forward":true,"token":"7fef9b7d1e63b3500a42462126e9bc3d","type":"normal"},"text":"","sourceAd":""}';
exit;}
echo "图片：".$img."歌曲：".$ga."歌手：".$gb."播放链接：".$data;
}
}


function curl_get($url, $array=array()){
$defaultOptions = array(
'IPHONE_UA'=>1,
'SSL'=>0,
'TOU'=>0,
'ADD_HEADER_ARRAY'=>0,
'POST'=>0,
'REFERER'=>0,
'USERAGENT'=>0,
'CURLOPT_FOLLOWLOCATION'=>0);
$array = array_merge($defaultOptions, $array);
$ch = curl_init($url);
if($array['SSL']){
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);}
if($array['IPHONE_UA']){
curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_1_2 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7D11 Safari/528.16'));
}if(is_array($array['ADD_HEADER_ARRAY'])){
curl_setopt($ch, CURLOPT_HTTPHEADER, $array['ADD_HEADER_ARRAY']);
}if ($array['POST']){
curl_setopt($ch, CURLOPT_POSTFIELDS, $array['POST']);
}if ($array['REFERER']){
curl_setopt($ch, CURLOPT_REFERER, $array['REFERER']);
}if($array['USERAGENT']){
curl_setopt($ch, CURLOPT_USERAGENT, $array['USERAGENT']);
}if($array['TOU']){
curl_setopt($ch, CURLOPT_HEADER, 1); //输出响应头
}if($array['CURLOPT_FOLLOWLOCATION'])
{
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);//自动跟踪跳转的链接 
}
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$get_url = curl_exec($ch);
curl_close($ch);
return $get_url;}
?>