<?php
$name = urlencode($_GET['msg']);
$b = urlencode($_GET['n']); 
$html = file_get_contents("http://app.dict.baidu.com/dictapp/v3/s?source=wenzi&pn=0&wd=$name"); 
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);
 $str=str_replace(' ','',$str);     
$stre='/body":\["(.*?)"\],"display_name":\["(.*?)"\],"dynasty":\["(.*?)"\],"literature_author":\["(.*?)"\],"(.*?)}\],"sid":\["(.*?)"/';
$result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "抱歉，查询不到有关内容。\nPS：请检查关键词或稍后重试！";
}else{
$t=$trstr[4][1];
for( $i = 1 ; $i < $result && $i < 5 ; $i ++ )
{
$gc=$trstr[2][$i];//作品
$gb=$trstr[3][$i];//作者
$ga=$trstr[4][$i];//年代

$ge=$trstr[6][$i];//ID


echo "$gc 〖$ga  · $gb 〗\n链接：http://shengshuyun.cn/api/hy.php?id=$ge\n";
}

echo "PS：点击链接查看详细信息！";

}




?>