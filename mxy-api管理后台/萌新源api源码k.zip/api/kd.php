<?php
$A = $_GET["msg"];
$B = file_get_contents("http://glapi.cn/kd/api.php?msg=$A");
echo $B;
?>