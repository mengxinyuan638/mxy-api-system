<?php
$m=(((60-date("i", time()))*60)+(60-date("s", time())))*1000;//获得延时时间
$a=date("Y-m-d H:i:s", time());//获取整点时间格式化
echo "api->sendMsg(整点报时：{$a})\nToolKit->sleep({$m})\nToolKit->access(true\\,http://呵呵.shengapi.cn:81/api/mmedic.php)";
?>