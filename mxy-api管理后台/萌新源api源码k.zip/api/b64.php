<?php
$b = $_GET['b'];//选择模式
$str = $_GET['msg'];//获取字符串
if($b=="1")//判断模式
{echo base64_encode($str);//输出加密后的内容
}
else{echo base64_decode($str);//输出解密后的内容
}
?>