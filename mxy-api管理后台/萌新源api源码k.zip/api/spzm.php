<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
if($msg>6||$msg<1||$msg==null)
{
echo "视频桌面\n最热～1\n最新～2\n文字～3\n明星～4\n爱情～5\n二次元～6";
}
else
{
$aa=str_replace("1", "最热", $msg);
$aa=str_replace("2", "最新", $aa);
$aa=str_replace("3", "文字", $aa);
$aa=str_replace("4", "明星", $aa);
$aa=str_replace("5", "爱情", $aa);
$aa=str_replace("6", "二次元", $aa);
$x=rand(1, 30);
$bbb=file_get_contents("http://www.bizhiduoduo.com/wallpaper/wplist.php?user=861852032137517&uid=da296be554a5e9c&prod=WallpaperDuoduo4.3.3.0&isrc=WallpaperDuoduo4.3.3.0_qh360ch.apk&mac=74ac5ff01d4f&dev=360%3E1501_M02%3E1501_M02&vc=6004330&av=22&utoken=&suid=0&type=getlist&listid=106&pg=0&pc=30&spvideo=1&st=no&rt=video&label=".$aa);
preg_match_all("/<uservideo name=\"(.*?)\" thumb=\"(.*?)\" url=\"(.*?)\" preview_url=\"(.*?)\"/",$bbb,$dd);
$dd1=$dd[1][$x];
$dd2=$dd[2][$x];
$dd3=$dd[3][$x];
$dd4=$dd[4][$x];
echo "±img=".$dd2."±\n昵称：".$dd1."\n链接：".$dd4;
}
?>