<?php
header("content-Type: text/html; charset=UTF-8");
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$keywords=urlencode($_GET['msg']);
$data =file_get_contents("http://app.bilibili.com/x/v2/search?appkey=1d8b6e7d45233436&build=560161&duration=0&keyword=$keywords&mobi_app=android&platform=android&pn=1&ps=10&ts=1534807273&sign=58fec668fa2fb65a5149d04aeca15cbb");
$c=(json_decode($data,true));
$list=$_GET["n"];
if($list==null)
{
liebiao($c);
}
else
{
xuange($c,$list);
}


function liebiao($c)
{
$result=$c["data"]["nav"][4]["total"];
for( $i = 0 ; $i < $result && $i < 5 ; $i ++ )

{
$e=$c["data"]["items"]["archive"][$i];
$b=$e["title"];
$mi=$e["author"];
echo ($i+1)."：".$b. " -- up主:" . $mi. "\n";
}

}


function xuange($c,$list)
{
$d=$e=$c["data"]["items"]["archive"][($list-1)];
$pic=$d["cover"];
$upzhu=$d["author"];
$jieshao=$d["desc"];
$id=$d["param"];
$time=$d["duration"];
echo "±img=",$pic,"±","\n","up主:",$upzhu,"\n","介绍:",$jieshao,"\n","时长:",$time,"\n","观看地址:","https://m.bilibili.com/video/av$id.html";
}
?>