<?php
 //统计

function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$httpheader[] = "Accept:*/*";
	$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
	$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
	$httpheader[] = "Connection:close";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if($referer){
		if($referer==1){
			curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
		}else{
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
	}
	if($ua){
		curl_setopt($ch, CURLOPT_USERAGENT,$ua);
	}else{
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn; R815T Build/JOP40D) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/4.5 Mobile Safari/533.1');
	}
	if($nobaody){
		curl_setopt($ch, CURLOPT_NOBODY,1);
	}
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
header("Content-Type:application/json;charset=utf-8");
$cookie = 'H_WISE_SIDS=137151_127760_128700_136648_129117_136758_128067_134982_120216_136985_133981_136365_137139_132909_136456_136617_131247_132378_131518_118886_118876_118842_118818_118801_136687_107317_132785_136799_136430_133352_136862_136812_137011_129651_136195_124628_135307_133847_132551_129645_131423_136221_137255_136045_110085_127969_133994_131951_135839_136613_135458_128196_136635_134350_134231_136413_136988; PSINO=2; delPer=0; BCLID=9224929741152452263; BDSFRCVID=4s4OJeC62ibjtSrwGoqQIizDPfKvoD7TH6aGA3aYFh1adlpEIabTEG0Pjf8g0KubVwkKogKKXgOTHw0F_2uxOjjg8UtVJeC6EG0Ptf8g0M5; H_BDCLCKID_SF=tR-j_K-2tKD3fP36q4Rfh4F_hgT22-usJTAJ2hcH0KLKjJoF5hbK5U-eKJQAaRTRLIciLJ7gJMb1MRjjLjbHWfKJDfQb2nO4WC6a-p5TtUJ8eCnTDMRh-lKWMPRyKMniyIv9-pn5tpQrh459XP68bTkA5bjZKxtq3mkjbPbDfn028DKu-n5jHjJQDNAt3J; SE_LAUNCH=5%3A26184369_24%3A26194573_25%3A26194480_12%3A26190461_22%3A26187265_11%3A26190335_13%3A26192561_0%3A26191372_10%3A26191372_30%3A26194476_15%3A26194570; BDORZ=AE84CDB3A529C0F8A2B9DCDD1D18B695; SIGNIN_UC=70a2711cf1d3d9b1a82d2f87d633bd8a03216866122; IMG_WH=375_553; BDPASSGATE=IlPT2AEptyoA_yiU4VK43kIN8efBTvS41fPESFpP36OtfCaWmhH3BrVMSEnHN-a8AiTM-Y3fo_-5kV8PQlxmicwdggYTpW-H7CG-zNSF5aTvL_NgzbIZCb4jQUZqqvzxkgl-zuEHQ49zBCstpBTbpuo4ivKl73JQb4r56kCygKrl_oGm2X8My88bOXVfYZ0APNu594rXnEpKLDm4Yv7tT9PecSIMR7QEy0ngi3MM4Pjkq6oY0ReiZMExGI8mFppkJR4bBPmLlKi9DV5wzZ1c; BDUSS=WVsZ3FzNlp4UThxVEdaR0JEemRMfmdvQXFwbG9ENk80dTFsMjA3R1FrZXZKdFJkSVFBQUFBJCQAAAAAAAAAAAEAAACSWB~Kd29obWEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK-ZrF2vmaxdL; PSTM=1567840476; BIDUPSID=1903B023A3811EEC29E88AE8AAFAF731; BAIDUID=1903B023A3811EEC29E88AE8AAFAF731:FG=1';
$num = $_GET["msg"];
if(!$num){
exit('输入内容错误。');
}
$url = 'https://sp0.baidu.com/9_Q4sjW91Qh3otqbppnN2DJv/pae/channel/data/asyncqury?cb=?&appid=4001&nu='.$num.'&com=_auto&qid=11276690169346352877&new_need_di=1&source_xcx=0&vcode=&token=&sourceId=4155&cb=jsonp_1571676277852_58018';
$data = get_curl($url,0,0,$cookie);
$data = preg_replace('/(.*?){"msg/','',$data);
$data = '{"msg'.$data;
$data = substr($data,0,-1);
$info = json_decode($data,true);
if($info["msg"]=="暂未查到与您单号相关的物流信息，请稍候再尝试查询"){
exit('未查询到该单号相关的物流信息。');
}
$info = $info["data"]["info"]["context"];
foreach($info as $key=>$value){
//hidtel($phonenum);
echo date("Y年m月d日 H:i:sA",$value["time"])."\\n".$value["desc"]."\\n\\n";
}

?>