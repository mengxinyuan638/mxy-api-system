<?php
header("Content-type: text/html; charset=utf-8"); 
$msg=urlencode($_GET['msg']);
$b=$_GET['n'];
$c=$_GET['type'];
$url=file_get_contents("http://soso.music.qq.com/fcgi-bin/search_cp?aggr=0&catZhida=1&lossless=0&sem=1&w=".$msg."&n=10&t=12&remoteplace=sizer.yqqlist.mv&hostUin=0&format=jsonp&inCharset=utf-8&outCharset=utf-8");
$result=preg_match_all("/{\"docid\":\"(.*?)\",\"duration\":(.*?),\"mvName_hilight\":\"(.*?)\",\"mv_id\":(.*?),\"mv_name\":\"(.*?)\",\"mv_pic_url\":\"(.*?)\",\"play_count\":(.*?),\"singerMID\":\"(.*?)\",\"singerName_hilight\":\"(.*?)\",\"singer_name\":\"(.*?)\",\"singerid\":(.*?),\"v_id\":\"(.*?)\",\"version\":(.*?)},/",$url,$nute);
if($b== null)
{
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[5][$x];
$je=$nute[9][$x];
echo ($x+1)."��".$jec."-".$je."\n";
}
echo "��ʾ�������������ѡ��";
}
else
if($b>10||$b<1)
{
echo "�밴�������ѡ��";
}
else
$b=$_GET['b'];
$b=($b-1);
$aa1=$nute[6][$b];//ͼƬ
$aa2=$nute[5][$b];//����
$aa3=$nute[9][$b];//����
$aa4=$nute[12][$b];//����
$aa5="https://y.qq.com/n/m/detail/mv/index.html?platform=11&appshare=android_qq&appversion=8090509&hosteuin=oKE5oKnF7K6zoc**&vid=".$aa4;
if($c=="text")
{
echo "ͼƬ��".$aa1."\nMV����".$aa2."\nMV���֣�".$aa3."\n���ӣ�".$aa5."";
}
else
if($c=="json")
{
echo "{\"app\":\"com.tencent.structmsg\",\"desc\":\"����\",\"view\":\"music\",\"ver\":\"0.0.0.1\",\"prompt\":\"[����]QQMV\",\"appID\":\"\",\"sourceName\":\"\",\"actionData\":\"\",\"actionData_A\":\"\",\"sourceUrl\":\"\",\"meta\":{\"music\":{\"title\":\"".$aa2."\",\"desc\":\"".$aa3."\",\"preview\":\"".$aa1."\",\"tag\":\"QQMV\",\"musicUrl\":\"".$aa5."\",\"jumpUrl\":\"".$aa5."\",\"source_icon\":\"\"}},\"config\":{\"forward\":true,\"autosize\":false,\"showSender\":true},\"text\":\"\",\"sourceAd\":\"\"}";
}
else
if($c=="xml")
{
echo "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><msg serviceID=\"1\" templateID=\"1\" action=\"web\" brief=\"[MV]".$aa2."\" sourcePublicUin=\"1828222534\" sourceMsgId=\"0\" url=\"\" flag=\"1\" adverSign=\"0\" createTime=\"2099-01-01\" multiMsgFlag=\"0\"><item layout=\"5\"><video cover=\"".$aa1."\" vInfo=\"".$aa4."\" tInfo=\"".$aa4."\" preStartPosi=\"0\" preTime=\"223\" preWidth=\"576\" preHeight=\"1000\" fullTime=\"223\" busiType=\"1\" aID=\"2335b4c521d481bk\" isJump2Web=\"0\" /><title>".$aa2."</title></item><source name=\"MV\" icon=\"https://q.url.cn/s/jBJuV\" url=\"\" action=\"web\" appid=\"\" /></msg>";
}
else
{
echo "ͼƬ��".$aa1."\nMV����".$aa2."\nMV���֣�".$aa3."\n���ӣ�".$aa5."";
}
?>