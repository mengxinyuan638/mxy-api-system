<?php
header("Content-type: text/html; charset=UTF-8");
include("./tongji/tongji.php");
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}

$name = $_GET["msg"];
$id = $_GET["id"];
if(strpos($name,'我接')!==false&&strpos($name,'开始成语接龙')===false){
$name=str_replace('我接','',$name);
$b=file_get_contents("data/cyjl/".$id.".json");
$shu=strlen($name);
$shu=$shu/3;
$shu="-$shu";
$t=mb_substr($name, $shu, 1, 'UTF-8');
if($b==$t){
$strs = file_get_contents("http://app.dict.baidu.com/dictapp/v120/search_idiom?mainkey=$t");
$strs = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $strs);
$name = $_GET["msg"];
$name=str_replace('我接','',$name);

$pd=strstr($strs,$name);
if($pd!==false){

$ss=preg_match_all('/"name":\["'.$name.'"\],"pinyin":\["(.*?)"\],"sid":\["(.*?)"\],"type":\["idiom"\],"word_pinyin":\["(.*?)"\],"baike_tts":\["(.*?)"\],"termadd_mean":\["(.*?)"\]/',$strs,$zs);
$w=mb_substr($name, -1, 1, 'UTF-8');
$my_file = 'data/cyjl/'.$id.'.json';
$handle = fopen($my_file, 'w') or die('Cannot open file: '.$my_file);
fwrite($handle, $w);

echo "恭喜，接龙成功！\n成语：$name\n拼音：".$zs[1][0]."\n解释：".$zs[5][0]."\n\n下一题开始咯！\n请接以〖".$w."〗打头的成语！";die;
}else{echo "接龙失败！\n\n当前需接以〖".$b."〗打头的成语。\nPS：您可以继续当前接龙或者重新开始！\n我接+成语或开始成语接龙+关键词。";die;}

}else{echo "接龙失败！\n再接再厉。\n当前需接以〖".$b."〗打头的成语。\nPS：您可以继续当前接龙或者重新开始！\n我接+成语或开始成语接龙+关键词。";die;}

}
if(strpos($name,'开始成语接龙')===false&&strpos($name,'我接')===false){
echo "抱歉，格式错误。\n开始游戏请发送：\n开始成语接龙+关键词。\nPS：关键词为一个汉字";
}
else
{
$name=str_replace('开始成语接龙','',$name);
$z=strlen($name);
if($z=="3"){
$name=$name."的成语";

$str = file_get_contents("http://app.dict.baidu.com/dictapp/v3/s?from=search&ptype=chengyu&source=chengyu&versionCode=52&platform=Android&wd=$name");
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $str);
$s=preg_match_all('/"name":\["(.*?)"\],"pinyin":\["(.*?)"\],"sid":\["(.*?)"\],"type":\["idiom"\],"word_pinyin":\["(.*?)"\],"search_attr":\["(.*?)"\],"mean_list":\[{"definition":\["(.*?)"\]/',$str,$z);
$arr=range(0,$s); 
shuffle($arr); 
foreach($arr as $s); 
$c = $z[1][$s];//成语
$j = $z[6][$s];//成语解释
$y = $z[2][$s];//拼音
$shu=strlen($name);
$shu=$shu/3;
$shu="-$shu";
$w=mb_substr($c, -1, 1, 'UTF-8');
$my_file = 'data/cyjl/'.$id.'.json';
$handle = fopen($my_file, 'w') or die('Cannot open file: '.$my_file);
fwrite($handle, $w);
if($c==''){
echo "抱歉，获取出错了！\n请重试。";
}
else
{
echo "开始咯！本宝宝出题啦！\n成语：$c\n拼音：$y\n解释：$j\n请接以〖".$w."〗字开头的成语。";

}
}else{echo "抱歉，仅限输入一个汉字。";}

}?>