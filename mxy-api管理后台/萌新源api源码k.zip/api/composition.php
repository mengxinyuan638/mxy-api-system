<?php
header("Content-type: text/html; charset=utf-8");
$msg=$_GET['msg'];
$b=$_GET['b'];
$list=file_get_contents("http://zhannei.baidu.com/cse/search?q=".$msg."&s=18326257347893590903&entry=1");
$list=str_replace('', '', $list);
$list=str_replace('', '', $list);
$result = preg_match_all("/target=\"_blank\">(.*?)a>/",$list,$nute);
$je=$nute[1][0];
if($b== null)
{
for ($x=0; $x < $result && $x<=9; $x++) 
{
$jec=$nute[1][$x];
echo ($x+1)."：".$jec."\n";
}
echo "提示：发送以上序号选择";
}
else
if($b>10||$b<1)
{
echo "请按以上序号选择";
}
else
{
$i=($b-1);
$lis=file_get_contents("http://zhannei.baidu.com/cse/search?q=".$msg."&s=18326257347893590903&entry=1");
$lisn=str_replace('', '', $lis);
$lisn=str_replace('', '', $lisn);
preg_match_all("/target=\"_blank\">(.*?)a>/",$lisn,$bb1);
preg_match_all('/.html (.*?)<\/span>/',$lis,$bb2);
preg_match_all('/
