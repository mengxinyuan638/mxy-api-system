<?php
$skey = $_GET["skey"];
$cs = $_GET["cs"];

if($cs){}else {echo "参数为空";}

if($cs == "gtk"){
echo getGTK($skey);}

if($cs == "bkn"){
echo getBKN($skey);}

function getBKN($skey){
$len = strlen($skey);
$hash = 5381;
for($i = 0; $i < $len; $i++){
$hash += ($hash << 5) + ord($skey[$i]);}
return $hash & 2147483647;}

function getGTK($skey){
$len = strlen($skey);
$hash = 5381;
for($i = 0; $i < $len; $i++){
$hash += ($hash << 5) + ord($skey[$i]);}
return $hash & 0x7fffffff;}