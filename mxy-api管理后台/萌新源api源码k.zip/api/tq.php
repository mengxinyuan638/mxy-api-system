<?php
$name = urlencode($_GET['msg']);
$data = file_get_contents("compress.zlib://http://wthrcdn.etouch.cn/weather_mini?city=".$name."");
$encode = mb_detect_encoding($data, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encode = mb_convert_encoding($data, 'UTF-8', $encode);
preg_match_all("/date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fx\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fl\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)city\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)ganmao\":\"(.*?)\"/",$str_encode,$c);
$q = $c[13][0];
$w = $c[15][0];
$e = $c[17][0];
$r = $c[21][0];
$t = $c[23][0];
$y = $c[25][0];
$u = $c[27][0];
$i = $c[29][0];
$o = $c[33][0];
$p = $c[35][0];
$a = $c[37][0];
$s = $c[39][0];
$d = $c[41][0];
$f = $c[45][0];
$g = $c[47][0];
$h = $c[49][0];
$j = $c[51][0];


echo "天气：$q\n\n$w\n$e  $r   $t   $y\n\n$u\n$i  $o  $p  $a\n\n$s\n$d  $f  $g  $h";
?>