<?php
 //统计

$msg=$_GET['msg'];
if($_GET['msg']){}
else{
echo "抱歉，msg参数不存在！\\n此为必填项。";exit;}
$url = "https://fanyi.baidu.com/gettts?lan=zh&text=".$msg."&spd=7&source=wise";
$str= file_get_contents($url);
$rand=rand(100000,99999999);
$shuju="yuyin/".$rand.".aac";
$handle = fopen($shuju, 'w') or die('Cannot open file: '.$shuju);
fwrite($handle, $str);
echo "http://".$_SERVER['HTTP_HOST']."/api/yuyin/".$rand.".aac";

fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+60);//延迟30秒后执行下面的命令
unlink("yuyin/".$rand.".aac");
?>