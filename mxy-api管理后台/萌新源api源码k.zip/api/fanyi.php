<?php
include("./tongji/tongji.php"); //统计
if(is_file($_SERVER['DOCUMENT_ROOT'].'/anquan.php')){require_once($_SERVER['DOCUMENT_ROOT'].'/anquan.php');}//调用安全组件
$name = urlencode($_GET['msg']);
$c = file_get_contents("compress.zlib://http://fanyi.youdao.com/openapi.do?keyfrom=yfhknnvt&key=457617074&type=data&doctype=json&version=1.1&q=".$name."");
$json = json_decode($c, true);
preg_match_all("/(.*?)basic\":{\"(.*?)\"(.*?)/",$c,$p);   
$p=$p[2][0];//判断
if($p==explains){
//{"translation":["desperately"],"basic":{"explains":["PlayerUnknown's Battlegrounds（PUBG，一款第一人称射击游戏）"]},"query":"绝地求生","errorCode":0,"web":[{"value":["Final Approach","Tomb Raider Survival"],"key":"绝地求生"}]}
preg_match_all("/(.*?)translation\":\[\"(.*?)\"\](.*?)explains\":\[\"(.*?)\"(.*?)/",$c,$j);//翻译、读音和解释
$a = $j[2][0];//翻译
$d = $j[4][0];//解释
$c=$json["query"];//查询的内容
echo "翻译：$c\r结果：$a\r解释：$d";
}else{
preg_match_all("/(.*?)translation\":\[\"(.*?)\"\](.*?)phonetic\":\"(.*?)\"(.*?),\"explains\":\[\"(.*?)\"(.*?)/",$c,$j);//翻译、读音和解释
$a = $j[2][0];//翻译
$b = $j[4][0];//读音
$d = $j[6][0];//解释
$c=$json["query"];//查询的内容
echo "翻译：$c\r结果：$a\r读音：$b\r解释：$d";

//{"translation":["Who are you?"],"query":"你是谁呀"


}?>