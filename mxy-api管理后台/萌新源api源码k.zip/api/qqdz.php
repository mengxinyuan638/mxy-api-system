<?php
 //统计

$zskey=file_get_contents("http://".$_SERVER['HTTP_HOST']."/key/skey.dat");
$s=preg_match_all('/"uin":"(.*?)","skey":"(.*?)","pskey":"(.*?)"/',$zskey,$j);
if($s==0){echo "数据库查询异常。";exit;}
$uin=$j[1][0];//skey
$skey="@".$j[2][0];//skey
$gtk= getGTK($skey);
$cookie = 'uin=o0'.$uin.'; skey='.$skey.'; ';
$url = 'http://kandian.qq.com/cgi-bin/detailPage/getMoreShortArticle?rowkey=8345d94565b61766&cookies=CAM%3D&deviceInfo=460014228101886%2C867401041651110&wifiInfo=wifi&bkn='.$gtk.'&g_tk='.$gtk.'';
$post="";
$data = get_curl($url,$post,$url,$cookie);
$data=str_replace('}]},"commentList":[{"','"},"commentList":[{"',$data);
$data=str_replace('"},"socialInfo":{"','"},"commentList":[{"commentId":"3665333739333564623862633065303036313732363336643566333633343330333733373336333233393338","content":"暂无"',$data);
$z = preg_match_all('/"contentInfo":{"text":"(.*?)"},"commentList":\[{"commentId":"(.*?)","content":"(.*?)"/',$data,$t);
if($z==0){echo "抱歉，获取数据异常，请过段时间再试。";exit;}
$s=rand(0,$z);
$n=$t[1][$s];//内容
$p=$t[3][$s];//神评
$tu=preg_match_all('/(.*?)","picsList":\[{"picUrl":"(.*?)"/',$n,$tt);
$n1=$tt[1][0];//
$tu1=$tt[2][0];//
if($tu==0){
echo "搞笑段子：".$n."\\n神评：".$p."";
}else{
echo "搞笑段子：".$n1."\\n[img:url=\"".$tu1."\"]\\n神评：".$p;}
function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept:application/json";
$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
$httpheader[] = "Connection:close";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if($post){
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
if($header){
curl_setopt($ch, CURLOPT_HEADER, TRUE);}
if($cookie){
curl_setopt($ch, CURLOPT_COOKIE, $cookie);}
if($referer){
if($referer==1){
curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
}else{
curl_setopt($ch, CURLOPT_REFERER, $referer);}}
if($ua){
curl_setopt($ch, CURLOPT_USERAGENT,$ua);
}else{
curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');}
if($nobaody){
curl_setopt($ch, CURLOPT_NOBODY,1);}
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;}
function getGTK($skey){
$len = strlen($skey);
$hash = 5381;
for($i = 0; $i < $len; $i++){
$hash += ($hash << 5) + ord($skey[$i]);}
return $hash & 0x7fffffff;}
?>