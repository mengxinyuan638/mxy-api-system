<?php
if($_GET["id"]!=""){
$cid=$_GET["cid"];
$html = file_get_contents("https://wx.ac.qq.com/1.0.0/Detail/comic?id=".$_GET["id"]."");
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);


//{"chapter_id":"6","seq_no":"1","vip_state":"1","title":"第1话 恶梦之前夜","pic":"https:\/\/manhua.qpic.cn\/chp_cover\/0\/15_11_10_9836e96001730eaae28a2c045a12cab7_1513307457749.jpg\/0","good":91089}

$s=preg_match_all('/{"chapter_id":"(.*?)","seq_no":"(.*?)","vip_state":"(.*?)","title":"(.*?)","pic":"(.*?)","good":(.*?)}/',$str,$q);
if($s=="0"){echo "抱歉，暂无此漫画信息。";exit;}
if($cid==""){
for( $i = 0 ; $i < $s ; $i ++ )
{
$cid=$q[1][$i];
$m=$q[4][$i];
$t=$q[5][$i];
//$str=str_replace('\\/','',$str);
echo "<hr><a href = 'http://www.shengapi.cn/api/qqdm.php?id=".$_GET["id"]."&cid=".$cid."' target = '_blank'>".$m."</a><br>";
}

exit;
}else{
$m=$q[4][$i];
$html = file_get_contents("https://wx.ac.qq.com/1.0.0/View/comic?id=".$_GET["id"]."&cid=".$_GET["cid"]."&detail=1");
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);
$str=str_replace('\\/','/',$str);
$s=preg_match_all('/"url":"(.*?)"/',$str,$q);
if($s=="0"){echo "抱歉，暂无此漫画信息。";exit;}
for( $i = 0 ; $i < $s ; $i ++ )
{
$t=$q[1][$i];

//echo "±img=".$t."±";
//$str=str_replace('\\/','',$str);
echo '<img src="http://www.shengapi.cn/api/t.php?url='.$t.'" alt="笙梳API"/>';
}



//echo $str;

exit;



$id=$q[1][$i];
$m=$q[3][$i];
$z=$q[2][$i];
$t=$q[4][$i];
$j=$q[6][$i];
$g=$q[8][$i];
$f=$q[10][$i];
$f=str_replace('","','、',$f);
echo "图：".$t."\n".$m."\n分类：".$f."\n作者：".$z."\n介绍：".$j."\n更新至：".$g."\n查看链接：http://www.shengapi.cn/api/qqdm.php?id=".$id;
}

//查看结束


}
$name = urlencode($_GET["msg"]);
$n=$_GET["n"];
if($name==""){echo "抱歉，输入为空。";exit;}
$html = file_get_contents("https://wx.ac.qq.com/1.0.0/Search/result?word=".$name."&page=1");
function replace_unicode_escape_sequence($match){
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');}
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $html);
$str=str_replace('\\/','/',$str);
//echo $str;exit;
//{"comic_id":629187,"artist_name":"冬漫社","title":"只对你臣服","cover_v_url":"https:\/\/manhua.qpic.cn\/vertical\/0\/04_17_13_e5348ec4b88cbc8f5f0e8160e103cca3_1559639601458.jpg\/0","short_desc":"占了爷的便宜，还想跑","brief_intrd":"“100块，辛苦费，走好不送。”堂堂帝少，竟被一个丫头当了解药！“占了爷的便宜，还想跑？谁给你的勇气！”","pgv_count":"2648647375","lated_seqno":"214","cover_url":"https:\/\/manhua.qpic.cn\/vertical\/0\/04_17_13_e5348ec4b88cbc8f5f0e8160e103cca3_1559639601458.jpg\/0","theme":["恋爱","都市"]}

$s=preg_match_all('/{"comic_id":(.*?),"artist_name":"(.*?)","title":"(.*?)","cover_v_url":"(.*?)","short_desc":"(.*?)","brief_intrd":"(.*?)","pgv_count":"(.*?)","lated_seqno":"(.*?)","cover_url":"(.*?)","theme":\["(.*?)"\]}/',$str,$q);
if($s=="0"){echo "抱歉，暂无相关漫画。";exit;}
if($n==""){
for( $i = 0 ; $i < $s ; $i ++ )
{
$m=$q[3][$i];
$z=$q[2][$i];
//$str=str_replace('\\/','',$str);
echo ($i+1)."、".$m."--".$z."\n";
}
}else{
$i=$n-1;
$id=$q[1][$i];
$m=$q[3][$i];
$z=$q[2][$i];
$t=$q[4][$i];
$j=$q[6][$i];
$g=$q[8][$i];
$f=$q[10][$i];
$f=str_replace('","','、',$f);
echo "图：".$t."\n".$m."\n分类：".$f."\n作者：".$z."\n介绍：".$j."\n更新至：".$g."\n查看链接：http://www.shengapi.cn/api/qqdm.php?id=".$id;
}
?>