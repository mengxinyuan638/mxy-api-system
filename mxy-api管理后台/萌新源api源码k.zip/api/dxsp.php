<?php
 //统计

$name = urlencode($_GET['msg']);
$b = $_GET['n'];
$str = "http://app.sitezt.cn/api/tbksearch?page_no=1&sort=tk_total_sales_desc%2Ctk_rate_desc&q=".$name.""; 
$str=file_get_contents($str);

        $stre = "/(.*?)\"title\":\"(.*?)\",\"pictUrl\":\"(.*?)\",\"couponAmount\":(.*?),\"zkPrice\":(.*?),\"biz30day\":(.*?),\"userType\":(.*?),\"shopTitle\":\"(.*?)\",\"nick\":\"(.*?)\",\"sellerId(.*?)auctionUrl\":\"(.*?)\",\"tkRate(.*?)/"; 
      
        $result = preg_match_all($stre,$str,$trstr);
if($result== 0){
echo "搜索不到与【".$_GET['msg']." 】的相关商品，请稍后重试或换个关键词试试。";

}
else
{

if($b== null)
{

for( $i = 0 ; $i < $result && $i < 5 ; $i ++ )
{
$a=$trstr[2][$i];//获取标题

$d=$trstr[5][$i];//获取价格
echo ($i+1)."：".$a."--".$d."\r";
}
echo "\n搜索到与【".$_GET['msg']." 】相关的商品共$result 条，您可以点1～$result 任一商品查看详细信息。";
}
else
{
//$s = $t[3][0];//图链
$f = $t[9][0];//来源
$g = $t[11][0];//链接

$i=($b-1);
$a=$trstr[2][$i];//获取标题
$d=$trstr[5][$i];//获取价格
$f=$trstr[9][$i];//获取来源
$s=$trstr[3][$i];//图片链接
$g=$trstr[11][$i];//商品链接

              if(!$g == ' '){
die ('列表中暂无序号为『'.$b.'』的商品，请输入存在的序号进行搜索。');
}

echo "±img=";
echo "$s";
echo "±";
echo "商品：$a\n价格：$d 元起\n来源：$f\n购买链接：$g";


}}

?>