<?php
 //统计

$name = $_GET['msg'];
$b = $_GET['n'];
$str = "http://m.ac.qq.com/search/result?word=".$name.""; 
$str=file_get_contents($str);
$result = preg_match_all('/<strong class=\"comic-title\">(.*?)</', $str, $a);
preg_match_all('/<small class=\"comic-tag\">(.*?)</', $str, $k);//获取类型
if($b== ""){
if($result== 0){
echo "搜索不到与".$_GET['msg']."的相关漫画作品，请稍后重试或换个关键词试试。";
}else{for( $i = 0 ; $i < $result && $i < 10 ; $i ++ ){
$ga=$a[1][$i];//获取漫画名
$ga=str_replace('\&nbsp;','',$ga);
$gb=$k[1][$i];//获取类型
echo ($i+1)."：".$ga."--".$gb."\r";}echo "共搜索到与".$_GET['msg']."的相关漫画".$result."条，您可以点1～".$result."任一作品。";
}}else{
preg_match_all('/small class=\"comic-update\">(.*?)</', $str, $c);//更新日期
preg_match_all('/<small class=\"comic-desc\">(.*?)</', $str, $d);//获取介绍
preg_match_all('/<a class=\"comic-link\" href=\"\/comic\/index\/id\/(.*?)\"/', $str, $e);//获取链接，需做进一步处理。/comic/index/id/536332
preg_match_all('/<small class=\"comic-tag\">(.*?)</', $str, $l);//获取类型
preg_match_all('/<img class=\"cover-image\" src=\"(.*?)\"/', $str, $f);//获取图链 
$i=($b-1);
$gb=$l[1][$i];//获取类型
$g=$c[1][$i];//更新日期
$j=$d[1][$i];//获取介绍
$c=$e[1][$i];//获取id
$t=$f[1][$i];//获取图链
$p = "https://m.ac.qq.com/comic/getMonthTicketInfo?t=&id=$c"; 
$p=file_get_contents($p);
preg_match_all('/monthTicket":"(.*?)"}/', $p, $d);//月票
if(!$c == ' '){
die ('列表中暂无序号为'.$b.'的漫画，请输入存在的序号进行查看。');
}
$str = "https://m.ac.qq.com/comic/index/id/$c"; 
$str=file_get_contents($str);
preg_match_all('/<span class="head-info-grade">(.*?)</', $str, $a);//评分
preg_match_all('/<span class="info-number">(.*?)</', $str, $r);//人气
preg_match_all('/<h1 class="top-title">(.*?)</', $str, $m);
$ga=$m[1][0];//获取漫画名

$s=file_get_contents("https://ac.qq.com/Comic/comicInfo/id/$c");

preg_match_all('/<em style="max-width: 168px;">(.*?)</', $s, $k);//作者
preg_match_all('/<em id="coll_count">(.*?)</', $s, $sc);
preg_match_all('/<span>(.*?)<\/span>/', $s, $pr);
$s=$sc[1][0];//收藏数
$u=$pr[1][9];//评分人数
$p=$a[1][0];//评分
$z=$k[1][0];//作者
$r=$r[1][0];//人气
$y=$d[1][0];//月票
preg_match_all('/<span class="comicList-info-update">(.*?)</', $str, $f);//更新至
preg_match_all('/<span class="comicList-info-update">(.*?)</', $str, $f);//获取图链 
$h=$f[1][0];//

echo "$ga\n收藏：$s 人气：$r\n评分：$p  评分人数：$u\n月票：$y  作者：$z\n$h $g\n类型：$gb\n介绍：$j\n链接：http://m.ac.qq.com/chapter/index/id/".$c."/seqno/1";}?>