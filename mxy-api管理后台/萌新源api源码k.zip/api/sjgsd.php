<?php
$id = $_GET['msg'];
function file_get_contents_post($url, $post){
$options = array(
'http'=> array(
'method'=>'POST',
'content'=> http_build_query($post),
),
);
$result = file_get_contents($url,false, stream_context_create($options));
return $result;
}
$data = file_get_contents_post("http://www.ip168.com/chxip/doGetMobile.do", array('keyword'=>$id,'btnsearch1'=>'%E6%9F%A5%E8%AF%A2'));
echo $data;