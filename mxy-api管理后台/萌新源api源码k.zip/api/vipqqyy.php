<?php
include("API.php");
$url=$_REQUEST['url'];
$song=$_REQUEST['song'];
$id=$_REQUEST['id'];
$Pages=$_REQUEST['Pages']?$_REQUEST['Pages']:"1";
$type=$_REQUEST['type']?$_REQUEST['type']:"list";
if($url) {
	$music=analyze($url);
	if(!$music) {
		echo json(1006,"text","歌曲解析失败！");
		exit();
	}
	if($_REQUEST["edition"]=="json") {
		$music_data=$music["data"];
		echo '{"app":"com.tencent.structmsg","config":{"autosize":true,"ctime":'.time().',"forward":true,"token":"acdd8397727ae544bdf78e6c45328f22","type":"normal"},"desc":"音乐","extra":{"app_type":1,"appid":100497308,"uin":2547678492},"meta":{"music":{"action":"","android_pkg_name":"","app_type":1,"appid":100497308,"desc":"'.$music_data["singer"].'","jumpUrl":"http://shengapi.cn/","musicUrl":"'.$music_data["music"].'","preview":"'.$music_data["Picture"].'","sourceMsgId":"0","source_icon":"","source_url":"","tag":"QQ音乐","title":"'.$music_data["Song"].'"}},"prompt":"[分享]'.$music_data["Song"].'","ver":"0.0.0.1","view":"music"}';
	} else {
		echo json(1000,null,null,$music);
	}
	exit();
}
if($song==null) {
	echo json(1001,"text","请输入歌曲名称！");
	exit();
} else if($song!=null&&$id!=null&$type!="lyrics") {
	xuange($song,$id,$Pages);
} else if($type=="lyrics") {
	lyrics($song,$id,$Pages);
} else if($type=="list") {
	liebiao($song,$Pages);
} else {
	echo json(1002,"text","请输入正确的操作类型！");
	exit();
}
function liebiao($song,$Pages) {
	$header=[
	'referer: https://y.qq.com/m/mqq/music/search.html?_wv=3&ADTAG=mqq&_wvNb=ffffff&_wvNt=000000',
	];
	$data_msg=curl("http://shc6.y.qq.com/soso/fcgi-bin/search_for_qq_cp?_=1596596573193&g_tk=36093520&g_tk_new_20200303=134181596&uin=2772655946&format=json&inCharset=utf-8&outCharset=utf-8&notice=0&platform=h5&needNewCode=1&w=".$song."&zhidaqu=1&catZhida=1&t=0&flag=1&ie=utf-8&sem=1&aggr=0&perpage=20&n=10&p=".$Pages."&remoteplace=txt.mqq.all",0,$header);
	$data_json=json_decode($data_msg,true);
	$list=$data_json["data"]["song"]["list"];
	if(!$list[0]) {
		echo json(1003,"text","请检查输入的关键词是否有误或者过长！");
		exit();
	}
	foreach($list as $k=>$v) {
		$singer_end=end($v["singer"]);
		foreach($v["singer"] as $vv) {
			if($vv===$singer_end) {
				$singer.=$vv["name"];
			} else {
				$singer.=$vv["name"]." / ";
			}
		}
		$array["data"][$k+1]=$v["songname"]."-".$singer;
		$singer="";
	}
	echo json(1000,null,null,$array);
}
function xuange($song,$id,$Pages) {
	$header=[
	'referer: https://y.qq.com/m/mqq/music/search.html?_wv=3&ADTAG=mqq&_wvNb=ffffff&_wvNt=000000',
	];
	$data_msg=curl("http://shc6.y.qq.com/soso/fcgi-bin/search_for_qq_cp?_=1596596573193&g_tk=36093520&g_tk_new_20200303=134181596&uin=2772655946&format=json&inCharset=utf-8&outCharset=utf-8&notice=0&platform=h5&needNewCode=1&w=".$song."&zhidaqu=1&catZhida=1&t=0&flag=1&ie=utf-8&sem=1&aggr=0&perpage=20&n=10&p=".$Pages."&remoteplace=txt.mqq.all",0,$header);
	$data_json=json_decode($data_msg,true);
	$list=$data_json["data"]["song"]["list"][$id-1];
	if(!$list) {
		echo json(1004,"text","请输入正确的歌曲序号！");
		exit();
	}
	$music_data=music($list);
	if(!$music_data) {
		echo json(1005,"text","歌曲播放链接获取失败！");
		exit();
	}
	if($_REQUEST["edition"]=="json") {
		//print_r($music_data);
		$music_data=$music_data["data"];
		echo '{"app":"com.tencent.structmsg","config":{"autosize":true,"ctime":'.time().',"forward":true,"token":"acdd8397727ae544bdf78e6c45328f22","type":"normal"},"desc":"音乐","extra":{"app_type":1,"appid":100497308,"uin":2547678492},"meta":{"music":{"action":"","android_pkg_name":"","app_type":1,"appid":100497308,"desc":"'.$music_data["singer"].'","jumpUrl":"http://shengapi.cn/","musicUrl":"'.$music_data["music"].'","preview":"'.$music_data["Picture"].'","sourceMsgId":"0","source_icon":"","source_url":"","tag":"QQ音乐","title":"'.$music_data["Song"].'"}},"prompt":"[分享]'.$music_data["Song"].'","ver":"0.0.0.1","view":"music"}';
	} else {
		echo json(1000,null,null,$music_data);
	}
}
function lyrics($song,$id,$Pages) {
	$data_msg=curl("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?ct=24&qqmusic_ver=1298&remoteplace=txt.yqq.lyric&searchid=103134783444040934&aggr=0&catZhida=1&lossless=0&sem=1&t=7&p=".$Pages."&n=10&w=".$song."&g_tk=5381&loginUin=2772655946&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0");
	$data_json=json_decode($data_msg,true);
	$list=$data_json["data"]["lyric"]["list"][$id-1];
	if(!$list) {
		echo json(1004,"text","请输入正确的歌曲序号！");
		exit();
	}
	echo json(1000,"data",$list["content"]);
}
function curl_id($songmid) {
	list($usec, $sec) = explode(" ", microtime());
	$msec=round($usec*1000);
	$data=curl("https://u.y.qq.com/cgi-bin/musicu.fcg",'{"comm":{"uin":"12345678","authst":"Q_H_L_2GkSAt50ee8gzIxBfwVxm4zic4SoFWtBe7jn4KeVgsdv-i16zip19RIMmP_JJ59","mina":1,"appid":1109523715,"ct":29},"urlReq":{"module":"vkey.GetVkeyServer","method":"CgiGetVkey","param":{"guid":"'.$msec.'","songmid":["'.$songmid.'"],"songtype":[0],"uin":"12345678","loginflag":1,"platform":"23","h5to":"speed"}}}');
	return $data;
}
function music($list,$Switch=false) {
	$data_cookie=file_get_contents("http://shengapi.cn/skey/skey.php");
	if(!$data_cookie) {
		$data_cookie=file_get_contents("http://shengapi.cn/skey/skey.php");
	}
	$data_cookie=json_decode($data_cookie,true);
	$header=[
	"user-agent: Mozilla/5.0 (Linux; Android 5.1.1; OPPO A33 Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045318 Mobile Safari/537.36 V1_AND_SQ_8.4.1_1442_YYB_D QQ/8.4.1.4680 NetType/WIFI WebP/0.3.0 Pixel/540 StatusBarHeight/37 SimpleUISwitch/0 QQTheme/2340",
	'Cookie: uin=o0'.$data_cookie["data"]["uin"].'; skey='.$data_cookie["data"]["skey"].'; p_uin=o'.$data_cookie["data"]["uin"].'; ',
	];
	$route="./data/file/data_text/qqmusic/".$list["songmid"].".json";
	if(file_exists($route)) {
		return json_decode(file_get_contents($route),true);
		exit();
	}
	$data=curl("https://i.y.qq.com/v8/playsong.html?_wv=14113&geneid=&uin=".$data_cookie["data"]["uin"]."&ADTAG=mqq_music&songmid=".$list["songmid"]."&playindex=0",0,$header);
	//print_r($data);
	preg_match("/m4aUrl\":\"(.*?)\",\"singer/",$data,$data_music);
	preg_match("/itemprop=\"image\" content=\"(.*?)\" \/>/",$data,$data_picture);
	if($data_music[1]==null) {
		return false;
		exit();
	}
	preg_match("/uin=(.*?)&/",$data_music[1],$data_music_uin);
	if(!$data_music_uin[1]&&!$Switch) {
		return false;
	}
	$singer_end=end($list["singer"]);
	foreach($list["singer"] as $v) {
		if($v===$singer_end) {
			$singer.=$v["name"];
		} else {
			$singer.=$v["name"]." / ";
		}
	}
	$array=array(
		'update time'=>date("Y-m-d H:i:s"),
		'data'=>array(
		"url"=>"http://y.qq.com/n/yqq/song/".$list["songmid"].".html",
		"singer"=>$singer,
		"Song"=>$list["songname"],
		"Picture"=>"http:".$data_picture[1],
		"music"=>$data_music[1],
		));
	if($_REQUEST["Compression"]=="true") {
		$music=json_decode(curl("http://ai.kenaisq.top/API/dwz.php?url=".urlencode($data_music[1])),true);
		$array["data"]["music"]=$music["url"];
	}
	if($Switch&&!$data_music_uin[1]) {
		$array["data"]["Tips"]="VIP账号登录失败，歌曲为VIP歌曲时，返回试听链接！";
	}
	file_put_contents($route,json_encode($array));
	return $array;
}
function analyze($url) {
	preg_match("/song\/(.*?).html/",$url,$mid);
	if(!$mid[1]) {
		echo json(1006,"text","歌曲解析失败！");
		exit();
	}
	$data_cookie=file_get_contents("http://shengapi.cn/skey/skey.php");
	if(!$data_cookie) {
		$data_cookie=file_get_contents("http://shengapi.cn/skey/skey.php");
	}
	$data_cookie=json_decode($data_cookie,true);
	$header=[
	"user-agent: Mozilla/5.0 (Linux; Android 5.1.1; OPPO A33 Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045318 Mobile Safari/537.36 V1_AND_SQ_8.4.1_1442_YYB_D QQ/8.4.1.4680 NetType/WIFI WebP/0.3.0 Pixel/540 StatusBarHeight/37 SimpleUISwitch/0 QQTheme/2340",
	'Cookie: uin=o0'.$data_cookie["data"]["uin"].'; skey='.$data_cookie["data"]["skey"].'; p_uin=o'.$data_cookie["data"]["uin"].'; ',
	];
	$route="./data/file/data_text/qqmusic/".$mid[1].".json";
	if(file_exists($route)) {
		return json_decode(file_get_contents($route),true);
		exit();
	}
	$data=curl("https://i.y.qq.com/v8/playsong.html?_wv=14113&geneid=&uin=".$data_cookie["data"]["uin"]."&ADTAG=mqq_music&songmid=".$mid[1]."&playindex=0",0,$header);
	//print_r($data);
	preg_match("/m4aUrl\":\"(.*?)\",\"singer/",$data,$data_music);
	preg_match("/itemprop=\"image\" content=\"(.*?)\" \/>/",$data,$data_picture);
	preg_match("/itemprop=\"description\" content=\"(.*?)\" \/>/",$data,$singername);
	preg_match("/songname\":\"(.*?)\",\"songtitle/",$data,$songname);
	if($data_music[1]==null) {
		return false;
		exit();
	}
	preg_match("/uin=(.*?)&/",$data_music[1],$data_music_uin);
	if(!$data_music_uin[1]&&!$Switch) {
		return false;
	}
	$singer_end=end($list["singer"]);
	foreach($list["singer"] as $v) {
		if($v===$singer_end) {
			$singer.=$v["name"];
		} else {
			$singer.=$v["name"]." / ";
		}
	}
	$array=array(
		'update time'=>date("Y-m-d H:i:s"),
		'data'=>array(
		"url"=>"http://y.qq.com/n/yqq/song/".$mid[1].".html",
		"singer"=>$singername[1],
		"Song"=>$songname[1],
		"Picture"=>"http:".$data_picture[1],
		"music"=>$data_music[1],
		));
	if($_REQUEST["Compression"]=="true") {
		$music=json_decode(curl("http://ai.kenaisq.top/API/dwz.php?url=".urlencode($data_music[1])),true);
		$array["data"]["music"]=$music["url"];
	}
	if($Switch&&!$data_music_uin[1]) {
		$array["data"]["Tips"]="VIP账号登录失败，歌曲为VIP歌曲时，返回试听链接！";
	}
	file_put_contents($route,json_encode($array));
	return $array;
}