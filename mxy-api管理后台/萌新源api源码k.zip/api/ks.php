<?php
$cookie='clientid=13; client_key=f60ac815; did=alipayio_bd64c0f0123f2b14153fc3abc604f381';
$url = "https://wxmini-api.uyouqu.com/rest/wd/wechatApp/hot/photos";//".$_GET['qq']."
$post = '{"pcursor":05,"count":1}';
$data = get_curl($url,$post,$url,$cookie);

$s=preg_match_all('/"coverUrls":\[{"cdn":"(.*?)","url":"(.*?)"},{"cdn":"(.*?)","url":"(.*?)"}\],"mainMvUrls":\[{"cdn":"(.*?)","url":"(.*?)"}(.*?)","caption":"(.*?)"/',$data,$x);
$s=rand(0,$s);
$t=$x[2][$s];
$l=$x[6][$s];
$n=$x[8][$s];
if($l==""){echo "抱歉，获取出错了！";exit;}
echo '图片：'.$t.'\n'.$n.'\n播放链接：'.$l.'';
//echo 'json:{"app":"com.tencent.structmsg","desc":"快手","view":"music","ver":"0.0.0.1","prompt":"[分享]'.$n.'","appID":"","sourceName":"","actionData":"","actionData_A":"","sourceUrl":"","meta":{"music":{"action":"","android_pkg_name":"","app_type":1,"appid":100497308,"desc":"'.$n.'","jumpUrl":"'.$l.'","musicUrl":"'.$l.'","preview":"'.$t.'","sourceMsgId":"0","source_icon":"","source_url":"","tag":"点卡片看视频点↗播放mp3","title":"'.$n.'"}},"config":{"autosize":true,"ctime":1575625127,"forward":true,"token":"7fef9b7d1e63b3500a42462126e9bc3d","type":"normal"},"text":"","sourceAd":""}';

function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept:application/json";
$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
$httpheader[] = "Connection:close";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if($post){
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
if($header){
curl_setopt($ch, CURLOPT_HEADER, TRUE);}
if($cookie){
curl_setopt($ch, CURLOPT_COOKIE, $cookie);}
if($referer){
if($referer==1){
curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
}else{
curl_setopt($ch, CURLOPT_REFERER, $referer);}}
if($ua){
curl_setopt($ch, CURLOPT_USERAGENT,$ua);
}else{
curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');}
if($nobaody){
curl_setopt($ch, CURLOPT_NOBODY,1);}
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;}
?>