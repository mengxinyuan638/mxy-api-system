<?php
error_reporting(0);//不致命报错
$lx=$_GET["lx"];
$url="http://api.ippzone.com/topic/detail_v2?sign=36ef2212d768361f78a05d3733cb52b2";
//类型参数
$coco=array(
"女神福利社"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":377937,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":1,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614160476088,"token":"v2_B5Pt4-NouhgpADN9ykkZ8v2Ujr-OcPCc6O8eoSu39fgKmRt_RtGS-EpCChRswx1Y","android_id":"29ed786c44582fad"}',
"颜值视频"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":381048657,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614166166990,"token":"v2_tkZGBB1rymvFVLXa3oVajWKA_dBEdObfnw56_3iG9zBOE3y2ZMWclj7_xVLKKuwj","android_id":"29ed786c44582fad"}',
"搞笑视频"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":377918,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614166839786,"token":"v2_WrzqJMW7-drOImeqJoFPk67aKEP9YNJxMFNHGRq5P1tB5WxV_v3bTLOAxNCvkS2f","android_id":"29ed786c44582fad"}',
"动漫收集站"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":381046502,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614166895343,"token":"v2_YpSwlyS0HXwrIsUu1cl1Sw6pq5D-KO0gNUIwKlfJH5_59LGA4TPvVOOgF3Lr7LXB","android_id":"29ed786c44582fad"}',
"一起来唱歌"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":381046481,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614167720995,"token":"v2_W4tQV1B7DlfYUTpikOa7o-BEIdBDEuqZrQcr4xXdviAxnaGGUlfbMxo44SBWBM0H","android_id":"29ed786c44582fad"}',
"绝地求生"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":377929,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614168059209,"token":"v2_Vis0UGr2aL3UPEXtGklSBwxro0ElazPV1oe7_tfFBzcbnAOW7GgP4g85z8fXJmxl","android_id":"29ed786c44582fad"}',
"王者荣耀"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":377928,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614168099373,"token":"v2_Vis0UGr2aL3UPEXtGklSBwxro0ElazPV1oe7_tfFBzcbnAOW7GgP4g85z8fXJmxl","android_id":"29ed786c44582fad"}',
"二次元御宅族"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":379597,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614168141728,"token":"v2_Vis0UGr2aL3UPEXtGklSBwxro0ElazPV1oe7_tfFBzcbnAOW7GgP4g85z8fXJmxl","android_id":"29ed786c44582fad"}',
"直男的日常"=>'{"c_types":[1,2,101,103,104],"next_cb":"{\"consumed_number\":10,\"is_rec\":true,\"offset\":10}","sort":"hot","tid":381046421,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614168244505,"token":"v2_R8TBkOrr0aQsR5NWpzOdeOasS1eUc2VVxZ5MNjZptr2oeYxZPonETL-a71uik49N","android_id":"29ed786c44582fad"}',
"皮皮推荐"=>'{"ad_wakeup":1,"audio":1,"auto":0,"c_types":[1,2,101,102,103,104,20,21,22,23],"direction":"down","filter":"all","sdk_ver":{},"tab":"推荐","h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614169730558,"token":"v2_nCMXSLlsZdAEuJo3qZL5PSjTqFZsqxZuipH5krCN0UpXpqeN2MREKL9NELWq8WyG","android_id":"29ed786c44582fad"}',
"皮皮电音台"=>'{"c_types":[1,2,101,103,104],"next_cb":"{\"consumed_number\":9,\"is_rec\":false,\"offset\":40}","sort":"hot","tid":381046461,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614169968064,"token":"v2_sYIs9g39Nc0k1ZYLr2CmubHiqHNGrBzzY1eZYJyRoaiEEkrXawDgcAbVA5Wpwkzb","android_id":"29ed786c44582fad"}',
"第五人格"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":379630,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614170027399,"token":"v2_sYIs9g39Nc0k1ZYLr2CmubHiqHNGrBzzY1eZYJyRoaiEEkrXawDgcAbVA5Wpwkzb","android_id":"29ed786c44582fad"}',
"穿越火线"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":378659,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614170112323,"token":"v2_sFM4u8aqfn1kIObnKDmXAwzvvjRnhTh1WtHcLPz6Z7O4fUQTx9ro8bpAP4iub6SS","android_id":"29ed786c44582fad"}',
"英雄联盟"=>'{"c_types":[1,2,101],"hotstamp":0,"pid":0,"tid":379629,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614170147741,"token":"v2_sFM4u8aqfn1kIObnKDmXAwzvvjRnhTh1WtHcLPz6Z7O4fUQTx9ro8bpAP4iub6SS","android_id":"29ed786c44582fad"}',
"沙雕同学"=>'{"c_types":[1,2,101,103,104],"next_cb":"{\"consumed_number\":10,\"is_rec\":true,\"offset\":20}","sort":"hot","tid":381048099,"h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614170281088,"token":"v2_Qvb5stssmAv_h9e9rlVAJW2AhOyQzI3SeibajK9VR9I9G4Lyh7nQ55SRF62omiP7","android_id":"29ed786c44582fad"}'
);
/*
http://api.ippzone.com/search/topic?sign=eba1c3b76a4cb3eb3cfb1707549d8faa
{"next_cb":"","q":"火影忍者","h_av":"4.7.2","h_pipi":"1.7.2","h_dt":0,"h_os":29,"h_app":"zuiyou_lite","h_model":"PCHM10","h_did":"29ed786c44582fad","h_nt":4,"h_m":2846925958169,"h_ch":"qihu","h_ts":1614170361443,"token":"v2_GZCvDSehoczx5erhw0oWtOwQTOl9BYtaApLIjYczJ5AHMyf5wYb01E4tOMrk_UZD","android_id":"29ed786c44582fad"}
*/
//类型判断
$lxs=$coco[$lx];
if(!$lxs){echo "参数\"lx=\"请填写完整！\n类型已有:女神福利社/颜值视频/搞笑视频/动漫收集站/一起来唱歌/绝地求生/王者荣耀/二次元御宅族/直男的日常/皮皮推荐/皮皮电音台/第五人格/穿越火线/英雄联盟/沙雕同学！,后续正在更新！";}else{
$data=post($url,$lxs);
//print_r($data);//打印查看数据
$json=json_decode($data, true);//开始解析
$s=count($json["data"]["list"]);
$s=rand(0,($s-1));
//格式化项目
$id=$json["data"]["list"][$s]["imgs"][0]["id"];//提取id
$sp=$json["data"]["list"][$s]["videos"][$id]["qualities"][0]["urls"][0]["url"];//视频链接
$tu=$json["data"]["list"][$s]["imgs"][0]["urls"]["360"]["urls"][0];//图片链接
$bt=$json["data"]["list"][$s]["member"]["sign"]?:$json["data"]["list"][$s]["member"]["profession"]["desc"];//标题
$yh=$json["data"]["list"][$s]["member"]["name"];//用户
//输出项目
echo "±img=".$tu."±\n";
echo "用户:".$yh."\n";
echo "标题:".$bt."\n";
echo $sp;

}
function post($url,$post){
$curl = curl_init(); 
curl_setopt($curl, CURLOPT_URL, $url); 
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1);
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
curl_setopt($curl, CURLOPT_POST, 1); 
curl_setopt($curl, CURLOPT_POSTFIELDS, $post); 
curl_setopt($curl, CURLOPT_TIMEOUT, 30); 
curl_setopt($curl, CURLOPT_HEADER, 0); 
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl); 
if (curl_errno($curl)) {
echo '错误信息;'.curl_error($curl);
}
curl_close($curl); 
return $result; 
}
