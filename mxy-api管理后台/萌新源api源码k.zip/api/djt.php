<?php
header("Content-type: text/html; charset=utf-8");
$utime = date("Y-m-d");
$json_string =httpGet('http://www.dutangapp.cn/u/toxic?date='.$utime);
$data= json_decode($json_string,true);
$myfile = fopen("wenben/binduyan.txt", "a+");
    foreach ($data['data'] as $v){
        if (isset($v['data'])){
            $text3= $v['data']."\n";
            fwrite($myfile, $text3);
        }
    }
fclose($myfile);
echo "ok";
function httpGet($url) {
    $curl = curl_init();
    $httpheader[] = "Accept:*/*";
    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
    $httpheader[] = "Connection:close";
    curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1" );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $httpheader);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 3);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_URL, $url);
    $res = curl_exec($curl);
    curl_close($curl);
    return $res;
}