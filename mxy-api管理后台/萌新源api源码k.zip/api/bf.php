<?php

$msg = $_GET['msg'];
echo "<video src=\"http://hbmc.chinashadt.com:2739/live/dzdy.stream_360p/playlist.m3u8\" controls=\"controls\" webkit-playsinline=\"true\" style=\"width: 100%; height: 60%; background-color: rgb(0, 0, 0);\" width=\"100%\" height=\"100%\"></video>";

?>