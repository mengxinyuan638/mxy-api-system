<?php
include('./key.php');
include("./asd/a.php");
$aa = intval(file_get_contents("asd/jishu.dat"));
?>
<!doctype html>
<!-- 我知道你喜欢扒站但是我承受不住 -->
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>君辞API - 免费提供API服务</title>
<meta name="viewport"content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>君辞API - 提供免费接口调用平台</title>
<meta name="description" content="君辞API是君辞免费提供API数据接口调用服务平台 - 我们致力于为用户提供稳定、快速的免费API数据接口服务。">
<meta name="keywords" content="API,聚合数据,API数据接口,API,免费接口,免费api接口调用,免费API数据调用,君辞API,君辞API">
<meta name="author" content="君辞">
<meta name="founder" content="君辞API">
<link href="../public/layui/other/css/site.min.css" rel="stylesheet">
<link href="../public/layui/other/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../public/layui/other/css/layui.css">
<link href="../public/layui/other/css/oneui.css" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="../favicon.ico">
<script src="https://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
<script src="../public/layui/layui.all.js"></script>
<script>
</script>
</head>

<body>
<header class="site-header">
<nav class="nav_jsxs">
<span style="float: left;"><a class="logo_jsxs" href=""></a></span>
<a href="../">首页</a>
<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $qq; ?>&amp;site=qq&amp;menu=yes">反馈</a>
</nav>
<div class="box-text">
<h1>君辞API</h1>
<?php
$data = file_get_contents("jiekoushuju.php");
$result = preg_match_all('/{"name":"(.*?)","dz":"(.*?)","cs":"(.*?)","gg":"(.*?)","sl":"(.*?)","sj":"(.*?)"}/',$data,$v);
?>

<p>稳定、快速、免费的 API 接口服务<br><span class="package-amount">共收录了 <strong><?php echo $result+62;?></strong> 个接口</span>
</p>
<style>
    #nr{
    	font-size:20px;
    	margin: 0;
        background: -webkit-linear-gradient(left,
            #ffffff,
            #ff0000 6.25%,
            #ff7d00 12.5%,
            #ffff00 18.75%,
            #00ff00 25%,
            #00ffff 31.25%,
            #0000ff 37.5%,
            #ff00ff 43.75%,
            #ffff00 50%,
            #ff0000 56.25%,
            #ff7d00 62.5%,
            #ffff00 68.75%,
            #00ff00 75%,
            #00ffff 81.25%,
            #0000ff 87.5%,
            #ff00ff 93.75%,
            #ffff00 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-size: 200% 100%;
        animation: masked-animation 2s infinite linear;
    }
    @keyframes masked-animation {
        0% {
            background-position: 0 0;
        }
        100% {
            background-position: -100%, 0;
        }
    }
</style>
<div style="background-color:#333;border-radius:25px;box-shadow:0px 0px 5px #f200ff;padding:5px;margin-top:10px;margin-bottom:0px;">
<marquee>
<b id="nr">君辞API是君辞云免费提供API数据接口调用服务平台 - 我们致力于为用户提供稳定、快速的免费API数据接口服务，感谢大家支持君辞API，欢迎大家调用本站接口，请大家收藏本站，各位不要攻击本站呦！</b> </marquee>
</div>
<center><span> 本站网址:</span>
<font color="red">http://<?php echo $key; ?></font><br/>
</center>

<div style=" position:fixed; left:0px; bottom:0px; width:30%; height:100px; background-image:url('ddt.gif');background-repeat: no-repeat;background-size: 100% 100%;"></div>

当前时间：<span id="localtime"></span><script type="text/javascript">function showLocale(objD)
{var str,colorhead,colorfoot;var yy = objD.getYear();
if(yy<1900) yy = yy+1900;
        var MM = objD.getMonth()+1;
    if(MM<10) MM = '0' + MM;
    var dd = objD.getDate();
    if(dd<10) dd = '0' + dd;
    var hh = objD.getHours();
    if(hh<10) hh = '0' + hh;
    var mm = objD.getMinutes();
    if(mm<10) mm = '0' + mm;
    var ss = objD.getSeconds();
    if(ss<10) ss = '0' + ss;
    var ww = objD.getDay();
    if  ( ww==0 )  colorhead="<font color=\"#FF3030\">";
    if  ( ww > 0 && ww < 6 )  colorhead="<font color=\"#FF3030\">";
    if  ( ww==6 )  colorhead="<font color=\"#FF3030\">";
    if  (ww==0)  ww="星期日";
    if  (ww==1)  ww="星期一";
    if  (ww==2)  ww="星期二";
    if  (ww==3)  ww="星期三";
    if  (ww==4)  ww="星期四";
    if  (ww==5)  ww="星期五";
    if  (ww==6)  ww="星期六";
    colorfoot="</font>"
    str = colorhead + yy + "-" + MM + "-" + dd + "丨" + hh + ":" + mm + ":" + ss + "丨" + ww + colorfoot;
    return(str);}function tick()
{var today;today = new Date();document.getElementById("localtime").innerHTML = showLocale(today);window.setTimeout("tick()", 1000);}
tick();</script>
<p></p>
<?php
$ip = $_SERVER["REMOTE_ADDR"]; 
$mm = file_get_contents("http://whois.pconline.com.cn/ipJson.jsp?callback=&ip=$ip");
$encode = mb_detect_encoding($mm, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encode = mb_convert_encoding($mm, 'UTF-8', $encode);
preg_match("/city\":\"(.*?)\"/",$str_encode,$add);
preg_match("/addr\":\"(.*?)\"/",$str_encode,$add1);
$data = file_get_contents("compress.zlib://http://wthrcdn.etouch.cn/weather_mini?city=".$add[1]."");
$encodea = mb_detect_encoding($data, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
$str_encodea = mb_convert_encoding($data, 'UTF-8', $encodea);
preg_match_all("/date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fx\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fl\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)city\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)date\":\"(.*?)\"(.*?)high\":\"(.*?)\"(.*?)fengli\":\"(.*?)\"(.*?)low\":\"(.*?)\"(.*?)fengxiang\":\"(.*?)\"(.*?)type\":\"(.*?)\"(.*?)ganmao\":\"(.*?)\"/",$str_encodea,$c);
$l=$c[37][0];
?>

</script>
<p><span style="color:#FFFFFF;">您的IP：<?php echo $ip; ?></span></span></p>
<span style="color:#FFFFFF;">您的地址：<?php echo $add1[1]; ?></span></span></p>
<span style="color:#FFFFFF;"><?php echo $add[1]; ?>明天天气：<?php echo $l; ?></span></span></p>
<p><span style="color:#FFFFFF;">总访问量：<?php echo $aa; ?></span>次</span></p>

</script></p><div id="J_player">     <audio id="J_MPlayer" src="http://<?php echo $key; ?>/mp3/<?php echo rand(1,14); ?>.mp3" controls="controls" autoplay="autoplay" autobuffer="autobuffer"></audio>    </div>

</div>
</header><section class="content content-boxed">
<div class="row row_jsxs" id="listApi">

<?php
if($result== 0){
echo "";
}else{
for( $i = 0 ; $i < $result && $i < $result ; $i ++ ){
$name=$v[1][$i];//名称
$dz=$v[2][$i];//提交地址
$cs=$v[3][$i];//参数
$gg=$v[4][$i];//公告
$sl=$v[5][$i];//示例
$sj=$v[6][$i];//返回数据
echo '<!--分割--><div class="col-sm-4"> <a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ss.php?id='.($i+1).'"> <div class="ribbon-box font-w600">'.$mz.'API</div><div class="block-content"> <div class="h4 push-5">'.$name.'</div> <p class="text-muted">'.$gg.'</p> </div></a></div> <!--分割-->';
}}?>



<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/music.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">网易热歌榜随机音乐API</div>
<p class="text-muted">热歌榜随机返回音乐</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/weather.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">多选墨迹天气查询API</div>
<p class="text-muted">用来查询天气，温度，空气质量等</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/Picturetext.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">图片取文字API</div>
<p class="text-muted">粗略获取图片中的文字，一天可以用五万次哦</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/60s.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">每日API</div>
<p class="text-muted">返回图片在图片中有，农历，时间，历史今天等等</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./api/skey/">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">获取QQskey</div>
<p class="text-muted">获取QQ的skey，pskey</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/ff.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">菲菲机器人</div>
<p class="text-muted">天气、翻译、藏头诗、笑话、歌词、计算、域名信息/备案/收录查询、IP查询、手机号码归属、人工智能聊天</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/fff.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">搜索梗</div>
<p class="text-muted">搜索更</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/cos.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">cos接口</div>
<p class="text-muted">随机返回一条cos图链接</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/tu.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">美腿接口</div>
<p class="text-muted">随机返回一条美腿图链接</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/fiction.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">小说搜索</div>
<p class="text-muted">搜索小说，进行观看</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/sition.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">搜索作文</div>
<p class="text-muted">搜索作文</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/cartoon.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">腾讯漫画</div>
<p class="text-muted">搜索漫画</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/yping.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">查询疫情</div>
<p class="text-muted">查询某地区疫情情况</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/lishi.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">历史今天</div>
<p class="text-muted">查询历史上的今天</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/trans.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">智能翻译</div>
<p class="text-muted">智能翻译</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/worda.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">艺术签名</div>
<p class="text-muted">艺术签名</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/Laughing.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机笑话</div>
<p class="text-muted">随机笑话</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/mryy.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机一言</div>
<p class="text-muted">随机一言</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/dmtupian.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">动漫图片</div>
<p class="text-muted">动漫图片</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/dmtupian2.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机动漫</div>
<p class="text-muted">随机动漫</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/dmtupian3.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">美女图片</div>
<p class="text-muted">美女图片</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/lsdd.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">多多铃声</div>
<p class="text-muted">?type=xml 可以返回xml</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/Ridicule.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">口吐芬芳等</div>
<p class="text-muted">口吐芬芳</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/constellation.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">星座运势</div>
<p class="text-muted">星座运势</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/ping.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">ping</div>
<p class="text-muted">ping查看域名延迟</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/kp.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">窥屏接口</div>
<p class="text-muted">利用百度API检测窥屏人员</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/twqh.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">土味情话</div>
<p class="text-muted">1700句土味情话</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/pdzs.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">判断文本字数</div>
<p class="text-muted">使用mb_strlen()直接判断字数</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/qqnick.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">获取QQ昵称</div>
<p class="text-muted">根据QQ号获取昵称</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/wy.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">网易云音乐</div>
<p class="text-muted">来源网易云音乐，有n=数字为选歌，无n则为列表。type为xml则输出xml数据。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/kuwodx.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">酷我音乐</div>
<p class="text-muted">来源酷我音乐，type为xml时将输出xml格式，否则将输出播放直链。有n=数字为选，无n则为列表。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/kugoudx.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">酷狗音乐</div>
<p class="text-muted">来源酷狗音乐，type为xml时将输出xml格式，否则将输出播放直链。有n=数字为选歌，无n则为列表。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/huya.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">虎牙</div>
<p class="text-muted">虎牙直播，有n=数字为选，无n则为列表。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/sgbaike.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">百科</div>
<p class="text-muted">查询百科内容。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/qqdz.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">看点段子</div>
<p class="text-muted">随机返回看点精选搞笑段子。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/gc.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">歌词</div>
<p class="text-muted">来源于酷狗，有n=数字输出整首歌词，无n为列表。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/wd.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">问答</div>
<p class="text-muted">返回有关问题答案。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/dt.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">斗图</div>
<p class="text-muted">随机返回相关斗图。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/duanzi.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">段子</div>
<p class="text-muted">id只能为1或者2，随机返回精选短视频或段子。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/wzry.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">王者荣耀英雄出装</div>
<p class="text-muted">查询英雄出装、铭文配置等。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/hqmt.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机精选图</div>
<p class="text-muted">来源于小妖精精选图。后面有m=1为返回图片链接，无m=1</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/sjys.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机颜色</div>
<p class="text-muted">id只能为1或者2，随机返回精选短视频或段子。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/xx.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">QQ空间信息查询</div>
<p class="text-muted">查询空间留言、日志、说说、相册数据，也能查询部分QQ绿钻等级、成长值、是否年费。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/laji.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">垃圾分类</div>
<p class="text-muted"></p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/cyjl.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">成语接龙</div>
<p class="text-muted">开始时，msg=开始成语接龙+一个关键字，如msg=开始成语接龙慕，id使用中请勿修改，建议使用QQ，如id=%QQ%。接龙格式：为msg=我接君辞而来，id与前者保持一致。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/bdj.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">百思不得姐段子</div>
<p class="text-muted">随机返回精选段子。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/jingxuanshipin.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">精选短视频</div>
<p class="text-muted">type可为网红、明星、热舞、风景、游戏、动物。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/meinvtu.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">美女图</div>
<p class="text-muted">m值为1时只返回链接，m为其他值时返回图片和类型。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/fangke.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">空间访客数量查询</div>
<p class="text-muted">查询QQ空间访客数量，返回当日访客数及总访客数。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/qqtq.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">QQ天气</div>
<p class="text-muted">与QQ同步天气，仅支持县级以上城市。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/miyu.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机谜语</div>
<p class="text-muted">共收集10715条谜语信息，将给您带来不一样的体验。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/tq.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">天气〖三天版〗</div>
<p class="text-muted">返回三天天气预报。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/lt.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">聊天</div>
<p class="text-muted">该接口已坏</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/nl.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">农历</div>
<p class="text-muted">返回当日农历、节气。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/fanyi.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">有道翻译</div>
<p class="text-muted">提供汉、英互译。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/douyu.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">斗鱼</div>
<p class="text-muted">搜索斗鱼直播主播房间号，点击链接即可观看。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/apk.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">应用搜索下载</div>
<p class="text-muted">有n=数字为选择，无n或n为空值为列表，来源于某某宝。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/bilibili.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">哔哩哔哩</div>
<p class="text-muted">来源于网络，有n=数字为选，无n则为列表。</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/name.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">随机姓名</div>
<p class="text-muted">随机一个姓名</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/head.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">多选头像</div>
<p class="text-muted">头像类型 男/女/动漫男/动漫女</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/phone.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">手机号归属地</div>
<p class="text-muted">用于查询手机号归属地</p>
</div></a></div>
<!--分割-->

<!--分割-->
<div class="col-sm-4">
<a target="_orange" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="./ipa/time.php">
<div class="ribbon-box font-w600">君辞API</div><div class="block-content">
<div class="h4 push-5">时间查询</div>
<p class="text-muted">用于查看现在时间机器人也可以用</p>
</div></a></div>
<!--分割-->


<div class="col-sm-12">
  <div class="block block-link-hover2 ribbon ribbon-modern ribbon-success">
<div class="block-content">
  <a class="block" href="">
<p class="text-center">本网站只提供接口服务，造成的一切后果与本网站无关!如果本站发布的内容侵犯你的利益，请联系我。发送至我的邮箱<?php echo $qq; ?>@qq.com</p>
<p class="text-center"><span id="runtime_span"></span>
<script type="text/javascript">function show_runtime(){window.setTimeout("show_runtime()",1000);X=new 
Date("04/13/2021 00:00:00");
Y=new Date();T=(Y.getTime()-X.getTime());M=24*60*60*1000;
a=T/M;A=Math.floor(a);b=(a-A)*24;B=Math.floor(b);c=(b-B)*60;C=Math.floor((b-B)*60);D=Math.floor((c-C)*60);
runtime_span.innerHTML="本站稳定运行: "+A+"天"+B+"小时"+C+"分"+D+"秒"}show_runtime();</script>
</p>
</a>
</div>
</div>
</div>
</div>
<div style="float:left; margin:0px 10px;"> 
<style type="text/css"> 
.qqlogo1{ 
 margin-top: 15px; 
 width:70px; 


 height:70px; 


 border-radius:200px; 
  
  
 }
  



.qqlogo2{ 


 margin-top: 0px; 


 width:70px; 


 height:70px; 


 border-radius:200px; 
  
  
 }

 .find .links .item1{
	position: relative;
	width: 22.6%;
	height: 80px;
	line-height: 80px;
	margin: 10px 1.2%;
	padding: 5px 0;
	text-align: center;
	float: left;
	transition: .2s all;
	opacity: .9;
	}

	.find .links .item1:hover{
		opacity: 1;
		transform: translateY(-10px);
	}

	.find .links .item1 .inner{
		position: relative;
		z-index: 5;
	}

	.find .links .item1 .bg{
		position: absolute; 
		bottom: 0;
		left: 0;
		width: 100%;
		height: 5%;
		z-index: 0;
		transition: .15s all;
	}

	.find .links .item1:hover .bg{
		height: 100%;
		width: 100%;
		border-radius: 5px;
		box-shadow: 0 3px 20px rgba(0,0,0,.28);
	}

	.find .links .item1 i{
		font-size: 20px;
	}

	.find .links .item1 span{
		display: inline-block;
		width: 100px;
	}

	.gate .links .item1 {
		margin: 5px 0;
		padding: 15px 1.5%;
		float: left;
		width: 22%;
		height: 60px;
		transition: .2s all;
		opacity: .85;
	}

	.gate .links .item1.akarin{
		opacity: .58;
	}

	.gate .links .item1:hover{
		opacity: 1;
		border-radius: 5px;
		background-color: rgba(255,255,255,.25);
		transform: translateY(-5px);
		box-shadow: 0 3px 20px rgba(0,0,0,.28);
	}

	.gate .links .item1 .avatar{
		float: left;
		height: 60px;
		line-height: 60px;
		width: 60px;
		border-radius: 100%;
		text-align: center;
		margin-right: 15px;
		background-color: #000000;
		overflow: hidden;
	}

	.gate .links .item1 .avatar i{
		font-size: 24px;
	}

	.gate .links .item1 .avatar img{
		height: 60px;
		max-width: 60px;
		border-radius: 100%;
	}

	.gate .links .item1 .inner{
		padding: 6px;
	}

	.gate .links .item1 .inner h5{
		font-weight: normal;
		font-size: 17px;
	}

	.gate .links .item1 .inner p{
		font-size: 13px;
		color: rgba(255,255,255,.6);
	}
	.find .links .item1,
	.gate .links .item1{
		width: 46%;
		height: auto;
		padding: 5px 0;
		margin: 10px 2%;
	}

	.find .links .item1{
		height: 60px;
		line-height: 60px;
		font-size: 13px;
	}

	.gate .links .item1 .avatar {
	height: 40px;
	line-height: 40px;
	width: 40px;
	}
	.gate .links .item1 .avatar img {
	height: 40px;
	max-width: 40px;
	}
	.gate .links .item1 .inner {
	padding: 0;
	}
	.gate .links .item1 .inner h5 {
	font-size: 15px;
	}

	.gate .links .item1 .inner h5,
	.gate .links .item1 .inner p{
		white-space:nowrap; 
	text-overflow:ellipsis;
	overflow:hidden;
	}
	.gate .links .item1 .inner h5 {
	font-size: 15px;
	}
	.gate .links .item1 .inner h5{
		font-weight: normal;
		font-size: 17px;
	}
 </style> 
 </div>

</div></font> 


<br>
<div class="gate ch"> 
<div class="container links"> 
<h2 class="chtitle"><center><b id="nr">友情<span>链接</span></b></center></h2> 
<div class="clear">



<a href="http://www.qinbinga.xyz">
<div class="item1"> 
<div class="avatar"> 
<img src="http://q2.qlogo.cn/headimg_dl?bs=Q2826957971&dst_uin=2826957971&dst_uin=2826957971&;dst_uin=2826957971&spec=100&url_enc=0&referer=bu_interface&term_type=PC"> 
</div> 
<div class="inner"> 
<h5><font color="black">梦久api</font></h5>
<p><font color="red">介绍:梦久API</font></p> 
</div> 
</div></a>

<a href="http://tianyi.gjwa.cn" target="_blank">
<div class="item1"> 
<div class="avatar"> 
<img src="http://q2.qlogo.cn/headimg_dl?bs=Q3189402257&dst_uin=3189402257&dst_uin=3189402257&;dst_uin=3189402257&spec=100&url_enc=0&referer=bu_interface&term_type=PC"> 
</div> 
<div class="inner"> 
<h5><font color="black">天一api</font></h5>
<p><font color="red">介绍:天一api,源码免费开源噢！</font></p> 
</div> 
</div></a>

<a href="http://api.tangdouz.com">
<div class="item1"> 
<div class="avatar"> 
<img src="http://q2.qlogo.cn/headimg_dl?bs=Q2595342084&dst_uin=2595342084&dst_uin=2595342084&;dst_uin=2595342084&spec=100&url_enc=0&referer=bu_interface&term_type=PC"> 
</div> 
<div class="inner"> 
<h5><font color="black">糖豆子api</font></h5>
<p><font color="red">介绍:优质API</font></p> 
</div> 
</div></a>

<a href onclick="return alert('友链申请说明\n网站名:君辞API\n网站图:<?php echo $key; ?>/images/favicon.png\n网址:<?php echo $key; ?>\n介绍:君辞API\nQQ:<?php echo $qq; ?>\n这是例子，请把你申请友链内容发送到<?php echo $qq; ?>@qq.com\n一定把我网站写到你的友链表上，否则不给你添加');" target="_blank">
<div class="item1"> 
<div class="avatar"> 
<img src="images/favicon.png"> 
</div> 
<div class="inner"> 
<h5><font color="black">申请友情</font></h5>
<p><font color="red">介绍:申请友情</font></p> 
</div> 
</div></a>

<div class="gate ch"> 
<div class="container links"> 
<h2 class="chtitle"><center><b id="nr">备案号:京ICP备19022312号-3</b></center></h2> 
<div class="clear">

<img width="300" height="300" src="images/favicon.png" alt="123">

<div class="main">
        <div class="quarter-div blue"></div>
        <div class="quarter-div green"></div>
        <div class="quarter-div orange"></div>
        <div class="quarter-div yellow"></div>
    </div>
</div></a>

</div></div></div></section>
	 
 </div> </div></a>

	 </div> </div></a>


<div style="text-align:right;">

<a href="http://ad.jingdianwan.com/jstm/?uid=122&sid=291" target="_blank" style="line-height:1.5;"></a>

</div>



<script type="text/javascript">
(function() {var coreSocialistValues = ["富强", "民主", "文明", "和谐", "自由", "平等", "公正", "法治", "爱国", "敬业", "诚信", "友善"], index = Math.floor(Math.random() * coreSocialistValues.length);document.body.addEventListener('click', function(e) {if (e.target.tagName == 'A') {return;}var x = e.pageX, y = e.pageY, span = document.createElement('span');span.textContent = coreSocialistValues[index];index = (index + 1) % coreSocialistValues.length;span.style.cssText = ['z-index: 9999999; position: absolute; font-weight: bold; color: #ff6651; top: ', y - 20, 'px; left: ', x, 'px;'].join('');document.body.appendChild(span);animate(span);});function animate(el) {var i = 0, top = parseInt(el.style.top), id = setInterval(frame, 16.7);function frame() {if (i > 180) {clearInterval(id);el.parentNode.removeChild(el);} else {i+=2;el.style.top = top - i + 'px';el.style.opacity = (180 - i) / 180;}}}}());
</script></div></div></div></div></header></div></div></section></div><script type="text/javascript" src="https://ohan.gitee.io/HanKu/HanJs/HanSnow.js"></script></body>




</div></div></div></section>

<script type="text/javascript" src="static/js/20354947.js"></script>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? "https://" : "http://");document.write(unescape("%3Cspan id="cnzz_stat_icon_1278270105"%3E%3C/span%3E%3Cscript src="" + cnzz_protocol + "s9.cnzz.com/z_stat.php%3Fid%3D1278270105%26online%3D1%26show%3Dline" type="text/javascript"%3E%3C/script%3E"));</script>
<script type="text/javascript">



</section>
<script type="text/javascript">
<script src="js/jquery.min.js"></script>
<script src="js/skel.min.js"></script>
<script src="js/util.js"></script>
<script src="js/main.js"></script>
<audio autoplay>
<p><script data-cfasync="false" src="js/email-decode.min.js"></script></p>

 <script type="text/javascript" charset="utf-8"  src="https://files.cnblogs.com/files/liuzhou1/L2Dwidget.0.min.js"></script>
<script type="text/javascript" charset="utf-8"  src="https://files.cnblogs.com/files/liuzhou1/L2Dwidget.min.js"></script>
<script type="text/javascript">
    L2Dwidget.init({"display": {
        "superSample": 2,
        "width": 200,
        "height": 400,
             "position": "right",
                 "hOffset": 0,
        "vOffset": 0
          }
     });
</script>



<!--鼠标特效-->
<canvas id="fireworks" style="position:fixed;left:0;top:0;pointer-events:none;"></canvas><script type="text/javascript" src="https://cdn.bootcss.com/animejs/2.2.0/anime.min.js"></script><script type="text/javascript" src="http://blog.nanyinet.cn/usr/plugins/HoerMouse/static/js/fireworks.js"></script><script>$("body").css("cursor", "url('http://blog.nanyinet.cn/usr/plugins/HoerMouse/static/image/dew/normal.cur'), default");
$("a").css("cursor", "url('http://blog.nanyinet.cn/usr/plugins/HoerMouse/static/image/dew/link.cur'), pointer");
</script>

<!--鼠标特效结束-->



<script src="https://api.vvhan.com/api/yinghua"></script>
<script src="https://api.vvhan.com/api/meihua"></script>
</body>
</html>