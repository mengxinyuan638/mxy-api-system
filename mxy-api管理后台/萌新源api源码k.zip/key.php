<?php
$key=$_SERVER["HTTP_HOST"];//网址
$qq="164857639";//QQ
$mz="君辞";//名称
?>
